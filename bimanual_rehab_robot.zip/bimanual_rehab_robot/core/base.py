"""
Base abstract classes and interfaces for the Bimanual Tele-Rehabilitation Robot System.
Defines contracts that concrete implementations must follow.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Any, Protocol, TypeVar, Generic
import numpy as np

from .enums import (
    Gender, AffectedSide, JointType, ExerciseType, 
    ExerciseMode, FatigueLevel, UserRole, Permission
)


# ==================== Type Variables ====================

T = TypeVar('T')
EntityT = TypeVar('EntityT', bound='Entity')


# ==================== Base Entity ====================

@dataclass
class Entity:
    """Base class for all entities with identity."""
    id: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)


# ==================== Data Classes ====================

@dataclass
class Vector3D:
    """3D vector for positions, velocities, etc."""
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    
    def to_array(self) -> np.ndarray:
        return np.array([self.x, self.y, self.z])
    
    @classmethod
    def from_array(cls, arr: np.ndarray) -> 'Vector3D':
        return cls(x=arr[0], y=arr[1], z=arr[2])
    
    def magnitude(self) -> float:
        return np.linalg.norm(self.to_array())


@dataclass
class JointState:
    """State of a single joint."""
    joint_type: JointType
    position: float  # radians
    velocity: float  # rad/s
    torque: float    # Nm
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class ArmState:
    """Complete state of an arm (master or follower)."""
    shoulder_rotation: JointState
    elbow_flexion: JointState
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_vector(self) -> np.ndarray:
        """Convert to state vector [θ_shoulder, θ_elbow, ω_shoulder, ω_elbow]."""
        return np.array([
            self.shoulder_rotation.position,
            self.elbow_flexion.position,
            self.shoulder_rotation.velocity,
            self.elbow_flexion.velocity
        ])


@dataclass
class TorqueCommand:
    """Torque command for the robot."""
    shoulder_torque: float  # Nm
    elbow_torque: float     # Nm
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_array(self) -> np.ndarray:
        return np.array([self.shoulder_torque, self.elbow_torque])


@dataclass 
class EstimationResult:
    """Result of a parameter estimation."""
    parameters: np.ndarray
    covariance: np.ndarray
    confidence: float
    iterations: int
    converged: bool
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BSIPResult:
    """Body Segment Inertial Parameters for one segment."""
    segment_name: str
    mass: float              # kg
    length: float            # m
    com_position: float      # m from proximal joint
    com_ratio: float         # ratio from proximal
    inertia_xx: float        # kg·m² about x-axis
    inertia_yy: float        # kg·m² about y-axis  
    inertia_zz: float        # kg·m² about z-axis
    radius_of_gyration: float  # m


@dataclass
class FatigueIndicators:
    """Fatigue detection indicators."""
    torque_decline_ratio: float      # Current/initial torque ratio
    movement_smoothness: float       # Jerk metric
    rom_decline_ratio: float         # Range of motion decline
    velocity_decline_ratio: float    # Velocity decline
    emg_frequency_shift: Optional[float] = None  # If EMG available
    timestamp: datetime = field(default_factory=datetime.now)


# ==================== Abstract Base Classes ====================

class ParameterEstimator(ABC):
    """
    Abstract base class for parameter estimation algorithms.
    Implementations: RLS, FFRLS, Kalman, etc.
    """
    
    @abstractmethod
    def initialize(self, initial_params: np.ndarray, initial_covariance: np.ndarray) -> None:
        """Initialize the estimator with initial parameters and covariance."""
        pass
    
    @abstractmethod
    def update(self, measurement: np.ndarray, regressor: np.ndarray) -> EstimationResult:
        """
        Update parameter estimates with new measurement.
        
        Args:
            measurement: Output measurement vector (y)
            regressor: Input regressor matrix (phi)
            
        Returns:
            Updated estimation result
        """
        pass
    
    @abstractmethod
    def get_parameters(self) -> np.ndarray:
        """Get current parameter estimates."""
        pass
    
    @abstractmethod
    def get_covariance(self) -> np.ndarray:
        """Get current covariance matrix."""
        pass
    
    @abstractmethod
    def reset(self) -> None:
        """Reset the estimator to initial state."""
        pass


class BSIPCalculator(ABC):
    """
    Abstract base class for Body Segment Inertial Parameter calculators.
    Based on de Leva (1996), Dumas (2007) methods.
    """
    
    @abstractmethod
    def calculate(
        self, 
        body_mass: float, 
        segment_length: float,
        gender: Gender
    ) -> BSIPResult:
        """
        Calculate BSIP for a segment.
        
        Args:
            body_mass: Total body mass (kg)
            segment_length: Length of the segment (m)
            gender: Patient gender for coefficient selection
            
        Returns:
            BSIPResult with mass, COM, inertia values
        """
        pass
    
    @abstractmethod
    def get_coefficients(self, gender: Gender) -> Dict[str, float]:
        """Get the BSIP coefficients for the given gender."""
        pass


class FatigueDetector(ABC):
    """
    Abstract base class for fatigue detection algorithms.
    """
    
    @abstractmethod
    def initialize(self, baseline_data: Dict[str, Any]) -> None:
        """Initialize detector with baseline measurements."""
        pass
    
    @abstractmethod
    def update(self, current_data: Dict[str, Any]) -> FatigueIndicators:
        """Update fatigue indicators with current data."""
        pass
    
    @abstractmethod
    def get_fatigue_level(self) -> FatigueLevel:
        """Get current fatigue level classification."""
        pass
    
    @abstractmethod
    def should_pause(self) -> bool:
        """Check if session should be paused due to fatigue."""
        pass
    
    @abstractmethod
    def reset(self) -> None:
        """Reset the detector for a new session."""
        pass


class ExerciseProtocolBase(ABC):
    """
    Abstract base class for exercise protocols.
    """
    
    @abstractmethod
    def get_exercises(self) -> List['Exercise']:
        """Get list of exercises in the protocol."""
        pass
    
    @abstractmethod
    def get_current_exercise(self) -> Optional['Exercise']:
        """Get the current exercise."""
        pass
    
    @abstractmethod
    def advance(self) -> bool:
        """Advance to next exercise. Returns False if protocol complete."""
        pass
    
    @abstractmethod
    def get_progress(self) -> float:
        """Get protocol completion progress (0.0 to 1.0)."""
        pass
    
    @abstractmethod
    def modify_for_fatigue(self, fatigue_level: FatigueLevel) -> None:
        """Modify protocol parameters based on fatigue level."""
        pass


class RobotInterface(ABC):
    """
    Abstract base class for robot communication interface.
    """
    
    @abstractmethod
    def connect(self) -> bool:
        """Establish connection to robot. Returns success status."""
        pass
    
    @abstractmethod
    def disconnect(self) -> None:
        """Disconnect from robot."""
        pass
    
    @abstractmethod
    def is_connected(self) -> bool:
        """Check if robot is connected."""
        pass
    
    @abstractmethod
    def get_master_state(self) -> ArmState:
        """Get current state of master arm (sound arm)."""
        pass
    
    @abstractmethod
    def get_follower_state(self) -> ArmState:
        """Get current state of follower arm (paretic arm)."""
        pass
    
    @abstractmethod
    def send_torque_command(self, command: TorqueCommand) -> bool:
        """Send torque command to follower arm."""
        pass
    
    @abstractmethod
    def emergency_stop(self) -> None:
        """Trigger emergency stop."""
        pass
    
    @abstractmethod
    def calibrate(self) -> bool:
        """Perform robot calibration."""
        pass


# ==================== Repository Pattern ====================

class Repository(ABC, Generic[EntityT]):
    """
    Abstract repository for data access.
    Implements Repository pattern for clean data layer separation.
    """
    
    @abstractmethod
    def get_by_id(self, entity_id: str) -> Optional[EntityT]:
        """Get entity by ID."""
        pass
    
    @abstractmethod
    def get_all(self) -> List[EntityT]:
        """Get all entities."""
        pass
    
    @abstractmethod
    def add(self, entity: EntityT) -> EntityT:
        """Add new entity."""
        pass
    
    @abstractmethod
    def update(self, entity: EntityT) -> EntityT:
        """Update existing entity."""
        pass
    
    @abstractmethod
    def delete(self, entity_id: str) -> bool:
        """Delete entity by ID."""
        pass
    
    @abstractmethod
    def exists(self, entity_id: str) -> bool:
        """Check if entity exists."""
        pass


# ==================== Observer Pattern ====================

class SessionObserver(ABC):
    """
    Observer interface for session events.
    Implementations can react to session state changes.
    """
    
    @abstractmethod
    def on_session_started(self, session_id: str) -> None:
        """Called when session starts."""
        pass
    
    @abstractmethod
    def on_exercise_changed(self, exercise_id: str) -> None:
        """Called when current exercise changes."""
        pass
    
    @abstractmethod
    def on_fatigue_detected(self, fatigue_level: FatigueLevel) -> None:
        """Called when significant fatigue is detected."""
        pass
    
    @abstractmethod
    def on_session_paused(self, reason: str) -> None:
        """Called when session is paused."""
        pass
    
    @abstractmethod
    def on_session_completed(self, session_id: str) -> None:
        """Called when session completes."""
        pass
    
    @abstractmethod
    def on_emergency_stop(self, reason: str) -> None:
        """Called when emergency stop is triggered."""
        pass


# ==================== Protocol (Structural Typing) ====================

class Authenticatable(Protocol):
    """Protocol for objects that can be authenticated."""
    
    def verify_password(self, password: str) -> bool:
        """Verify password matches."""
        ...
    
    def get_role(self) -> UserRole:
        """Get user role."""
        ...
    
    def get_permissions(self) -> List[Permission]:
        """Get user permissions."""
        ...


class Serializable(Protocol):
    """Protocol for objects that can be serialized."""
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        ...
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Serializable':
        """Create from dictionary."""
        ...
