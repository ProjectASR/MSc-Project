"""
Custom exceptions for the Bimanual Tele-Rehabilitation Robot System.
"""


class BimanualRobotError(Exception):
    """Base exception for all system errors."""
    pass


# ==================== Patient Exceptions ====================

class PatientError(BimanualRobotError):
    """Base exception for patient-related errors."""
    pass


class PatientNotFoundError(PatientError):
    """Raised when a patient cannot be found."""
    def __init__(self, patient_id: str):
        self.patient_id = patient_id
        super().__init__(f"Patient with ID '{patient_id}' not found.")


class InvalidAnthropometricDataError(PatientError):
    """Raised when anthropometric data is invalid."""
    def __init__(self, message: str, field: str = None):
        self.field = field
        super().__init__(f"Invalid anthropometric data{f' for {field}' if field else ''}: {message}")


# ==================== Estimation Exceptions ====================

class EstimationError(BimanualRobotError):
    """Base exception for estimation-related errors."""
    pass


class InsufficientDataError(EstimationError):
    """Raised when there's not enough data for estimation."""
    def __init__(self, required: int, available: int):
        self.required = required
        self.available = available
        super().__init__(
            f"Insufficient data for estimation. Required: {required}, Available: {available}"
        )


class ConvergenceError(EstimationError):
    """Raised when estimation algorithm fails to converge."""
    def __init__(self, iterations: int, tolerance: float):
        self.iterations = iterations
        self.tolerance = tolerance
        super().__init__(
            f"Estimation failed to converge after {iterations} iterations "
            f"with tolerance {tolerance}"
        )


class SingularMatrixError(EstimationError):
    """Raised when a matrix operation encounters singularity."""
    def __init__(self, operation: str = "inversion"):
        self.operation = operation
        super().__init__(f"Singular matrix encountered during {operation}")


# ==================== Protocol Exceptions ====================

class ProtocolError(BimanualRobotError):
    """Base exception for protocol-related errors."""
    pass


class InvalidProtocolError(ProtocolError):
    """Raised when a protocol configuration is invalid."""
    pass


class ProtocolNotFoundError(ProtocolError):
    """Raised when a protocol cannot be found."""
    def __init__(self, protocol_id: str):
        self.protocol_id = protocol_id
        super().__init__(f"Protocol with ID '{protocol_id}' not found.")


class ExerciseConstraintError(ProtocolError):
    """Raised when exercise parameters violate constraints."""
    def __init__(self, parameter: str, value: float, constraint: str):
        self.parameter = parameter
        self.value = value
        self.constraint = constraint
        super().__init__(
            f"Exercise constraint violated: {parameter}={value} does not satisfy {constraint}"
        )


# ==================== Session Exceptions ====================

class SessionError(BimanualRobotError):
    """Base exception for session-related errors."""
    pass


class SessionNotFoundError(SessionError):
    """Raised when a session cannot be found."""
    def __init__(self, session_id: str):
        self.session_id = session_id
        super().__init__(f"Session with ID '{session_id}' not found.")


class SessionStateError(SessionError):
    """Raised when a session operation is invalid for current state."""
    def __init__(self, current_state: str, attempted_operation: str):
        self.current_state = current_state
        self.attempted_operation = attempted_operation
        super().__init__(
            f"Cannot perform '{attempted_operation}' while session is in '{current_state}' state."
        )


# ==================== Robot Exceptions ====================

class RobotError(BimanualRobotError):
    """Base exception for robot-related errors."""
    pass


class RobotConnectionError(RobotError):
    """Raised when robot connection fails."""
    def __init__(self, port: str = None, message: str = None):
        self.port = port
        msg = f"Failed to connect to robot"
        if port:
            msg += f" on port {port}"
        if message:
            msg += f": {message}"
        super().__init__(msg)


class RobotCommunicationError(RobotError):
    """Raised when robot communication fails."""
    pass


class EmergencyStopError(RobotError):
    """Raised when emergency stop is triggered."""
    def __init__(self, reason: str = "Unknown"):
        self.reason = reason
        super().__init__(f"Emergency stop triggered: {reason}")


class RobotCalibrationError(RobotError):
    """Raised when robot calibration fails."""
    pass


class TorqueLimitExceededError(RobotError):
    """Raised when torque exceeds safety limits."""
    def __init__(self, joint: str, torque: float, limit: float):
        self.joint = joint
        self.torque = torque
        self.limit = limit
        super().__init__(
            f"Torque limit exceeded for {joint}: {torque:.2f} Nm > {limit:.2f} Nm"
        )


# ==================== Authentication Exceptions ====================

class AuthenticationError(BimanualRobotError):
    """Base exception for authentication errors."""
    pass


class InvalidCredentialsError(AuthenticationError):
    """Raised when credentials are invalid."""
    def __init__(self):
        super().__init__("Invalid username or password.")


class UnauthorizedAccessError(AuthenticationError):
    """Raised when user lacks permission."""
    def __init__(self, permission: str, user_role: str):
        self.permission = permission
        self.user_role = user_role
        super().__init__(
            f"User with role '{user_role}' does not have permission '{permission}'."
        )


class SessionExpiredError(AuthenticationError):
    """Raised when user session has expired."""
    def __init__(self):
        super().__init__("User session has expired. Please log in again.")


# ==================== Data Exceptions ====================

class DataError(BimanualRobotError):
    """Base exception for data-related errors."""
    pass


class DatabaseConnectionError(DataError):
    """Raised when database connection fails."""
    def __init__(self, database: str = None, message: str = None):
        self.database = database
        msg = "Database connection failed"
        if database:
            msg += f" for {database}"
        if message:
            msg += f": {message}"
        super().__init__(msg)


class DataValidationError(DataError):
    """Raised when data validation fails."""
    def __init__(self, field: str, value, reason: str):
        self.field = field
        self.value = value
        self.reason = reason
        super().__init__(f"Validation failed for '{field}': {reason}")


class CloudSyncError(DataError):
    """Raised when cloud synchronization fails."""
    pass


# ==================== Fatigue Detection Exceptions ====================

class FatigueError(BimanualRobotError):
    """Base exception for fatigue detection errors."""
    pass


class FatigueThresholdExceededError(FatigueError):
    """Raised when fatigue exceeds acceptable threshold."""
    def __init__(self, fatigue_level: int, threshold: int):
        self.fatigue_level = fatigue_level
        self.threshold = threshold
        super().__init__(
            f"Fatigue level ({fatigue_level}) exceeded threshold ({threshold}). "
            "Session should be paused."
        )
