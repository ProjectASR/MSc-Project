"""
Core enumerations for the Bimanual Tele-Rehabilitation Robot System.
"""
from enum import Enum, auto


class Gender(Enum):
    """Patient gender for BSIP calculations."""
    MALE = auto()
    FEMALE = auto()


class AffectedSide(Enum):
    """Side affected by stroke."""
    LEFT = auto()
    RIGHT = auto()
    BILATERAL = auto()


class ArmSegment(Enum):
    """Upper limb segments."""
    UPPER_ARM = auto()
    FOREARM = auto()
    HAND = auto()


class JointType(Enum):
    """Joint types for the bimanual robot."""
    SHOULDER_INTERNAL_ROTATION = auto()
    SHOULDER_EXTERNAL_ROTATION = auto()
    ELBOW_FLEXION = auto()
    ELBOW_EXTENSION = auto()


class ExerciseType(Enum):
    """Types of rehabilitation exercises."""
    ELBOW_FLEXION_EXTENSION = auto()
    SHOULDER_ROTATION = auto()
    BIMANUAL_SYMMETRIC = auto()
    BIMANUAL_ASYMMETRIC = auto()


class ExerciseMode(Enum):
    """Exercise control modes."""
    PASSIVE = auto()          # Robot moves the arm
    ACTIVE_ASSISTED = auto()  # Robot assists patient movement
    ACTIVE = auto()           # Patient moves, robot monitors
    RESISTIVE = auto()        # Robot provides resistance


class SessionStatus(Enum):
    """Rehabilitation session status."""
    SCHEDULED = auto()
    IN_PROGRESS = auto()
    COMPLETED = auto()
    CANCELLED = auto()
    PAUSED = auto()


class FatigueLevel(Enum):
    """Fatigue severity levels."""
    NONE = 0
    MILD = 1
    MODERATE = 2
    SEVERE = 3
    CRITICAL = 4


class UserRole(Enum):
    """User roles for access control."""
    ADMIN = auto()
    DOCTOR = auto()
    PHYSIOTHERAPIST = auto()
    CAREGIVER = auto()
    PATIENT = auto()


class Permission(Enum):
    """System permissions."""
    # Patient management
    VIEW_PATIENTS = auto()
    CREATE_PATIENT = auto()
    EDIT_PATIENT = auto()
    DELETE_PATIENT = auto()
    
    # Protocol management
    VIEW_PROTOCOLS = auto()
    CREATE_PROTOCOL = auto()
    EDIT_PROTOCOL = auto()
    DELETE_PROTOCOL = auto()
    ASSIGN_PROTOCOL = auto()
    
    # Session management
    VIEW_SESSIONS = auto()
    START_SESSION = auto()
    CONTROL_SESSION = auto()
    END_SESSION = auto()
    
    # Parameter management
    VIEW_PARAMETERS = auto()
    EDIT_PARAMETERS = auto()
    CALIBRATE_SYSTEM = auto()
    
    # Data access
    VIEW_REPORTS = auto()
    EXPORT_DATA = auto()
    VIEW_ANALYTICS = auto()
    
    # System administration
    MANAGE_USERS = auto()
    SYSTEM_CONFIG = auto()


class EstimationMethod(Enum):
    """Parameter estimation methods."""
    RLS = auto()              # Recursive Least Squares
    FFRLS = auto()            # Forgetting Factor RLS
    KALMAN = auto()           # Kalman Filter
    SALS = auto()             # Slide Average Least Squares


class BSIPMethod(Enum):
    """Body Segment Inertial Parameter calculation methods."""
    DE_LEVA_1996 = auto()
    DUMAS_2007 = auto()
    ZATSIORSKY_SELUYANOV = auto()


class RobotState(Enum):
    """Robot operational states."""
    DISCONNECTED = auto()
    INITIALIZING = auto()
    READY = auto()
    OPERATING = auto()
    EMERGENCY_STOP = auto()
    ERROR = auto()
    CALIBRATING = auto()
