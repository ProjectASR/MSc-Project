"""
Parameter Estimation Algorithms for Adaptive Torque Modeling.

Implements:
- Recursive Least Squares (RLS)
- Forgetting Factor Recursive Least Squares (FFRLS)

Based on:
- "Research on adaptive impedance control technology of upper limb rehabilitation 
   robot based on impedance parameter prediction" (Frontiers 2023)
- Standard system identification literature

These estimators are used to adaptively estimate arm impedance parameters
(stiffness, damping, inertia) during rehabilitation exercises.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Tuple, List
import numpy as np
from numpy.linalg import inv, LinAlgError

from core.base import ParameterEstimator, EstimationResult
from core.enums import EstimationMethod
from core.exceptions import (
    InsufficientDataError, 
    SingularMatrixError, 
    ConvergenceError
)


@dataclass
class RLSConfig:
    """Configuration for RLS estimator."""
    num_parameters: int
    initial_covariance: float = 1000.0  # Large initial uncertainty
    regularization: float = 1e-6        # For numerical stability


@dataclass 
class FFRLSConfig(RLSConfig):
    """Configuration for FFRLS estimator."""
    forgetting_factor: float = 0.98     # λ ∈ (0.95, 0.99) typical
    min_forgetting_factor: float = 0.90
    max_forgetting_factor: float = 0.999
    adaptive_forgetting: bool = False   # Enable adaptive λ


class RLSEstimator(ParameterEstimator):
    """
    Recursive Least Squares (RLS) Parameter Estimator.
    
    Standard RLS algorithm for online parameter estimation:
    
    θ̂(k) = θ̂(k-1) + K(k)[y(k) - φᵀ(k)θ̂(k-1)]
    K(k) = P(k-1)φ(k)[1 + φᵀ(k)P(k-1)φ(k)]⁻¹
    P(k) = P(k-1) - K(k)φᵀ(k)P(k-1)
    
    Where:
    - θ̂: Parameter estimate vector
    - K: Kalman gain
    - P: Covariance matrix
    - φ: Regressor vector
    - y: Measurement
    """
    
    def __init__(self, config: RLSConfig):
        """
        Initialize RLS estimator.
        
        Args:
            config: RLS configuration
        """
        self.config = config
        self.method = EstimationMethod.RLS
        
        # State variables
        self._theta: Optional[np.ndarray] = None  # Parameter estimates
        self._P: Optional[np.ndarray] = None      # Covariance matrix
        self._initialized = False
        self._iteration = 0
        
        # History for analysis
        self._theta_history: List[np.ndarray] = []
        self._error_history: List[float] = []
    
    def initialize(
        self, 
        initial_params: np.ndarray, 
        initial_covariance: Optional[np.ndarray] = None
    ) -> None:
        """
        Initialize the estimator.
        
        Args:
            initial_params: Initial parameter estimate vector
            initial_covariance: Initial covariance matrix (optional)
        """
        n = len(initial_params)
        
        if n != self.config.num_parameters:
            raise ValueError(
                f"Initial params size ({n}) doesn't match config ({self.config.num_parameters})"
            )
        
        self._theta = initial_params.copy().astype(float)
        
        if initial_covariance is not None:
            self._P = initial_covariance.copy()
        else:
            # Initialize with large covariance (high uncertainty)
            self._P = self.config.initial_covariance * np.eye(n)
        
        # Add small regularization for numerical stability
        self._P += self.config.regularization * np.eye(n)
        
        self._initialized = True
        self._iteration = 0
        self._theta_history = [self._theta.copy()]
        self._error_history = []
    
    def update(
        self, 
        measurement: np.ndarray, 
        regressor: np.ndarray
    ) -> EstimationResult:
        """
        Update parameter estimates with new measurement.
        
        Implements standard RLS update equations.
        
        Args:
            measurement: Output measurement y (scalar or vector)
            regressor: Regressor vector φ
            
        Returns:
            EstimationResult with updated parameters
        """
        if not self._initialized:
            raise RuntimeError("Estimator not initialized. Call initialize() first.")
        
        # Ensure proper shapes
        y = np.atleast_1d(measurement).flatten()
        phi = np.atleast_1d(regressor).flatten()
        
        if len(phi) != self.config.num_parameters:
            raise ValueError(
                f"Regressor size ({len(phi)}) doesn't match parameters ({self.config.num_parameters})"
            )
        
        try:
            # Prediction error
            y_pred = phi @ self._theta
            error = y - y_pred
            
            # Kalman gain: K = Pφ / (1 + φᵀPφ)
            P_phi = self._P @ phi
            denominator = 1.0 + phi @ P_phi
            K = P_phi / denominator
            
            # Parameter update: θ = θ + K * error
            self._theta = self._theta + K * error[0] if len(error) == 1 else self._theta + K @ error
            
            # Covariance update: P = P - KφᵀP
            self._P = self._P - np.outer(K, phi @ self._P)
            
            # Ensure symmetry and positive definiteness
            self._P = (self._P + self._P.T) / 2
            self._P += self.config.regularization * np.eye(self.config.num_parameters)
            
            self._iteration += 1
            self._theta_history.append(self._theta.copy())
            self._error_history.append(float(np.mean(error**2)))
            
            # Calculate confidence based on covariance trace
            confidence = 1.0 / (1.0 + np.trace(self._P))
            
            return EstimationResult(
                parameters=self._theta.copy(),
                covariance=self._P.copy(),
                confidence=confidence,
                iterations=self._iteration,
                converged=self._check_convergence(),
                metadata={
                    'method': 'RLS',
                    'error': float(np.mean(error**2)),
                    'kalman_gain_norm': float(np.linalg.norm(K)),
                }
            )
            
        except LinAlgError as e:
            raise SingularMatrixError(f"Matrix operation failed: {e}")
    
    def _check_convergence(self, tolerance: float = 1e-6) -> bool:
        """Check if estimates have converged."""
        if len(self._theta_history) < 2:
            return False
        
        delta = np.linalg.norm(
            self._theta_history[-1] - self._theta_history[-2]
        )
        return delta < tolerance
    
    def get_parameters(self) -> np.ndarray:
        """Get current parameter estimates."""
        if self._theta is None:
            raise RuntimeError("Estimator not initialized")
        return self._theta.copy()
    
    def get_covariance(self) -> np.ndarray:
        """Get current covariance matrix."""
        if self._P is None:
            raise RuntimeError("Estimator not initialized")
        return self._P.copy()
    
    def reset(self) -> None:
        """Reset to uninitialized state."""
        self._theta = None
        self._P = None
        self._initialized = False
        self._iteration = 0
        self._theta_history = []
        self._error_history = []
    
    def get_parameter_history(self) -> np.ndarray:
        """Get history of parameter estimates."""
        return np.array(self._theta_history)
    
    def get_error_history(self) -> np.ndarray:
        """Get history of estimation errors."""
        return np.array(self._error_history)


class FFRLSEstimator(ParameterEstimator):
    """
    Forgetting Factor Recursive Least Squares (FFRLS) Estimator.
    
    Extends RLS with exponential forgetting to track time-varying parameters.
    This is essential for rehabilitation where patient's arm impedance 
    changes due to fatigue, motor learning, and recovery.
    
    Algorithm (from Frontiers 2023 paper):
    
    θ̂(k) = θ̂(k-1) + K(k)[y(k) - φᵀ(k)θ̂(k-1)]
    K(k) = P(k-1)φ(k)[λ + φᵀ(k)P(k-1)φ(k)]⁻¹
    P(k) = (1/λ)[P(k-1) - K(k)φᵀ(k)P(k-1)]
    
    Where λ is the forgetting factor (0.95-0.99 typical).
    - λ close to 1: Slow adaptation, good for steady-state
    - λ close to 0.95: Fast adaptation, good for tracking changes
    """
    
    def __init__(self, config: FFRLSConfig):
        """
        Initialize FFRLS estimator.
        
        Args:
            config: FFRLS configuration with forgetting factor
        """
        self.config = config
        self.method = EstimationMethod.FFRLS
        
        # Validate forgetting factor
        if not (0 < config.forgetting_factor <= 1):
            raise ValueError("Forgetting factor must be in (0, 1]")
        
        self._lambda = config.forgetting_factor
        
        # State variables
        self._theta: Optional[np.ndarray] = None
        self._P: Optional[np.ndarray] = None
        self._initialized = False
        self._iteration = 0
        
        # History
        self._theta_history: List[np.ndarray] = []
        self._error_history: List[float] = []
        self._lambda_history: List[float] = []
        
        # For adaptive forgetting
        self._innovation_history: List[float] = []
    
    def initialize(
        self, 
        initial_params: np.ndarray, 
        initial_covariance: Optional[np.ndarray] = None
    ) -> None:
        """Initialize the FFRLS estimator."""
        n = len(initial_params)
        
        if n != self.config.num_parameters:
            raise ValueError(
                f"Initial params size ({n}) doesn't match config ({self.config.num_parameters})"
            )
        
        self._theta = initial_params.copy().astype(float)
        
        if initial_covariance is not None:
            self._P = initial_covariance.copy()
        else:
            self._P = self.config.initial_covariance * np.eye(n)
        
        self._P += self.config.regularization * np.eye(n)
        
        self._lambda = self.config.forgetting_factor
        self._initialized = True
        self._iteration = 0
        self._theta_history = [self._theta.copy()]
        self._error_history = []
        self._lambda_history = [self._lambda]
        self._innovation_history = []
    
    def update(
        self, 
        measurement: np.ndarray, 
        regressor: np.ndarray
    ) -> EstimationResult:
        """
        Update parameters using FFRLS algorithm.
        
        Args:
            measurement: Output measurement y
            regressor: Regressor vector φ
            
        Returns:
            EstimationResult with updated parameters
        """
        if not self._initialized:
            raise RuntimeError("Estimator not initialized")
        
        y = np.atleast_1d(measurement).flatten()
        phi = np.atleast_1d(regressor).flatten()
        
        if len(phi) != self.config.num_parameters:
            raise ValueError(f"Regressor size mismatch")
        
        try:
            # Prediction and innovation (error)
            y_pred = phi @ self._theta
            innovation = y - y_pred
            
            # Store for adaptive forgetting
            self._innovation_history.append(float(innovation[0] if len(innovation) > 0 else innovation))
            
            # Adaptive forgetting factor (optional)
            if self.config.adaptive_forgetting:
                self._lambda = self._adapt_forgetting_factor()
            
            # FFRLS Kalman gain: K = Pφ / (λ + φᵀPφ)
            P_phi = self._P @ phi
            denominator = self._lambda + phi @ P_phi
            K = P_phi / denominator
            
            # Parameter update
            error_scalar = innovation[0] if len(innovation) == 1 else np.mean(innovation)
            self._theta = self._theta + K * error_scalar
            
            # Covariance update with forgetting: P = (1/λ)(P - KφᵀP)
            self._P = (1.0 / self._lambda) * (self._P - np.outer(K, phi @ self._P))
            
            # Ensure numerical stability
            self._P = (self._P + self._P.T) / 2
            
            # Covariance limiting to prevent blow-up
            max_cov = self.config.initial_covariance * 10
            if np.trace(self._P) > max_cov * self.config.num_parameters:
                self._P = max_cov * np.eye(self.config.num_parameters)
            
            self._P += self.config.regularization * np.eye(self.config.num_parameters)
            
            self._iteration += 1
            self._theta_history.append(self._theta.copy())
            self._error_history.append(float(np.mean(innovation**2)))
            self._lambda_history.append(self._lambda)
            
            confidence = 1.0 / (1.0 + np.trace(self._P))
            
            return EstimationResult(
                parameters=self._theta.copy(),
                covariance=self._P.copy(),
                confidence=confidence,
                iterations=self._iteration,
                converged=self._check_convergence(),
                metadata={
                    'method': 'FFRLS',
                    'forgetting_factor': self._lambda,
                    'error': float(np.mean(innovation**2)),
                    'kalman_gain_norm': float(np.linalg.norm(K)),
                }
            )
            
        except LinAlgError as e:
            raise SingularMatrixError(f"Matrix operation failed: {e}")
    
    def _adapt_forgetting_factor(self) -> float:
        """
        Adaptively adjust forgetting factor based on innovation.
        
        When prediction errors increase, reduce λ for faster adaptation.
        When errors are stable, increase λ for smoother estimates.
        """
        if len(self._innovation_history) < 10:
            return self._lambda
        
        recent_var = np.var(self._innovation_history[-10:])
        older_var = np.var(self._innovation_history[-20:-10]) if len(self._innovation_history) >= 20 else recent_var
        
        if recent_var > 1.5 * older_var:
            # Errors increasing - reduce lambda for faster tracking
            new_lambda = max(
                self.config.min_forgetting_factor,
                self._lambda - 0.01
            )
        elif recent_var < 0.5 * older_var:
            # Errors decreasing - increase lambda for stability
            new_lambda = min(
                self.config.max_forgetting_factor,
                self._lambda + 0.005
            )
        else:
            new_lambda = self._lambda
        
        return new_lambda
    
    def _check_convergence(self, tolerance: float = 1e-6) -> bool:
        """Check parameter convergence."""
        if len(self._theta_history) < 2:
            return False
        delta = np.linalg.norm(self._theta_history[-1] - self._theta_history[-2])
        return delta < tolerance
    
    def get_parameters(self) -> np.ndarray:
        if self._theta is None:
            raise RuntimeError("Estimator not initialized")
        return self._theta.copy()
    
    def get_covariance(self) -> np.ndarray:
        if self._P is None:
            raise RuntimeError("Estimator not initialized")
        return self._P.copy()
    
    def get_forgetting_factor(self) -> float:
        """Get current forgetting factor."""
        return self._lambda
    
    def set_forgetting_factor(self, lambda_: float) -> None:
        """
        Manually set forgetting factor.
        
        Args:
            lambda_: New forgetting factor in (0, 1]
        """
        if not (0 < lambda_ <= 1):
            raise ValueError("Forgetting factor must be in (0, 1]")
        self._lambda = lambda_
    
    def reset(self) -> None:
        """Reset estimator."""
        self._theta = None
        self._P = None
        self._initialized = False
        self._iteration = 0
        self._lambda = self.config.forgetting_factor
        self._theta_history = []
        self._error_history = []
        self._lambda_history = []
        self._innovation_history = []
    
    def get_parameter_history(self) -> np.ndarray:
        return np.array(self._theta_history)
    
    def get_error_history(self) -> np.ndarray:
        return np.array(self._error_history)
    
    def get_forgetting_factor_history(self) -> np.ndarray:
        return np.array(self._lambda_history)


# ==================== Factory Functions ====================

def create_rls_estimator(
    num_parameters: int,
    initial_covariance: float = 1000.0,
) -> RLSEstimator:
    """Create a standard RLS estimator."""
    config = RLSConfig(
        num_parameters=num_parameters,
        initial_covariance=initial_covariance,
    )
    return RLSEstimator(config)


def create_ffrls_estimator(
    num_parameters: int,
    forgetting_factor: float = 0.98,
    initial_covariance: float = 1000.0,
    adaptive: bool = False,
) -> FFRLSEstimator:
    """
    Create a FFRLS estimator.
    
    Args:
        num_parameters: Number of parameters to estimate
        forgetting_factor: λ value (0.95-0.99 recommended)
        initial_covariance: Initial uncertainty level
        adaptive: Enable adaptive forgetting factor
    
    Returns:
        Configured FFRLSEstimator
    """
    config = FFRLSConfig(
        num_parameters=num_parameters,
        forgetting_factor=forgetting_factor,
        initial_covariance=initial_covariance,
        adaptive_forgetting=adaptive,
    )
    return FFRLSEstimator(config)


# ==================== Arm Impedance Estimator ====================

class ArmImpedanceEstimator:
    """
    High-level estimator for arm impedance parameters.
    
    Estimates the parameters of the arm impedance model:
    τ = J*θ̈ + B*θ̇ + K*θ
    
    Where:
    - J: Inertia (kg·m²)
    - B: Damping (Nm·s/rad)
    - K: Stiffness (Nm/rad)
    
    Uses FFRLS for online adaptation during rehabilitation.
    """
    
    def __init__(
        self,
        forgetting_factor: float = 0.98,
        initial_inertia: float = 0.1,
        initial_damping: float = 1.0,
        initial_stiffness: float = 10.0,
    ):
        """
        Initialize arm impedance estimator.
        
        Args:
            forgetting_factor: FFRLS forgetting factor
            initial_inertia: Initial inertia estimate (kg·m²)
            initial_damping: Initial damping estimate (Nm·s/rad)
            initial_stiffness: Initial stiffness estimate (Nm/rad)
        """
        self._estimator = create_ffrls_estimator(
            num_parameters=3,
            forgetting_factor=forgetting_factor,
            adaptive=True,
        )
        
        self._initial_params = np.array([
            initial_inertia,
            initial_damping, 
            initial_stiffness
        ])
        
        self._estimator.initialize(self._initial_params)
    
    def update(
        self,
        torque: float,
        position: float,
        velocity: float,
        acceleration: float,
    ) -> dict:
        """
        Update impedance estimates with new measurement.
        
        The model is: τ = J*θ̈ + B*θ̇ + K*θ
        
        Rearranging for RLS: τ = [θ̈, θ̇, θ] @ [J, B, K]ᵀ
        
        Args:
            torque: Measured joint torque (Nm)
            position: Joint position (rad)
            velocity: Joint velocity (rad/s)
            acceleration: Joint acceleration (rad/s²)
            
        Returns:
            Dict with estimated inertia, damping, stiffness
        """
        # Construct regressor: φ = [θ̈, θ̇, θ]
        regressor = np.array([acceleration, velocity, position])
        
        # Measurement is torque
        result = self._estimator.update(
            measurement=np.array([torque]),
            regressor=regressor,
        )
        
        params = result.parameters
        
        return {
            'inertia': max(0.001, params[0]),      # Ensure positive
            'damping': max(0.0, params[1]),        # Non-negative
            'stiffness': max(0.0, params[2]),      # Non-negative
            'confidence': result.confidence,
            'converged': result.converged,
        }
    
    def get_parameters(self) -> dict:
        """Get current impedance parameters."""
        params = self._estimator.get_parameters()
        return {
            'inertia': max(0.001, params[0]),
            'damping': max(0.0, params[1]),
            'stiffness': max(0.0, params[2]),
        }
    
    def reset(self) -> None:
        """Reset to initial state."""
        self._estimator.reset()
        self._estimator.initialize(self._initial_params)
