"""
Human Arm Dynamics Model for Torque Profile Calculation.

Implements 2-DOF planar arm dynamics using Lagrangian-Euler formulation:
τ = M(q)q̈ + C(q,q̇)q̇ + G(q)

Based on:
- Koike & Kawato (1995) - Estimation of dynamic joint torques
- IEEE 2008 - Modeling and dynamics of human arm

This model is used to:
1. Calculate required joint torques for desired movements
2. Serve as the command generator for the bimanual robot
3. Provide baseline for parameter estimation
"""
from dataclasses import dataclass, field
from typing import Dict, Tuple, Optional, List
import numpy as np
from numpy import sin, cos

from core.base import BSIPResult, TorqueCommand
from core.enums import ArmSegment, Gender


@dataclass
class ArmDynamicsParameters:
    """
    Parameters for 2-DOF arm dynamics model.
    
    Coordinate system:
    - q1: Shoulder angle (internal/external rotation or flexion)
    - q2: Elbow angle (flexion/extension)
    - Positive direction: Counter-clockwise when viewed from above
    """
    # Link 1: Upper arm
    m1: float          # Mass (kg)
    l1: float          # Length (m)
    lc1: float         # COM distance from shoulder (m)
    I1: float          # Moment of inertia about COM (kg·m²)
    
    # Link 2: Forearm + Hand
    m2: float          # Mass (kg)
    l2: float          # Length (m)
    lc2: float         # COM distance from elbow (m)
    I2: float          # Moment of inertia about COM (kg·m²)
    
    # Gravity
    g: float = 9.81    # m/s²
    
    # Viscous friction coefficients (optional)
    b1: float = 0.0    # Shoulder friction (Nm·s/rad)
    b2: float = 0.0    # Elbow friction (Nm·s/rad)
    
    def __post_init__(self):
        """Validate parameters."""
        if self.m1 <= 0 or self.m2 <= 0:
            raise ValueError("Masses must be positive")
        if self.l1 <= 0 or self.l2 <= 0:
            raise ValueError("Lengths must be positive")
        if self.I1 <= 0 or self.I2 <= 0:
            raise ValueError("Inertias must be positive")
    
    @classmethod
    def from_bsip(
        cls,
        upper_arm: BSIPResult,
        forearm_hand: BSIPResult,
        gravity: float = 9.81,
    ) -> 'ArmDynamicsParameters':
        """Create parameters from BSIP calculation results."""
        return cls(
            m1=upper_arm.mass,
            l1=upper_arm.length,
            lc1=upper_arm.com_position,
            I1=upper_arm.inertia_zz,
            m2=forearm_hand.mass,
            l2=forearm_hand.length,
            lc2=forearm_hand.com_position,
            I2=forearm_hand.inertia_zz,
            g=gravity,
        )


class PlanarArmDynamics:
    """
    2-DOF Planar Arm Dynamics Model.
    
    Computes inverse dynamics: Given motion (q, q̇, q̈), compute required torques τ.
    
    Equations of motion (Lagrangian formulation):
    τ = M(q)q̈ + C(q,q̇)q̇ + G(q) + F(q̇)
    
    Where:
    - M(q): 2×2 inertia matrix
    - C(q,q̇): 2×2 Coriolis/centrifugal matrix
    - G(q): 2×1 gravity vector
    - F(q̇): 2×1 friction vector
    
    Configuration:
    - Arm in vertical plane (for elbow flexion/extension)
    - Or arm in horizontal plane (for shoulder rotation)
    """
    
    def __init__(
        self,
        params: ArmDynamicsParameters,
        include_gravity: bool = True,
        include_friction: bool = True,
    ):
        """
        Initialize arm dynamics model.
        
        Args:
            params: Arm dynamics parameters from BSIP
            include_gravity: Include gravity term in calculations
            include_friction: Include viscous friction
        """
        self.params = params
        self.include_gravity = include_gravity
        self.include_friction = include_friction
        
        # Pre-compute constant terms for efficiency
        self._precompute_constants()
    
    def _precompute_constants(self) -> None:
        """Pre-compute constant terms used in dynamics equations."""
        p = self.params
        
        # Constants for inertia matrix
        self._d1 = p.I1 + p.I2 + p.m1 * p.lc1**2 + p.m2 * (p.l1**2 + p.lc2**2)
        self._d2 = p.I2 + p.m2 * p.lc2**2
        self._d3 = p.m2 * p.l1 * p.lc2  # Coupling term
        
        # Constants for gravity (vertical plane)
        self._g1 = (p.m1 * p.lc1 + p.m2 * p.l1) * p.g
        self._g2 = p.m2 * p.lc2 * p.g
    
    def inertia_matrix(self, q: np.ndarray) -> np.ndarray:
        """
        Compute 2×2 inertia matrix M(q).
        
        M = [M11  M12]
            [M21  M22]
        
        Args:
            q: Joint angles [q1, q2] (rad)
            
        Returns:
            2×2 inertia matrix
        """
        q2 = q[1]
        c2 = cos(q2)
        
        M11 = self._d1 + 2 * self._d3 * c2
        M12 = self._d2 + self._d3 * c2
        M21 = M12  # Symmetric
        M22 = self._d2
        
        return np.array([[M11, M12], [M21, M22]])
    
    def coriolis_matrix(self, q: np.ndarray, q_dot: np.ndarray) -> np.ndarray:
        """
        Compute Coriolis and centrifugal matrix C(q,q̇).
        
        Using Christoffel symbols formulation.
        
        Args:
            q: Joint angles [q1, q2] (rad)
            q_dot: Joint velocities [q1_dot, q2_dot] (rad/s)
            
        Returns:
            2×2 Coriolis matrix
        """
        q2 = q[1]
        q1_dot, q2_dot = q_dot
        
        s2 = sin(q2)
        h = self._d3 * s2  # Velocity coupling term
        
        C11 = -h * q2_dot
        C12 = -h * (q1_dot + q2_dot)
        C21 = h * q1_dot
        C22 = 0.0
        
        return np.array([[C11, C12], [C21, C22]])
    
    def gravity_vector(self, q: np.ndarray) -> np.ndarray:
        """
        Compute gravity vector G(q).
        
        Assumes arm is in vertical plane with shoulder at origin.
        
        Args:
            q: Joint angles [q1, q2] (rad)
            
        Returns:
            2×1 gravity vector
        """
        if not self.include_gravity:
            return np.zeros(2)
        
        q1, q2 = q
        
        G1 = self._g1 * cos(q1) + self._g2 * cos(q1 + q2)
        G2 = self._g2 * cos(q1 + q2)
        
        return np.array([G1, G2])
    
    def friction_vector(self, q_dot: np.ndarray) -> np.ndarray:
        """
        Compute viscous friction vector F(q̇).
        
        Args:
            q_dot: Joint velocities (rad/s)
            
        Returns:
            2×1 friction vector
        """
        if not self.include_friction:
            return np.zeros(2)
        
        return np.array([
            self.params.b1 * q_dot[0],
            self.params.b2 * q_dot[1]
        ])
    
    def inverse_dynamics(
        self,
        q: np.ndarray,
        q_dot: np.ndarray,
        q_ddot: np.ndarray,
    ) -> np.ndarray:
        """
        Compute joint torques using inverse dynamics.
        
        τ = M(q)q̈ + C(q,q̇)q̇ + G(q) + F(q̇)
        
        Args:
            q: Joint angles [q1, q2] (rad)
            q_dot: Joint velocities [q1_dot, q2_dot] (rad/s)
            q_ddot: Joint accelerations [q1_ddot, q2_ddot] (rad/s²)
            
        Returns:
            Joint torques [τ1, τ2] (Nm)
        """
        M = self.inertia_matrix(q)
        C = self.coriolis_matrix(q, q_dot)
        G = self.gravity_vector(q)
        F = self.friction_vector(q_dot)
        
        tau = M @ q_ddot + C @ q_dot + G + F
        
        return tau
    
    def forward_dynamics(
        self,
        q: np.ndarray,
        q_dot: np.ndarray,
        tau: np.ndarray,
    ) -> np.ndarray:
        """
        Compute joint accelerations using forward dynamics.
        
        q̈ = M⁻¹(q)[τ - C(q,q̇)q̇ - G(q) - F(q̇)]
        
        Args:
            q: Joint angles (rad)
            q_dot: Joint velocities (rad/s)
            tau: Applied torques (Nm)
            
        Returns:
            Joint accelerations (rad/s²)
        """
        M = self.inertia_matrix(q)
        C = self.coriolis_matrix(q, q_dot)
        G = self.gravity_vector(q)
        F = self.friction_vector(q_dot)
        
        # q̈ = M⁻¹(τ - Cq̇ - G - F)
        M_inv = np.linalg.inv(M)
        q_ddot = M_inv @ (tau - C @ q_dot - G - F)
        
        return q_ddot
    
    def get_torque_command(
        self,
        q: np.ndarray,
        q_dot: np.ndarray,
        q_ddot: np.ndarray,
    ) -> TorqueCommand:
        """
        Get torque command for robot.
        
        Returns:
            TorqueCommand object
        """
        tau = self.inverse_dynamics(q, q_dot, q_ddot)
        
        return TorqueCommand(
            shoulder_torque=tau[0],
            elbow_torque=tau[1],
        )


class TorqueProfileGenerator:
    """
    Generates torque profiles for rehabilitation exercises.
    
    Creates time-series of required torques based on:
    1. Desired trajectory (position, velocity, acceleration)
    2. Patient-specific arm dynamics parameters
    
    Used to personalize the bimanual robot commands for each patient.
    """
    
    def __init__(
        self,
        dynamics: PlanarArmDynamics,
        sample_rate: float = 100.0,  # Hz
    ):
        """
        Initialize torque profile generator.
        
        Args:
            dynamics: Arm dynamics model with patient-specific parameters
            sample_rate: Sampling rate for trajectory (Hz)
        """
        self.dynamics = dynamics
        self.sample_rate = sample_rate
        self.dt = 1.0 / sample_rate
    
    def generate_sinusoidal_profile(
        self,
        joint: str,  # 'shoulder' or 'elbow'
        amplitude: float,  # rad
        frequency: float,  # Hz
        duration: float,  # seconds
        offset: float = 0.0,  # rad
    ) -> Dict[str, np.ndarray]:
        """
        Generate torque profile for sinusoidal motion.
        
        Useful for repetitive flexion/extension exercises.
        
        Args:
            joint: Which joint to move
            amplitude: Motion amplitude (rad)
            frequency: Motion frequency (Hz)
            duration: Exercise duration (s)
            offset: Angle offset (rad)
            
        Returns:
            Dict with time, position, velocity, acceleration, torque arrays
        """
        t = np.arange(0, duration, self.dt)
        omega = 2 * np.pi * frequency
        
        # Sinusoidal trajectory
        theta = amplitude * np.sin(omega * t) + offset
        theta_dot = amplitude * omega * np.cos(omega * t)
        theta_ddot = -amplitude * omega**2 * np.sin(omega * t)
        
        # Initialize arrays
        n_samples = len(t)
        tau_shoulder = np.zeros(n_samples)
        tau_elbow = np.zeros(n_samples)
        
        for i in range(n_samples):
            if joint == 'shoulder':
                q = np.array([theta[i], 0.0])
                q_dot = np.array([theta_dot[i], 0.0])
                q_ddot = np.array([theta_ddot[i], 0.0])
            else:  # elbow
                q = np.array([0.0, theta[i]])
                q_dot = np.array([0.0, theta_dot[i]])
                q_ddot = np.array([0.0, theta_ddot[i]])
            
            tau = self.dynamics.inverse_dynamics(q, q_dot, q_ddot)
            tau_shoulder[i] = tau[0]
            tau_elbow[i] = tau[1]
        
        return {
            'time': t,
            'position': theta,
            'velocity': theta_dot,
            'acceleration': theta_ddot,
            'torque_shoulder': tau_shoulder,
            'torque_elbow': tau_elbow,
        }
    
    def generate_ramp_profile(
        self,
        joint: str,
        start_angle: float,  # rad
        end_angle: float,    # rad
        duration: float,     # seconds
        hold_time: float = 1.0,  # seconds at end
    ) -> Dict[str, np.ndarray]:
        """
        Generate torque profile for ramp (linear) motion.
        
        Useful for reaching exercises.
        
        Motion profile: smooth start and stop using minimum jerk trajectory.
        """
        t_move = np.arange(0, duration, self.dt)
        t_hold = np.arange(duration, duration + hold_time, self.dt)
        t = np.concatenate([t_move, t_hold])
        
        # Minimum jerk trajectory for smooth motion
        # x(t) = x0 + (xf-x0) * (10τ³ - 15τ⁴ + 6τ⁵), where τ = t/T
        tau_norm = t_move / duration
        position_move = start_angle + (end_angle - start_angle) * (
            10 * tau_norm**3 - 15 * tau_norm**4 + 6 * tau_norm**5
        )
        position_hold = np.full_like(t_hold, end_angle)
        position = np.concatenate([position_move, position_hold])
        
        # Derivatives
        velocity = np.gradient(position, self.dt)
        acceleration = np.gradient(velocity, self.dt)
        
        # Compute torques
        n_samples = len(t)
        tau_shoulder = np.zeros(n_samples)
        tau_elbow = np.zeros(n_samples)
        
        for i in range(n_samples):
            if joint == 'shoulder':
                q = np.array([position[i], 0.0])
                q_dot = np.array([velocity[i], 0.0])
                q_ddot = np.array([acceleration[i], 0.0])
            else:
                q = np.array([0.0, position[i]])
                q_dot = np.array([0.0, velocity[i]])
                q_ddot = np.array([0.0, acceleration[i]])
            
            tau = self.dynamics.inverse_dynamics(q, q_dot, q_ddot)
            tau_shoulder[i] = tau[0]
            tau_elbow[i] = tau[1]
        
        return {
            'time': t,
            'position': position,
            'velocity': velocity,
            'acceleration': acceleration,
            'torque_shoulder': tau_shoulder,
            'torque_elbow': tau_elbow,
        }
    
    def generate_bimanual_profile(
        self,
        master_trajectory: Dict[str, np.ndarray],
        phase_lag: float = 0.0,  # seconds
    ) -> Dict[str, np.ndarray]:
        """
        Generate bimanual (symmetric) torque profile.
        
        Follower arm mirrors master arm with optional phase lag.
        Used for bimanual coordination training.
        
        Args:
            master_trajectory: Trajectory from sound arm
            phase_lag: Time delay for follower (0 = synchronized)
            
        Returns:
            Combined profile for both arms
        """
        t = master_trajectory['time']
        
        # Follower follows master with phase lag
        lag_samples = int(phase_lag * self.sample_rate)
        
        if lag_samples > 0:
            follower_position = np.pad(
                master_trajectory['position'][:-lag_samples],
                (lag_samples, 0),
                mode='edge'
            )
        else:
            follower_position = master_trajectory['position'].copy()
        
        follower_velocity = np.gradient(follower_position, self.dt)
        follower_acceleration = np.gradient(follower_velocity, self.dt)
        
        return {
            'time': t,
            'master_position': master_trajectory['position'],
            'master_velocity': master_trajectory['velocity'],
            'follower_position': follower_position,
            'follower_velocity': follower_velocity,
            'master_torque_shoulder': master_trajectory['torque_shoulder'],
            'master_torque_elbow': master_trajectory['torque_elbow'],
            # Follower torques would be computed by robot controller
        }


# ==================== Factory Functions ====================

def create_arm_dynamics(
    body_mass: float,
    upper_arm_length: float,
    forearm_length: float,
    hand_length: float,
    gender: Gender,
    include_gravity: bool = True,
) -> PlanarArmDynamics:
    """
    Create arm dynamics model from anthropometric data.
    
    Args:
        body_mass: Total body mass (kg)
        upper_arm_length: Upper arm length (m)
        forearm_length: Forearm length (m)
        hand_length: Hand length (m)
        gender: Patient gender
        include_gravity: Include gravity effects
        
    Returns:
        Configured PlanarArmDynamics model
    """
    from estimation.bsip_calculator import UpperLimbBSIPCalculator, BSIPMethod
    
    # Calculate BSIP
    calculator = UpperLimbBSIPCalculator(method=BSIPMethod.DE_LEVA_1996)
    
    upper_arm_bsip = calculator._calculator.calculate(
        body_mass, upper_arm_length, gender, ArmSegment.UPPER_ARM
    )
    forearm_hand_bsip = calculator.get_combined_forearm_hand(
        body_mass, forearm_length, hand_length, gender
    )
    
    # Create dynamics parameters
    params = ArmDynamicsParameters.from_bsip(upper_arm_bsip, forearm_hand_bsip)
    
    return PlanarArmDynamics(params, include_gravity=include_gravity)
