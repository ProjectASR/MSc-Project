"""
Body Segment Inertial Parameters (BSIP) Calculator.

Implements calculation methods from:
- de Leva, P. (1996). Adjustments to Zatsiorsky-Seluyanov's segment inertia parameters.
  Journal of Biomechanics, 29, 1223-1230.
- Dumas, R., Chèze, L., & Verriest, J.P. (2007). Adjustments to McConville et al. and 
  Young et al. body segment inertial parameters. Journal of Biomechanics, 40(3), 543-553.

These parameters are essential for computing arm dynamics and torque profiles.
"""
from dataclasses import dataclass
from typing import Dict, Tuple
import numpy as np

from core.base import BSIPCalculator, BSIPResult
from core.enums import Gender, ArmSegment, BSIPMethod


@dataclass
class BSIPCoefficients:
    """
    BSIP regression coefficients for a body segment.
    Mass and COM are expressed as ratios/percentages of total body mass and segment length.
    """
    mass_ratio: float           # Segment mass / Total body mass
    com_proximal_ratio: float   # COM distance from proximal end / Segment length
    radius_gyration_ratio: float  # Radius of gyration / Segment length
    
    # For more detailed 3D inertia (optional)
    rg_x_ratio: float = 0.0     # About x-axis (longitudinal)
    rg_y_ratio: float = 0.0     # About y-axis (frontal)
    rg_z_ratio: float = 0.0     # About z-axis (sagittal)


class DeLeva1996Calculator(BSIPCalculator):
    """
    BSIP calculator using de Leva (1996) adjusted coefficients.
    Based on Zatsiorsky-Seluyanov data adjusted for standard anatomical landmarks.
    
    Reference:
    de Leva, P. (1996). Adjustments to Zatsiorsky-Seluyanov's segment inertia parameters.
    Journal of Biomechanics, 29(9), 1223-1230.
    """
    
    # Coefficients table from de Leva (1996)
    # Format: (mass_ratio, com_proximal_ratio, radius_gyration_ratio)
    COEFFICIENTS: Dict[Tuple[Gender, ArmSegment], BSIPCoefficients] = {
        # Male coefficients
        (Gender.MALE, ArmSegment.UPPER_ARM): BSIPCoefficients(
            mass_ratio=0.0271,
            com_proximal_ratio=0.5772,
            radius_gyration_ratio=0.285,
            rg_x_ratio=0.285,
            rg_y_ratio=0.269,
            rg_z_ratio=0.158,
        ),
        (Gender.MALE, ArmSegment.FOREARM): BSIPCoefficients(
            mass_ratio=0.0162,
            com_proximal_ratio=0.4574,
            radius_gyration_ratio=0.276,
            rg_x_ratio=0.276,
            rg_y_ratio=0.265,
            rg_z_ratio=0.121,
        ),
        (Gender.MALE, ArmSegment.HAND): BSIPCoefficients(
            mass_ratio=0.0061,
            com_proximal_ratio=0.7900,
            radius_gyration_ratio=0.628,
            rg_x_ratio=0.628,
            rg_y_ratio=0.513,
            rg_z_ratio=0.401,
        ),
        
        # Female coefficients
        (Gender.FEMALE, ArmSegment.UPPER_ARM): BSIPCoefficients(
            mass_ratio=0.0255,
            com_proximal_ratio=0.5754,
            radius_gyration_ratio=0.278,
            rg_x_ratio=0.278,
            rg_y_ratio=0.260,
            rg_z_ratio=0.148,
        ),
        (Gender.FEMALE, ArmSegment.FOREARM): BSIPCoefficients(
            mass_ratio=0.0138,
            com_proximal_ratio=0.4559,
            radius_gyration_ratio=0.261,
            rg_x_ratio=0.261,
            rg_y_ratio=0.257,
            rg_z_ratio=0.094,
        ),
        (Gender.FEMALE, ArmSegment.HAND): BSIPCoefficients(
            mass_ratio=0.0056,
            com_proximal_ratio=0.7474,
            radius_gyration_ratio=0.531,
            rg_x_ratio=0.531,
            rg_y_ratio=0.454,
            rg_z_ratio=0.335,
        ),
    }
    
    def __init__(self):
        self.method = BSIPMethod.DE_LEVA_1996
    
    def calculate(
        self, 
        body_mass: float, 
        segment_length: float,
        gender: Gender,
        segment: ArmSegment = ArmSegment.UPPER_ARM
    ) -> BSIPResult:
        """
        Calculate BSIP for a segment using de Leva (1996) coefficients.
        
        Args:
            body_mass: Total body mass (kg)
            segment_length: Length of the segment (m)
            gender: Patient gender
            segment: Which arm segment
            
        Returns:
            BSIPResult with calculated parameters
        """
        coeff = self.COEFFICIENTS[(gender, segment)]
        
        # Calculate mass
        mass = coeff.mass_ratio * body_mass
        
        # Calculate COM position from proximal joint
        com_position = coeff.com_proximal_ratio * segment_length
        
        # Calculate radius of gyration
        radius_gyration = coeff.radius_gyration_ratio * segment_length
        
        # Calculate moments of inertia about COM
        # I = m * k^2 where k is radius of gyration
        inertia_sagittal = mass * (coeff.rg_z_ratio * segment_length) ** 2  # About z (sagittal plane motion)
        inertia_frontal = mass * (coeff.rg_y_ratio * segment_length) ** 2   # About y (frontal plane motion)
        inertia_longitudinal = mass * (coeff.rg_x_ratio * segment_length) ** 2  # About x (longitudinal axis)
        
        return BSIPResult(
            segment_name=segment.name,
            mass=mass,
            length=segment_length,
            com_position=com_position,
            com_ratio=coeff.com_proximal_ratio,
            inertia_xx=inertia_longitudinal,
            inertia_yy=inertia_frontal,
            inertia_zz=inertia_sagittal,
            radius_of_gyration=radius_gyration,
        )
    
    def get_coefficients(self, gender: Gender) -> Dict[str, BSIPCoefficients]:
        """Get all coefficients for a gender."""
        return {
            segment.name: self.COEFFICIENTS[(gender, segment)]
            for segment in ArmSegment
        }


class Dumas2007Calculator(BSIPCalculator):
    """
    BSIP calculator using Dumas et al. (2007) adjusted coefficients.
    Based on McConville et al. and Young et al. data with adjustments.
    
    Provides more accurate 3D inertia tensor estimates.
    
    Reference:
    Dumas, R., Chèze, L., & Verriest, J.P. (2007). Adjustments to McConville et al. 
    and Young et al. body segment inertial parameters. Journal of Biomechanics, 40(3), 543-553.
    """
    
    # Coefficients from Dumas (2007) - Table 4
    COEFFICIENTS: Dict[Tuple[Gender, ArmSegment], BSIPCoefficients] = {
        # Male coefficients (from McConville adjusted)
        (Gender.MALE, ArmSegment.UPPER_ARM): BSIPCoefficients(
            mass_ratio=0.0240,
            com_proximal_ratio=0.5070,
            radius_gyration_ratio=0.322,
            rg_x_ratio=0.310,
            rg_y_ratio=0.143,
            rg_z_ratio=0.322,
        ),
        (Gender.MALE, ArmSegment.FOREARM): BSIPCoefficients(
            mass_ratio=0.0170,
            com_proximal_ratio=0.4170,
            radius_gyration_ratio=0.303,
            rg_x_ratio=0.285,
            rg_y_ratio=0.107,
            rg_z_ratio=0.303,
        ),
        (Gender.MALE, ArmSegment.HAND): BSIPCoefficients(
            mass_ratio=0.0060,
            com_proximal_ratio=0.3680,
            radius_gyration_ratio=0.559,
            rg_x_ratio=0.524,
            rg_y_ratio=0.297,
            rg_z_ratio=0.559,
        ),
        
        # Female coefficients (from Young adjusted)
        (Gender.FEMALE, ArmSegment.UPPER_ARM): BSIPCoefficients(
            mass_ratio=0.0230,
            com_proximal_ratio=0.5090,
            radius_gyration_ratio=0.327,
            rg_x_ratio=0.312,
            rg_y_ratio=0.144,
            rg_z_ratio=0.327,
        ),
        (Gender.FEMALE, ArmSegment.FOREARM): BSIPCoefficients(
            mass_ratio=0.0140,
            com_proximal_ratio=0.4170,
            radius_gyration_ratio=0.295,
            rg_x_ratio=0.280,
            rg_y_ratio=0.105,
            rg_z_ratio=0.295,
        ),
        (Gender.FEMALE, ArmSegment.HAND): BSIPCoefficients(
            mass_ratio=0.0050,
            com_proximal_ratio=0.3680,
            radius_gyration_ratio=0.540,
            rg_x_ratio=0.509,
            rg_y_ratio=0.289,
            rg_z_ratio=0.540,
        ),
    }
    
    def __init__(self):
        self.method = BSIPMethod.DUMAS_2007
    
    def calculate(
        self, 
        body_mass: float, 
        segment_length: float,
        gender: Gender,
        segment: ArmSegment = ArmSegment.UPPER_ARM
    ) -> BSIPResult:
        """
        Calculate BSIP using Dumas (2007) coefficients.
        """
        coeff = self.COEFFICIENTS[(gender, segment)]
        
        mass = coeff.mass_ratio * body_mass
        com_position = coeff.com_proximal_ratio * segment_length
        radius_gyration = coeff.radius_gyration_ratio * segment_length
        
        # 3D inertia tensor components
        inertia_xx = mass * (coeff.rg_x_ratio * segment_length) ** 2
        inertia_yy = mass * (coeff.rg_y_ratio * segment_length) ** 2
        inertia_zz = mass * (coeff.rg_z_ratio * segment_length) ** 2
        
        return BSIPResult(
            segment_name=segment.name,
            mass=mass,
            length=segment_length,
            com_position=com_position,
            com_ratio=coeff.com_proximal_ratio,
            inertia_xx=inertia_xx,
            inertia_yy=inertia_yy,
            inertia_zz=inertia_zz,
            radius_of_gyration=radius_gyration,
        )
    
    def get_coefficients(self, gender: Gender) -> Dict[str, BSIPCoefficients]:
        return {
            segment.name: self.COEFFICIENTS[(gender, segment)]
            for segment in ArmSegment
        }


class UpperLimbBSIPCalculator:
    """
    High-level calculator for complete upper limb BSIP.
    Combines individual segment calculations for arm dynamics modeling.
    """
    
    def __init__(self, method: BSIPMethod = BSIPMethod.DE_LEVA_1996):
        """
        Initialize with specified calculation method.
        
        Args:
            method: BSIP calculation method to use
        """
        self.method = method
        
        if method == BSIPMethod.DE_LEVA_1996:
            self._calculator = DeLeva1996Calculator()
        elif method == BSIPMethod.DUMAS_2007:
            self._calculator = Dumas2007Calculator()
        else:
            raise ValueError(f"Unsupported BSIP method: {method}")
    
    def calculate_all_segments(
        self,
        body_mass: float,
        upper_arm_length: float,
        forearm_length: float,
        hand_length: float,
        gender: Gender,
    ) -> Dict[ArmSegment, BSIPResult]:
        """
        Calculate BSIP for all upper limb segments.
        
        Returns:
            Dictionary mapping segment to BSIPResult
        """
        return {
            ArmSegment.UPPER_ARM: self._calculator.calculate(
                body_mass, upper_arm_length, gender, ArmSegment.UPPER_ARM
            ),
            ArmSegment.FOREARM: self._calculator.calculate(
                body_mass, forearm_length, gender, ArmSegment.FOREARM
            ),
            ArmSegment.HAND: self._calculator.calculate(
                body_mass, hand_length, gender, ArmSegment.HAND
            ),
        }
    
    def get_combined_forearm_hand(
        self,
        body_mass: float,
        forearm_length: float,
        hand_length: float,
        gender: Gender,
    ) -> BSIPResult:
        """
        Calculate combined BSIP for forearm+hand as single segment.
        Useful for 2-DOF arm model (shoulder + elbow).
        
        Uses parallel axis theorem for combined inertia.
        """
        forearm = self._calculator.calculate(
            body_mass, forearm_length, gender, ArmSegment.FOREARM
        )
        hand = self._calculator.calculate(
            body_mass, hand_length, gender, ArmSegment.HAND
        )
        
        combined_length = forearm_length + hand_length
        combined_mass = forearm.mass + hand.mass
        
        # COM of combined segment (from elbow)
        forearm_com_from_elbow = forearm.com_position
        hand_com_from_elbow = forearm_length + hand.com_position
        
        combined_com = (
            forearm.mass * forearm_com_from_elbow + 
            hand.mass * hand_com_from_elbow
        ) / combined_mass
        
        # Combined inertia using parallel axis theorem
        # I_combined = I_forearm + m_f * d_f^2 + I_hand + m_h * d_h^2
        d_forearm = combined_com - forearm_com_from_elbow
        d_hand = combined_com - hand_com_from_elbow
        
        combined_inertia_zz = (
            forearm.inertia_zz + forearm.mass * d_forearm**2 +
            hand.inertia_zz + hand.mass * d_hand**2
        )
        
        combined_inertia_yy = (
            forearm.inertia_yy + forearm.mass * d_forearm**2 +
            hand.inertia_yy + hand.mass * d_hand**2
        )
        
        # Approximate radius of gyration
        combined_rg = np.sqrt(combined_inertia_zz / combined_mass)
        
        return BSIPResult(
            segment_name="FOREARM_HAND",
            mass=combined_mass,
            length=combined_length,
            com_position=combined_com,
            com_ratio=combined_com / combined_length,
            inertia_xx=forearm.inertia_xx + hand.inertia_xx,  # Approximate
            inertia_yy=combined_inertia_yy,
            inertia_zz=combined_inertia_zz,
            radius_of_gyration=combined_rg,
        )
    
    def calculate_arm_dynamics_parameters(
        self,
        body_mass: float,
        upper_arm_length: float,
        forearm_length: float,
        hand_length: float,
        gender: Gender,
    ) -> Dict[str, float]:
        """
        Calculate parameters needed for 2-DOF arm dynamics model.
        
        The arm is modeled with:
        - Link 1: Upper arm (shoulder to elbow)
        - Link 2: Forearm + Hand (elbow to fingertip)
        
        Returns dict with:
        - m1, m2: Link masses
        - l1, l2: Link lengths  
        - lc1, lc2: COM positions from proximal joint
        - I1, I2: Moments of inertia about COM
        """
        upper_arm = self._calculator.calculate(
            body_mass, upper_arm_length, gender, ArmSegment.UPPER_ARM
        )
        forearm_hand = self.get_combined_forearm_hand(
            body_mass, forearm_length, hand_length, gender
        )
        
        return {
            'm1': upper_arm.mass,
            'm2': forearm_hand.mass,
            'l1': upper_arm_length,
            'l2': forearm_hand.length,
            'lc1': upper_arm.com_position,
            'lc2': forearm_hand.com_position,
            'I1': upper_arm.inertia_zz,  # For sagittal plane motion
            'I2': forearm_hand.inertia_zz,
            # Additional parameters
            'total_mass': upper_arm.mass + forearm_hand.mass,
            'total_length': upper_arm_length + forearm_hand.length,
        }


# Factory function for easy calculator creation
def create_bsip_calculator(method: BSIPMethod = BSIPMethod.DE_LEVA_1996) -> UpperLimbBSIPCalculator:
    """
    Factory function to create a BSIP calculator.
    
    Args:
        method: Calculation method (DE_LEVA_1996 or DUMAS_2007)
        
    Returns:
        Configured UpperLimbBSIPCalculator instance
    """
    return UpperLimbBSIPCalculator(method)
