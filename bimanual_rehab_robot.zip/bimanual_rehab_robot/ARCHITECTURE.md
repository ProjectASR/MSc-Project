# Bimanual Tele-Rehabilitation Robot Software Architecture

## Project: Adaptive Torque Modeling and Optimized Exercise Protocols for Upper Limb Bimanual Tele-Robot

### University of Moratuwa - Robotics and Automation Laboratory

---

## 1. System Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        BIMANUAL REHAB ROBOT SYSTEM                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐  │
│  │   Patient   │    │   Torque    │    │  Exercise   │    │   Fatigue   │  │
│  │  Management │◄──►│  Modeling   │◄──►│  Protocol   │◄──►│  Detection  │  │
│  └─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘  │
│         │                  │                  │                  │          │
│         ▼                  ▼                  ▼                  ▼          │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     DATA MANAGEMENT LAYER                            │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐            │   │
│  │  │ Patient  │  │ Session  │  │ Exercise │  │  Torque  │            │   │
│  │  │   Repo   │  │   Repo   │  │   Repo   │  │   Repo   │            │   │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│         │                                                      │           │
│         ▼                                                      ▼           │
│  ┌─────────────┐                                      ┌─────────────┐      │
│  │    User     │                                      │    Robot    │      │
│  │  Interface  │                                      │  Controller │      │
│  │    (HMI)    │                                      │  Interface  │      │
│  └─────────────┘                                      └─────────────┘      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Module Architecture

### 2.1 Core Module (`core/`)
Base classes and interfaces that define the system contracts.

- `base.py` - Abstract base classes
- `interfaces.py` - Protocol definitions (Python protocols/ABCs)
- `enums.py` - System enumerations
- `exceptions.py` - Custom exceptions

### 2.2 Models Module (`models/`)
Data models representing system entities.

- `patient.py` - Patient data model with anthropometric parameters
- `session.py` - Rehabilitation session model
- `arm_segment.py` - Upper arm, forearm, hand segment models
- `torque_profile.py` - Torque profile data structure

### 2.3 Estimation Module (`estimation/`)
Parameter estimation algorithms based on literature.

- `bsip_calculator.py` - Body Segment Inertial Parameters (de Leva, Dumas methods)
- `rls_estimator.py` - Recursive Least Squares implementation
- `ffrls_estimator.py` - Forgetting Factor RLS (from Frontiers 2023 paper)
- `impedance_estimator.py` - Arm impedance parameter estimation

### 2.4 Protocols Module (`protocols/`)
Exercise protocol management.

- `exercise.py` - Individual exercise definitions
- `protocol.py` - Exercise protocol class
- `protocol_builder.py` - Protocol builder (Builder pattern)
- `protocol_optimizer.py` - Protocol optimization based on patient data

### 2.5 Fatigue Module (`fatigue/`)
Fatigue detection algorithms.

- `fatigue_detector.py` - Base fatigue detection
- `emg_fatigue.py` - EMG-based fatigue detection
- `torque_fatigue.py` - Torque decline-based fatigue detection
- `composite_detector.py` - Multi-modal fatigue detection

### 2.6 Data Module (`data/`)
Data persistence and management.

- `database.py` - Database connection management
- `repositories.py` - Repository pattern implementations
- `cloud_sync.py` - Cloud database synchronization

### 2.7 Users Module (`users/`)
User management with role-based access.

- `user.py` - Base user class
- `doctor.py` - Doctor role
- `physiotherapist.py` - Physiotherapist role
- `caregiver.py` - Caregiver role
- `patient_user.py` - Patient role
- `auth.py` - Authentication system
- `permissions.py` - Permission management

### 2.8 Interfaces Module (`interfaces/`)
External interfaces.

- `robot_interface.py` - Robot communication interface
- `hmi_interface.py` - Human-Machine Interface
- `sensor_interface.py` - Sensor data acquisition

---

## 3. Design Patterns Used

| Pattern | Application |
|---------|-------------|
| **Factory** | User creation based on role |
| **Strategy** | Different estimation algorithms (RLS, FFRLS) |
| **Observer** | Real-time session monitoring |
| **Repository** | Data access abstraction |
| **Builder** | Exercise protocol construction |
| **Singleton** | Database connection, Robot interface |
| **Template Method** | Fatigue detection algorithms |
| **Adapter** | Robot communication protocols |

---

## 4. Class Diagrams

### 4.1 Patient and Anthropometric Data

```
┌─────────────────────────────────────────┐
│              Patient                     │
├─────────────────────────────────────────┤
│ - id: str                               │
│ - name: str                             │
│ - age: int                              │
│ - gender: Gender                        │
│ - height: float (m)                     │
│ - weight: float (kg)                    │
│ - affected_side: AffectedSide           │
│ - stroke_date: datetime                 │
│ - anthropometrics: Anthropometrics      │
├─────────────────────────────────────────┤
│ + calculate_bsip(): BSIPResults         │
│ + get_arm_segments(): List[ArmSegment]  │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│           Anthropometrics               │
├─────────────────────────────────────────┤
│ - upper_arm_length: float               │
│ - forearm_length: float                 │
│ - hand_length: float                    │
│ - upper_arm_circumference: float        │
│ - forearm_circumference: float          │
│ - shoulder_width: float                 │
├─────────────────────────────────────────┤
│ + from_measurements(): Anthropometrics  │
└─────────────────────────────────────────┘
```

### 4.2 Estimation Classes

```
┌─────────────────────────────────────────┐
│      <<interface>>                      │
│      ParameterEstimator                 │
├─────────────────────────────────────────┤
│ + estimate(data): EstimationResult      │
│ + update(new_data): None                │
│ + reset(): None                         │
└─────────────────────────────────────────┘
            △                 △
            │                 │
┌───────────┴───┐    ┌───────┴───────────┐
│ RLSEstimator  │    │  FFRLSEstimator   │
├───────────────┤    ├───────────────────┤
│ - P: matrix   │    │ - P: matrix       │
│ - theta: vec  │    │ - theta: vec      │
│               │    │ - lambda: float   │
├───────────────┤    ├───────────────────┤
│ + estimate()  │    │ + estimate()      │
│ + update()    │    │ + update()        │
└───────────────┘    └───────────────────┘
```

### 4.3 User Hierarchy

```
┌─────────────────────────────────────────┐
│              User (Abstract)            │
├─────────────────────────────────────────┤
│ - id: str                               │
│ - username: str                         │
│ - password_hash: str                    │
│ - email: str                            │
│ - role: UserRole                        │
├─────────────────────────────────────────┤
│ + login(): bool                         │
│ + logout(): None                        │
│ + get_permissions(): List[Permission]   │
│ + can_access(resource): bool            │
└─────────────────────────────────────────┘
        △           △           △
        │           │           │
┌───────┴───┐ ┌─────┴─────┐ ┌───┴───────┐
│  Doctor   │ │Physio-    │ │ Caregiver │
│           │ │therapist  │ │           │
├───────────┤ ├───────────┤ ├───────────┤
│+prescribe │ │+design_   │ │+monitor   │
│ _protocol │ │ exercises │ │ _patient  │
│+view_all  │ │+adjust_   │ │+view_     │
│ _patients │ │ params    │ │ progress  │
└───────────┘ └───────────┘ └───────────┘
```

---

## 5. Mathematical Models

### 5.1 BSIP Calculation (de Leva 1996, Dumas 2007)

For each segment (upper arm, forearm, hand):

```
Mass:           m_i = c_m,i × M_body
COM position:   r_i = c_r,i × L_segment
Inertia:        I_i = c_I,i × M_body × L_segment²
```

Where `c_m`, `c_r`, `c_I` are gender-specific coefficients from literature.

### 5.2 Arm Dynamics (Lagrangian-Euler)

```
τ = M(q)q̈ + C(q,q̇)q̇ + G(q) + F(q̇)
```

Where:
- τ: Joint torques
- M(q): Inertia matrix
- C(q,q̇): Coriolis/centrifugal matrix
- G(q): Gravity vector
- F(q̇): Friction terms

### 5.3 FFRLS Algorithm

```
θ̂(k) = θ̂(k-1) + K(k)[y(k) - φᵀ(k)θ̂(k-1)]
K(k) = P(k-1)φ(k)[λ + φᵀ(k)P(k-1)φ(k)]⁻¹
P(k) = (1/λ)[P(k-1) - K(k)φᵀ(k)P(k-1)]
```

Where λ is the forgetting factor (0.95-0.99 typical).

---

## 6. Data Flow

```
Patient Registration
        │
        ▼
Anthropometric Measurement
        │
        ▼
BSIP Calculation (de Leva/Dumas)
        │
        ▼
Initial Parameter Estimation
        │
        ▼
┌───────────────────────────────────┐
│     REHABILITATION SESSION        │
│  ┌─────────────────────────────┐  │
│  │ 1. Load exercise protocol   │  │
│  │ 2. Read sensor data         │  │
│  │ 3. Update parameter est.    │  │
│  │ 4. Calculate torque command │  │
│  │ 5. Send to robot            │  │
│  │ 6. Monitor fatigue          │  │
│  │ 7. Adjust if needed         │  │
│  │ 8. Log all data             │  │
│  └─────────────────────────────┘  │
└───────────────────────────────────┘
        │
        ▼
Session Analysis & Reporting
```

---

## 7. File Structure

```
bimanual_rehab_robot/
├── ARCHITECTURE.md
├── README.md
├── requirements.txt
├── setup.py
├── config/
│   ├── __init__.py
│   ├── settings.py
│   └── constants.py
├── core/
│   ├── __init__.py
│   ├── base.py
│   ├── interfaces.py
│   ├── enums.py
│   └── exceptions.py
├── models/
│   ├── __init__.py
│   ├── patient.py
│   ├── session.py
│   ├── arm_segment.py
│   └── torque_profile.py
├── estimation/
│   ├── __init__.py
│   ├── bsip_calculator.py
│   ├── rls_estimator.py
│   ├── ffrls_estimator.py
│   └── impedance_estimator.py
├── protocols/
│   ├── __init__.py
│   ├── exercise.py
│   ├── protocol.py
│   ├── protocol_builder.py
│   └── protocol_optimizer.py
├── fatigue/
│   ├── __init__.py
│   ├── fatigue_detector.py
│   └── composite_detector.py
├── data/
│   ├── __init__.py
│   ├── database.py
│   ├── repositories.py
│   └── cloud_sync.py
├── users/
│   ├── __init__.py
│   ├── user.py
│   ├── roles.py
│   ├── auth.py
│   └── permissions.py
├── interfaces/
│   ├── __init__.py
│   ├── robot_interface.py
│   ├── hmi_interface.py
│   └── sensor_interface.py
├── utils/
│   ├── __init__.py
│   ├── math_utils.py
│   └── validation.py
└── tests/
    ├── __init__.py
    ├── test_estimation.py
    ├── test_bsip.py
    └── test_protocols.py
```

---

## 8. Technology Stack

| Component | Technology |
|-----------|------------|
| Language | Python 3.10+ |
| Numerical | NumPy, SciPy |
| Database | SQLAlchemy + PostgreSQL |
| Cloud | Firebase / AWS |
| HMI | PyQt6 / Kivy (tablet) |
| Robot Comm | pySerial / ROS2 |
| Testing | pytest |
| Documentation | Sphinx |

---

## 9. References

1. Frontiers 2023 - FFRLS for adaptive impedance control
2. de Leva 1996 - BSIP adjustments
3. Dumas et al. 2007 - Updated BSIP equations
4. Koike & Kawato 1995 - Arm dynamics modeling
5. Perera et al. 2024 - Base bimanual robot system

