"""
Bimanual Tele-Rehabilitation Robot Software System

A comprehensive software framework for controlling and managing
a bimanual tele-rehabilitation robot for post-stroke patients.

Developed at: University of Moratuwa, Robotics and Automation Laboratory
Project: Adaptive Torque Modeling and Optimized Exercise Protocols
"""

__version__ = "0.1.0"
__author__ = "Robotics and Automation Laboratory, University of Moratuwa"

from . import core
from . import models
from . import estimation
from . import protocols
from . import fatigue
