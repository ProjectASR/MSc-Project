"""Interfaces module - Robot and HMI interfaces (to be implemented)."""
