"""
Bimanual Tele-Rehabilitation Robot - Main Example Script

This script demonstrates how to use the rehabilitation robot software system:
1. Create a patient with anthropometric data
2. Calculate Body Segment Inertial Parameters (BSIP)
3. Create arm dynamics model for torque calculation
4. Generate exercise protocol
5. Run parameter estimation
6. Monitor fatigue

Run this script from the project root directory:
    python main.py

Or run specific examples:
    python main.py --example bsip
    python main.py --example protocol
    python main.py --example estimation
    python main.py --example fatigue
"""

import sys
import argparse
from datetime import date
import numpy as np

# Add parent directory to path for imports
sys.path.insert(0, '.')

from core.enums import Gender, AffectedSide, BSIPMethod, ArmSegment
from models.patient import Patient, Anthropometrics, MedicalHistory
from estimation.bsip_calculator import UpperLimbBSIPCalculator, create_bsip_calculator
from estimation.parameter_estimators import create_ffrls_estimator, ArmImpedanceEstimator
from estimation.arm_dynamics import PlanarArmDynamics, ArmDynamicsParameters, TorqueProfileGenerator
from protocols.exercise_protocol import ProtocolBuilder, StandardProtocols
from fatigue.fatigue_detector import CompositeFatigueDetector, create_fatigue_detector


def example_patient_creation():
    """Example: Creating a patient with anthropometric data."""
    print("\n" + "="*60)
    print("EXAMPLE 1: Patient Creation")
    print("="*60)
    
    # Create anthropometric measurements
    anthropometrics = Anthropometrics(
        height=1.75,              # meters
        body_mass=70.0,           # kg
        upper_arm_length=0.30,    # meters
        forearm_length=0.25,      # meters
        hand_length=0.19,         # meters
        upper_arm_circumference=0.28,
        forearm_circumference=0.24,
    )
    
    # Create medical history
    medical_history = MedicalHistory(
        stroke_date=date(2024, 6, 15),
        stroke_type="Ischemic",
        affected_hemisphere="Left",
        initial_nihss_score=8,
        current_fma_score=35,
        comorbidities=["Hypertension"],
        medications=["Aspirin", "Lisinopril"],
    )
    
    # Create patient
    patient = Patient.create(
        name="John Doe",
        date_of_birth=date(1960, 5, 20),
        gender=Gender.MALE,
        affected_side=AffectedSide.RIGHT,
        contact_number="+94771234567",
        email="john.doe@email.com",
    )
    patient.set_anthropometrics(anthropometrics)
    patient.medical_history = medical_history
    
    # Display patient info
    print(f"\nPatient Created: {patient}")
    print(f"  Age: {patient.age} years")
    print(f"  BMI: {anthropometrics.bmi:.1f}")
    print(f"  Affected Side: {patient.affected_side.name}")
    print(f"  Sound Arm: {patient.sound_arm}")
    print(f"  Days Since Stroke: {medical_history.days_since_stroke}")
    print(f"  Recovery Phase: {medical_history.stroke_phase}")
    print(f"  FMA Score: {medical_history.current_fma_score}/66")
    
    can_exercise, reason = patient.can_perform_exercise()
    print(f"  Can Perform Exercises: {can_exercise}")
    
    return patient


def example_bsip_calculation(patient: Patient = None):
    """Example: Calculate Body Segment Inertial Parameters."""
    print("\n" + "="*60)
    print("EXAMPLE 2: BSIP Calculation (de Leva 1996)")
    print("="*60)
    
    if patient is None:
        # Default values if no patient provided
        body_mass = 70.0
        upper_arm_length = 0.30
        forearm_length = 0.25
        hand_length = 0.19
        gender = Gender.MALE
    else:
        body_mass = patient.anthropometrics.body_mass
        upper_arm_length = patient.anthropometrics.upper_arm_length
        forearm_length = patient.anthropometrics.forearm_length
        hand_length = patient.anthropometrics.hand_length
        gender = patient.gender
    
    # Create BSIP calculator
    calculator = create_bsip_calculator(method=BSIPMethod.DE_LEVA_1996)
    
    # Calculate for all segments
    bsip_results = calculator.calculate_all_segments(
        body_mass=body_mass,
        upper_arm_length=upper_arm_length,
        forearm_length=forearm_length,
        hand_length=hand_length,
        gender=gender,
    )
    
    print(f"\nBody Mass: {body_mass} kg")
    print(f"Gender: {gender.name}")
    print("\nSegment Parameters:")
    print("-" * 50)
    
    for segment, result in bsip_results.items():
        print(f"\n{segment.name}:")
        print(f"  Mass: {result.mass:.4f} kg ({result.mass/body_mass*100:.2f}% of body)")
        print(f"  Length: {result.length*100:.1f} cm")
        print(f"  COM from proximal: {result.com_position*100:.2f} cm ({result.com_ratio*100:.1f}%)")
        print(f"  Inertia (Izz): {result.inertia_zz:.6f} kg·m²")
    
    # Get combined forearm+hand for 2-DOF model
    combined = calculator.get_combined_forearm_hand(
        body_mass, forearm_length, hand_length, gender
    )
    print(f"\nCombined FOREARM+HAND (for 2-DOF model):")
    print(f"  Mass: {combined.mass:.4f} kg")
    print(f"  Length: {combined.length*100:.1f} cm")
    print(f"  COM: {combined.com_position*100:.2f} cm")
    print(f"  Inertia: {combined.inertia_zz:.6f} kg·m²")
    
    # Get dynamics parameters
    print("\n" + "-"*50)
    print("Parameters for Arm Dynamics Model:")
    dyn_params = calculator.calculate_arm_dynamics_parameters(
        body_mass, upper_arm_length, forearm_length, hand_length, gender
    )
    for key, value in dyn_params.items():
        print(f"  {key}: {value:.4f}")
    
    return bsip_results


def example_arm_dynamics():
    """Example: Arm dynamics and torque profile generation."""
    print("\n" + "="*60)
    print("EXAMPLE 3: Arm Dynamics & Torque Profile")
    print("="*60)
    
    # Create dynamics parameters (typical male adult)
    params = ArmDynamicsParameters(
        m1=1.90,      # Upper arm mass (kg)
        l1=0.30,      # Upper arm length (m)
        lc1=0.173,    # Upper arm COM (m)
        I1=0.0141,    # Upper arm inertia (kg·m²)
        m2=1.52,      # Forearm+hand mass (kg)
        l2=0.44,      # Forearm+hand length (m)
        lc2=0.181,    # Forearm+hand COM (m)
        I2=0.0188,    # Forearm+hand inertia (kg·m²)
        g=9.81,
    )
    
    # Create dynamics model
    dynamics = PlanarArmDynamics(params, include_gravity=True)
    
    # Test inverse dynamics at a specific configuration
    q = np.array([np.radians(30), np.radians(45)])      # Joint angles
    q_dot = np.array([np.radians(10), np.radians(15)])  # Velocities
    q_ddot = np.array([np.radians(5), np.radians(8)])   # Accelerations
    
    # Calculate required torques
    tau = dynamics.inverse_dynamics(q, q_dot, q_ddot)
    
    print(f"\nJoint Configuration:")
    print(f"  Shoulder angle: {np.degrees(q[0]):.1f}°")
    print(f"  Elbow angle: {np.degrees(q[1]):.1f}°")
    print(f"\nJoint Velocities:")
    print(f"  Shoulder: {np.degrees(q_dot[0]):.1f}°/s")
    print(f"  Elbow: {np.degrees(q_dot[1]):.1f}°/s")
    print(f"\nRequired Torques:")
    print(f"  Shoulder: {tau[0]:.3f} Nm")
    print(f"  Elbow: {tau[1]:.3f} Nm")
    
    # Generate torque profile for sinusoidal exercise
    generator = TorqueProfileGenerator(dynamics, sample_rate=100.0)
    
    profile = generator.generate_sinusoidal_profile(
        joint='elbow',
        amplitude=np.radians(45),  # 45° amplitude
        frequency=0.25,            # 0.25 Hz (4 second cycle)
        duration=8.0,              # 8 seconds (2 cycles)
    )
    
    print(f"\nGenerated Elbow Flexion/Extension Profile:")
    print(f"  Duration: {profile['time'][-1]:.1f} seconds")
    print(f"  Samples: {len(profile['time'])}")
    print(f"  Peak position: {np.degrees(np.max(np.abs(profile['position']))):.1f}°")
    print(f"  Peak elbow torque: {np.max(np.abs(profile['torque_elbow'])):.3f} Nm")
    print(f"  Peak shoulder torque: {np.max(np.abs(profile['torque_shoulder'])):.3f} Nm")
    
    return dynamics, profile


def example_exercise_protocol():
    """Example: Creating and using exercise protocols."""
    print("\n" + "="*60)
    print("EXAMPLE 4: Exercise Protocol Creation")
    print("="*60)
    
    # Method 1: Use predefined protocol
    print("\nMethod 1: Standard Protocol (based on FMA score)")
    fma_score = 35
    protocol = StandardProtocols.get_protocol_for_fma_score(fma_score)
    
    print(f"  FMA Score: {fma_score}")
    print(f"  Selected Protocol: {protocol.name}")
    print(f"  Difficulty: {protocol.difficulty_level}/5")
    print(f"  Number of Exercises: {len(protocol.exercises)}")
    print(f"  Estimated Duration: {protocol.get_total_duration()}")
    
    # Method 2: Build custom protocol
    print("\nMethod 2: Custom Protocol using Builder")
    custom_protocol = (
        ProtocolBuilder()
        .create_protocol(
            "Custom Bimanual Protocol",
            "Personalized protocol for patient rehabilitation"
        )
        .set_difficulty(3)
        .set_warmup(180)  # 3 minutes
        .add_elbow_flexion_extension(
            rom_degrees=60,
            speed_degrees_per_sec=20,
            repetitions=8,
            sets=2,
            assistance=0.5,
        )
        .add_shoulder_rotation(
            rom_degrees=45,
            speed_degrees_per_sec=15,
            repetitions=8,
            sets=2,
            assistance=0.5,
        )
        .enable_fatigue_adjustment(True)
        .set_max_duration(30)
        .build()
    )
    
    print(f"\n  Protocol Name: {custom_protocol.name}")
    print(f"  Exercises:")
    for i, ex in enumerate(custom_protocol.exercises, 1):
        print(f"    {i}. {ex.name}")
        print(f"       Type: {ex.exercise_type.name}")
        print(f"       Mode: {ex.mode.name}")
        print(f"       ROM: {ex.parameters.range_of_motion}°")
        print(f"       Reps × Sets: {ex.parameters.repetitions} × {ex.parameters.sets}")
        print(f"       Est. Duration: {ex.get_estimated_duration()}")
    
    # Simulate protocol execution
    print(f"\nProtocol Execution Simulation:")
    custom_protocol.reset()
    step = 0
    while True:
        current = custom_protocol.get_current_exercise()
        if current is None:
            break
        
        progress = custom_protocol.get_progress()
        if step < 3:  # Show first few steps
            print(f"  Step {step+1}: {current.name} - Progress: {progress*100:.1f}%")
        
        if not custom_protocol.advance():
            break
        step += 1
    
    print(f"  ... (total {step} steps)")
    print(f"  Final Progress: {custom_protocol.get_progress()*100:.1f}%")
    
    return custom_protocol


def example_parameter_estimation():
    """Example: Online parameter estimation using FFRLS."""
    print("\n" + "="*60)
    print("EXAMPLE 5: Parameter Estimation (FFRLS)")
    print("="*60)
    
    # Create arm impedance estimator
    estimator = ArmImpedanceEstimator(
        forgetting_factor=0.98,
        initial_inertia=0.1,
        initial_damping=1.0,
        initial_stiffness=10.0,
    )
    
    # Simulate data with known parameters
    true_inertia = 0.15      # kg·m²
    true_damping = 2.0       # Nm·s/rad
    true_stiffness = 15.0    # Nm/rad
    
    print(f"\nTrue Parameters:")
    print(f"  Inertia: {true_inertia} kg·m²")
    print(f"  Damping: {true_damping} Nm·s/rad")
    print(f"  Stiffness: {true_stiffness} Nm/rad")
    
    # Generate simulated measurements
    np.random.seed(42)
    n_samples = 200
    dt = 0.01
    
    print(f"\nRunning estimation with {n_samples} samples...")
    
    for i in range(n_samples):
        # Simulated motion
        t = i * dt
        position = 0.5 * np.sin(2 * np.pi * 0.5 * t)
        velocity = 0.5 * 2 * np.pi * 0.5 * np.cos(2 * np.pi * 0.5 * t)
        acceleration = -0.5 * (2 * np.pi * 0.5)**2 * np.sin(2 * np.pi * 0.5 * t)
        
        # True torque with noise
        torque = (true_inertia * acceleration + 
                  true_damping * velocity + 
                  true_stiffness * position +
                  np.random.normal(0, 0.1))
        
        # Update estimator
        result = estimator.update(torque, position, velocity, acceleration)
    
    # Get final estimates
    params = estimator.get_parameters()
    
    print(f"\nEstimated Parameters:")
    print(f"  Inertia: {params['inertia']:.4f} kg·m² (error: {abs(params['inertia']-true_inertia)/true_inertia*100:.1f}%)")
    print(f"  Damping: {params['damping']:.4f} Nm·s/rad (error: {abs(params['damping']-true_damping)/true_damping*100:.1f}%)")
    print(f"  Stiffness: {params['stiffness']:.4f} Nm/rad (error: {abs(params['stiffness']-true_stiffness)/true_stiffness*100:.1f}%)")
    
    return estimator


def example_fatigue_detection():
    """Example: Multi-modal fatigue detection."""
    print("\n" + "="*60)
    print("EXAMPLE 6: Fatigue Detection")
    print("="*60)
    
    # Create composite fatigue detector
    detector = create_fatigue_detector(
        detector_type='composite',
        sample_rate=100.0,
    )
    
    # Generate baseline data (first few repetitions - no fatigue)
    np.random.seed(42)
    n_baseline = 300  # 3 seconds at 100 Hz
    dt = 0.01
    t = np.arange(n_baseline) * dt
    
    baseline_positions = 0.5 * np.sin(2 * np.pi * 0.5 * t)
    baseline_velocities = 0.5 * 2 * np.pi * 0.5 * np.cos(2 * np.pi * 0.5 * t)
    baseline_torques = 5.0 + 0.5 * np.random.randn(n_baseline)
    
    # Initialize detector with baseline
    detector.initialize({
        'torques': baseline_torques,
        'velocities': baseline_velocities,
        'positions': baseline_positions,
        'dt': dt,
    })
    
    print("\nBaseline established from initial 3 seconds")
    print(f"  Baseline mean torque: {np.mean(np.abs(baseline_torques)):.2f} Nm")
    print(f"  Baseline ROM: {np.max(baseline_positions) - np.min(baseline_positions):.3f} rad")
    
    # Simulate exercise with progressive fatigue
    print("\nSimulating exercise with progressive fatigue...")
    
    fatigue_stages = [
        (100, 1.0, "No fatigue"),
        (100, 0.9, "Beginning fatigue"),
        (100, 0.75, "Moderate fatigue"),
        (100, 0.6, "Severe fatigue"),
    ]
    
    sample_idx = 0
    for n_samples, fatigue_factor, description in fatigue_stages:
        for i in range(n_samples):
            t = sample_idx * dt
            
            # Degraded performance due to fatigue
            position = 0.5 * fatigue_factor * np.sin(2 * np.pi * 0.5 * t)
            velocity = 0.5 * fatigue_factor * 2 * np.pi * 0.5 * np.cos(2 * np.pi * 0.5 * t)
            torque = 5.0 * fatigue_factor + 0.5 * np.random.randn()
            
            # Mark new repetition every 200 samples
            new_rep = (sample_idx % 200 == 0)
            
            indicators = detector.update({
                'torque': torque,
                'position': position,
                'velocity': velocity,
                'new_rep': new_rep,
            })
            
            sample_idx += 1
        
        # Report after each stage
        level = detector.get_fatigue_level()
        report = detector.get_detailed_report()
        print(f"\n  Stage: {description}")
        print(f"    Fatigue Level: {level.name}")
        print(f"    Torque Ratio: {report['indicators']['torque_decline']*100:.1f}%")
        print(f"    Smoothness: {report['indicators']['movement_smoothness']*100:.1f}%")
        print(f"    Should Pause: {report['should_pause']}")
    
    return detector


def run_all_examples():
    """Run all examples in sequence."""
    print("\n" + "#"*60)
    print("#  BIMANUAL TELE-REHABILITATION ROBOT SYSTEM")
    print("#  Example Demonstrations")
    print("#"*60)
    
    # Run examples
    patient = example_patient_creation()
    example_bsip_calculation(patient)
    example_arm_dynamics()
    example_exercise_protocol()
    example_parameter_estimation()
    example_fatigue_detection()
    
    print("\n" + "="*60)
    print("All examples completed successfully!")
    print("="*60)


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Bimanual Tele-Rehabilitation Robot Examples"
    )
    parser.add_argument(
        '--example',
        choices=['all', 'patient', 'bsip', 'dynamics', 'protocol', 'estimation', 'fatigue'],
        default='all',
        help='Which example to run (default: all)'
    )
    
    args = parser.parse_args()
    
    if args.example == 'all':
        run_all_examples()
    elif args.example == 'patient':
        example_patient_creation()
    elif args.example == 'bsip':
        patient = example_patient_creation()
        example_bsip_calculation(patient)
    elif args.example == 'dynamics':
        example_arm_dynamics()
    elif args.example == 'protocol':
        example_exercise_protocol()
    elif args.example == 'estimation':
        example_parameter_estimation()
    elif args.example == 'fatigue':
        example_fatigue_detection()


if __name__ == "__main__":
    main()
