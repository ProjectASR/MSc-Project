#!/usr/bin/env python
"""
Launch the Bimanual Rehabilitation Robot User Interface.

Usage:
    python run_ui.py
    
Requirements:
    pip install customtkinter pillow numpy scipy
"""

import sys
import os

# Add project root to path
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

def check_dependencies():
    """Check if required packages are installed."""
    missing = []
    
    try:
        import customtkinter
    except ImportError:
        missing.append('customtkinter')
    
    try:
        import numpy
    except ImportError:
        missing.append('numpy')
    
    try:
        import scipy
    except ImportError:
        missing.append('scipy')
    
    if missing:
        print("=" * 60)
        print("Missing required packages!")
        print("=" * 60)
        print(f"\nPlease install: {', '.join(missing)}")
        print(f"\nRun: pip install {' '.join(missing)}")
        print("\nOr install all requirements:")
        print("    pip install -r requirements.txt")
        print("=" * 60)
        return False
    
    return True


def main():
    """Main entry point."""
    print("=" * 60)
    print("  Bimanual Tele-Rehabilitation Robot System")
    print("  University of Moratuwa - Robotics Laboratory")
    print("=" * 60)
    print("\nStarting User Interface...\n")
    
    if not check_dependencies():
        sys.exit(1)
    
    # Import and run the application
    from ui.app import run_app
    run_app()


if __name__ == "__main__":
    main()
