"""
Patient model with anthropometric measurements for BSIP calculation.
Based on de Leva (1996) and Dumas (2007) body segment parameter methods.
"""
from dataclasses import dataclass, field
from datetime import datetime, date
from typing import Dict, List, Optional, Any
import uuid

from core.enums import Gender, AffectedSide, ArmSegment
from core.base import Entity, BSIPResult


@dataclass
class Anthropometrics:
    """
    Anthropometric measurements required for BSIP calculation.
    All measurements in SI units (meters, kilograms).
    """
    # Required measurements
    height: float                    # Total body height (m)
    body_mass: float                 # Total body mass (kg)
    
    # Upper limb measurements
    upper_arm_length: float          # Acromion to radiale (m)
    forearm_length: float            # Radiale to stylion (m)
    hand_length: float               # Stylion to dactylion (m)
    
    # Optional circumference measurements for refined estimates
    upper_arm_circumference: Optional[float] = None   # Mid-upper arm (m)
    forearm_circumference: Optional[float] = None     # Max forearm (m)
    wrist_circumference: Optional[float] = None       # At stylion (m)
    
    # Shoulder measurements
    shoulder_width: Optional[float] = None            # Biacromial breadth (m)
    
    # Measurement metadata
    measured_at: datetime = field(default_factory=datetime.now)
    measured_by: Optional[str] = None
    
    def __post_init__(self):
        """Validate measurements."""
        self._validate()
    
    def _validate(self) -> None:
        """Validate anthropometric measurements are within reasonable ranges."""
        # Height validation (0.5m to 2.5m)
        if not 0.5 <= self.height <= 2.5:
            raise ValueError(f"Height {self.height}m is outside reasonable range (0.5-2.5m)")
        
        # Body mass validation (20kg to 300kg)
        if not 20 <= self.body_mass <= 300:
            raise ValueError(f"Body mass {self.body_mass}kg is outside reasonable range (20-300kg)")
        
        # Segment length validations
        if not 0.1 <= self.upper_arm_length <= 0.5:
            raise ValueError(f"Upper arm length {self.upper_arm_length}m is outside reasonable range")
        
        if not 0.1 <= self.forearm_length <= 0.4:
            raise ValueError(f"Forearm length {self.forearm_length}m is outside reasonable range")
        
        if not 0.05 <= self.hand_length <= 0.3:
            raise ValueError(f"Hand length {self.hand_length}m is outside reasonable range")
    
    @property
    def total_arm_length(self) -> float:
        """Total length from shoulder to fingertip."""
        return self.upper_arm_length + self.forearm_length + self.hand_length
    
    @property
    def bmi(self) -> float:
        """Body Mass Index."""
        return self.body_mass / (self.height ** 2)
    
    def get_segment_length(self, segment: ArmSegment) -> float:
        """Get length of specific segment."""
        segment_map = {
            ArmSegment.UPPER_ARM: self.upper_arm_length,
            ArmSegment.FOREARM: self.forearm_length,
            ArmSegment.HAND: self.hand_length,
        }
        return segment_map[segment]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'height': self.height,
            'body_mass': self.body_mass,
            'upper_arm_length': self.upper_arm_length,
            'forearm_length': self.forearm_length,
            'hand_length': self.hand_length,
            'upper_arm_circumference': self.upper_arm_circumference,
            'forearm_circumference': self.forearm_circumference,
            'wrist_circumference': self.wrist_circumference,
            'shoulder_width': self.shoulder_width,
            'measured_at': self.measured_at.isoformat(),
            'measured_by': self.measured_by,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Anthropometrics':
        """Create from dictionary."""
        data = data.copy()
        if 'measured_at' in data and isinstance(data['measured_at'], str):
            data['measured_at'] = datetime.fromisoformat(data['measured_at'])
        return cls(**data)
    
    @classmethod
    def estimate_from_height(cls, height: float, body_mass: float, gender: Gender) -> 'Anthropometrics':
        """
        Estimate segment lengths from height using regression equations.
        Based on Winter (2009) proportions.
        """
        # Segment length proportions relative to height
        if gender == Gender.MALE:
            upper_arm_ratio = 0.186
            forearm_ratio = 0.146
            hand_ratio = 0.108
        else:
            upper_arm_ratio = 0.173
            forearm_ratio = 0.138
            hand_ratio = 0.104
        
        return cls(
            height=height,
            body_mass=body_mass,
            upper_arm_length=height * upper_arm_ratio,
            forearm_length=height * forearm_ratio,
            hand_length=height * hand_ratio,
        )


@dataclass
class MedicalHistory:
    """Patient medical history relevant to rehabilitation."""
    stroke_date: date
    stroke_type: str = "Ischemic"  # Ischemic or Hemorrhagic
    affected_hemisphere: str = "Left"
    initial_nihss_score: Optional[int] = None  # NIH Stroke Scale
    current_fma_score: Optional[int] = None    # Fugl-Meyer Assessment
    comorbidities: List[str] = field(default_factory=list)
    medications: List[str] = field(default_factory=list)
    contraindications: List[str] = field(default_factory=list)
    notes: str = ""
    
    @property
    def days_since_stroke(self) -> int:
        """Days elapsed since stroke."""
        return (date.today() - self.stroke_date).days
    
    @property
    def stroke_phase(self) -> str:
        """Current stroke recovery phase."""
        days = self.days_since_stroke
        if days <= 7:
            return "Acute"
        elif days <= 90:
            return "Subacute"
        else:
            return "Chronic"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'stroke_date': self.stroke_date.isoformat(),
            'stroke_type': self.stroke_type,
            'affected_hemisphere': self.affected_hemisphere,
            'initial_nihss_score': self.initial_nihss_score,
            'current_fma_score': self.current_fma_score,
            'comorbidities': self.comorbidities,
            'medications': self.medications,
            'contraindications': self.contraindications,
            'notes': self.notes,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MedicalHistory':
        data = data.copy()
        if 'stroke_date' in data and isinstance(data['stroke_date'], str):
            data['stroke_date'] = date.fromisoformat(data['stroke_date'])
        return cls(**data)


@dataclass
class Patient(Entity):
    """
    Patient entity with all relevant information for rehabilitation.
    """
    # Personal information (with defaults to satisfy dataclass inheritance rules)
    name: str = ""
    date_of_birth: date = field(default_factory=lambda: date(2000, 1, 1))
    gender: Gender = Gender.MALE
    contact_number: Optional[str] = None
    email: Optional[str] = None
    emergency_contact: Optional[str] = None
    
    # Clinical information
    affected_side: AffectedSide = AffectedSide.LEFT
    medical_history: Optional[MedicalHistory] = None
    
    # Anthropometric data
    anthropometrics: Optional[Anthropometrics] = None
    
    # Calculated BSIP (cached after calculation)
    _bsip_cache: Dict[ArmSegment, BSIPResult] = field(default_factory=dict, repr=False)
    
    # Assigned healthcare providers
    assigned_doctor_id: Optional[str] = None
    assigned_physiotherapist_id: Optional[str] = None
    assigned_caregiver_id: Optional[str] = None
    
    # Status
    is_active: bool = True
    
    def __post_init__(self):
        """Validate required fields."""
        if not self.name:
            raise ValueError("Patient name is required")
        if not self.id:
            raise ValueError("Patient ID is required")
    
    @classmethod
    def create(cls, name: str, date_of_birth: date, gender: Gender, **kwargs) -> 'Patient':
        """Factory method to create a new patient with generated ID."""
        patient_id = f"PAT-{uuid.uuid4().hex[:8].upper()}"
        return cls(id=patient_id, name=name, date_of_birth=date_of_birth, gender=gender, **kwargs)
    
    @property
    def age(self) -> int:
        """Calculate patient age."""
        today = date.today()
        return today.year - self.date_of_birth.year - (
            (today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day)
        )
    
    @property
    def sound_arm(self) -> str:
        """Get the sound (unaffected) arm side."""
        if self.affected_side == AffectedSide.LEFT:
            return "Right"
        elif self.affected_side == AffectedSide.RIGHT:
            return "Left"
        else:
            return "Both affected"
    
    def set_anthropometrics(self, anthropometrics: Anthropometrics) -> None:
        """Set anthropometric measurements and clear BSIP cache."""
        self.anthropometrics = anthropometrics
        self._bsip_cache.clear()
        self.updated_at = datetime.now()
    
    def get_bsip(self, segment: ArmSegment) -> Optional[BSIPResult]:
        """Get cached BSIP for segment, if available."""
        return self._bsip_cache.get(segment)
    
    def set_bsip(self, segment: ArmSegment, bsip: BSIPResult) -> None:
        """Cache BSIP calculation result."""
        self._bsip_cache[segment] = bsip
    
    def has_complete_data(self) -> bool:
        """Check if patient has all required data for rehabilitation."""
        return (
            self.anthropometrics is not None and
            self.medical_history is not None
        )
    
    def can_perform_exercise(self) -> tuple[bool, Optional[str]]:
        """
        Check if patient can safely perform exercises.
        Returns (can_perform, reason_if_not).
        """
        if not self.is_active:
            return False, "Patient is not active"
        
        if self.medical_history is None:
            return False, "Medical history not available"
        
        # Check contraindications
        critical_contraindications = [
            "uncontrolled hypertension",
            "unstable cardiac condition",
            "acute infection",
        ]
        
        for contra in self.medical_history.contraindications:
            if any(crit in contra.lower() for crit in critical_contraindications):
                return False, f"Contraindication: {contra}"
        
        return True, None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'id': self.id,
            'name': self.name,
            'date_of_birth': self.date_of_birth.isoformat(),
            'gender': self.gender.name,
            'contact_number': self.contact_number,
            'email': self.email,
            'emergency_contact': self.emergency_contact,
            'affected_side': self.affected_side.name,
            'medical_history': self.medical_history.to_dict() if self.medical_history else None,
            'anthropometrics': self.anthropometrics.to_dict() if self.anthropometrics else None,
            'assigned_doctor_id': self.assigned_doctor_id,
            'assigned_physiotherapist_id': self.assigned_physiotherapist_id,
            'assigned_caregiver_id': self.assigned_caregiver_id,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Patient':
        """Create patient from dictionary."""
        data = data.copy()
        
        # Convert date strings
        data['date_of_birth'] = date.fromisoformat(data['date_of_birth'])
        data['created_at'] = datetime.fromisoformat(data['created_at'])
        data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        
        # Convert enums
        data['gender'] = Gender[data['gender']]
        data['affected_side'] = AffectedSide[data['affected_side']]
        
        # Convert nested objects
        if data.get('medical_history'):
            data['medical_history'] = MedicalHistory.from_dict(data['medical_history'])
        if data.get('anthropometrics'):
            data['anthropometrics'] = Anthropometrics.from_dict(data['anthropometrics'])
        
        return cls(**data)
    
    def __str__(self) -> str:
        return f"Patient({self.id}: {self.name}, {self.age}y, {self.gender.name})"
