"""
User Interface module for Bimanual Rehabilitation Robot System.
Provides modern, professional GUI using CustomTkinter.
"""

from .app import MainApplication, run_app
from .config import COLORS, FONTS, SPACING
from .login_screen import LoginScreen
from .dashboard import DashboardView
from .session_control import SessionControlView

__all__ = [
    'MainApplication',
    'run_app',
    'COLORS',
    'FONTS',
    'SPACING',
    'LoginScreen',
    'DashboardView',
    'SessionControlView',
]
