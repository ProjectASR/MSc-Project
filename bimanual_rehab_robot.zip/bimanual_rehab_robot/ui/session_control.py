"""
Session Control Screen for Bimanual Rehabilitation Robot.
Real-time monitoring and control of rehabilitation sessions.
"""

import customtkinter as ctk
from typing import Callable, Optional, Dict, Any
import tkinter as tk
from datetime import datetime
import math
import random

from .config import COLORS, FONTS, SPACING, RADIUS
from .widgets import (
    Card, StatCard, PrimaryButton, SecondaryButton, OutlineButton,
    ProgressCard, GaugeWidget, StatusBadge
)


class SessionControlView(ctk.CTkFrame):
    """
    Session control and monitoring view.
    Provides real-time feedback during rehabilitation exercises.
    """
    
    def __init__(self, parent, on_emergency_stop: Callable = None):
        super().__init__(parent, fg_color=COLORS['background'])
        
        self.on_emergency_stop = on_emergency_stop
        self.is_running = False
        self.session_time = 0
        self.current_rep = 1
        self.current_set = 1
        self.total_reps = 10
        self.total_sets = 3
        
        # Animation variables
        self.angle = 0
        self.target_angle = 0
        
        self._create_ui()
        self._start_animation()
    
    def _create_ui(self):
        """Create the session control UI."""
        # Main container with two columns
        main_container = ctk.CTkFrame(self, fg_color='transparent')
        main_container.pack(fill='both', expand=True, padx=SPACING['lg'], pady=SPACING['lg'])
        
        # Left column - Robot visualization and controls
        left_col = ctk.CTkFrame(main_container, fg_color='transparent')
        left_col.pack(side='left', fill='both', expand=True, padx=(0, SPACING['md']))
        
        # Right column - Metrics and parameters
        right_col = ctk.CTkFrame(main_container, fg_color='transparent', width=380)
        right_col.pack(side='right', fill='y')
        right_col.pack_propagate(False)
        
        # === Left Column Content ===
        
        # Session header
        self._create_session_header(left_col)
        
        # Robot arm visualization
        self._create_visualization(left_col)
        
        # Control buttons
        self._create_controls(left_col)
        
        # === Right Column Content ===
        
        # Patient info
        self._create_patient_info(right_col)
        
        # Real-time metrics
        self._create_metrics(right_col)
        
        # Exercise parameters
        self._create_parameters(right_col)
        
        # Session log
        self._create_session_log(right_col)
    
    def _create_session_header(self, parent):
        """Create session information header."""
        header = ctk.CTkFrame(
            parent,
            fg_color=COLORS['surface'],
            corner_radius=RADIUS['lg']
        )
        header.pack(fill='x', pady=(0, SPACING['md']))
        
        inner = ctk.CTkFrame(header, fg_color='transparent')
        inner.pack(fill='x', padx=SPACING['lg'], pady=SPACING['md'])
        
        # Left - Session info
        info_frame = ctk.CTkFrame(inner, fg_color='transparent')
        info_frame.pack(side='left', fill='x', expand=True)
        
        title_frame = ctk.CTkFrame(info_frame, fg_color='transparent')
        title_frame.pack(fill='x')
        
        ctk.CTkLabel(
            title_frame,
            text="Rehabilitation Session",
            font=FONTS['heading_md'],
            text_color=COLORS['text_primary']
        ).pack(side='left')
        
        self.status_badge = StatusBadge(title_frame, "Ready", "info")
        self.status_badge.pack(side='left', padx=SPACING['md'])
        
        ctk.CTkLabel(
            info_frame,
            text="Elbow Flexion/Extension • Intermediate Protocol",
            font=FONTS['body_md'],
            text_color=COLORS['text_secondary']
        ).pack(anchor='w', pady=(SPACING['xs'], 0))
        
        # Right - Timer
        timer_frame = ctk.CTkFrame(inner, fg_color='transparent')
        timer_frame.pack(side='right')
        
        ctk.CTkLabel(
            timer_frame,
            text="Session Time",
            font=FONTS['body_sm'],
            text_color=COLORS['text_secondary']
        ).pack()
        
        self.timer_label = ctk.CTkLabel(
            timer_frame,
            text="00:00:00",
            font=('Consolas', 32, 'bold'),
            text_color=COLORS['primary']
        )
        self.timer_label.pack()
    
    def _create_visualization(self, parent):
        """Create robot arm visualization."""
        viz_card = Card(parent, title="Robot Arm Visualization")
        viz_card.pack(fill='both', expand=True, pady=(0, SPACING['md']))
        
        # Canvas for arm visualization
        self.viz_canvas = tk.Canvas(
            viz_card.content,
            bg=COLORS['surface'],
            highlightthickness=0,
            height=350
        )
        self.viz_canvas.pack(fill='both', expand=True)
        
        # Bind resize
        self.viz_canvas.bind('<Configure>', self._on_canvas_resize)
        
        # Progress indicators below canvas
        progress_frame = ctk.CTkFrame(viz_card.content, fg_color='transparent')
        progress_frame.pack(fill='x', pady=SPACING['sm'])
        
        # Rep counter
        rep_frame = ctk.CTkFrame(progress_frame, fg_color='transparent')
        rep_frame.pack(side='left', expand=True)
        
        ctk.CTkLabel(
            rep_frame,
            text="Repetition",
            font=FONTS['body_sm'],
            text_color=COLORS['text_secondary']
        ).pack()
        
        self.rep_label = ctk.CTkLabel(
            rep_frame,
            text="1 / 10",
            font=FONTS['heading_md'],
            text_color=COLORS['text_primary']
        )
        self.rep_label.pack()
        
        # Set counter
        set_frame = ctk.CTkFrame(progress_frame, fg_color='transparent')
        set_frame.pack(side='left', expand=True)
        
        ctk.CTkLabel(
            set_frame,
            text="Set",
            font=FONTS['body_sm'],
            text_color=COLORS['text_secondary']
        ).pack()
        
        self.set_label = ctk.CTkLabel(
            set_frame,
            text="1 / 3",
            font=FONTS['heading_md'],
            text_color=COLORS['text_primary']
        )
        self.set_label.pack()
        
        # Progress bar
        prog_frame = ctk.CTkFrame(progress_frame, fg_color='transparent')
        prog_frame.pack(side='left', expand=True, fill='x', padx=SPACING['lg'])
        
        ctk.CTkLabel(
            prog_frame,
            text="Session Progress",
            font=FONTS['body_sm'],
            text_color=COLORS['text_secondary']
        ).pack()
        
        self.session_progress = ctk.CTkProgressBar(
            prog_frame,
            progress_color=COLORS['primary'],
            fg_color=COLORS['surface_dark'],
            height=12,
            corner_radius=6
        )
        self.session_progress.pack(fill='x', pady=SPACING['xs'])
        self.session_progress.set(0)
    
    def _create_controls(self, parent):
        """Create control buttons."""
        controls_frame = ctk.CTkFrame(
            parent,
            fg_color=COLORS['surface'],
            corner_radius=RADIUS['lg']
        )
        controls_frame.pack(fill='x')
        
        inner = ctk.CTkFrame(controls_frame, fg_color='transparent')
        inner.pack(fill='x', padx=SPACING['lg'], pady=SPACING['md'])
        
        # Main controls
        main_controls = ctk.CTkFrame(inner, fg_color='transparent')
        main_controls.pack(fill='x')
        
        # Start/Pause button
        self.start_btn = ctk.CTkButton(
            main_controls,
            text="▶️  Start Session",
            font=FONTS['button'],
            fg_color=COLORS['secondary'],
            hover_color=COLORS['secondary_hover'],
            corner_radius=RADIUS['md'],
            height=50,
            width=180,
            command=self._toggle_session
        )
        self.start_btn.pack(side='left', padx=SPACING['xs'])
        
        # Skip button
        self.skip_btn = ctk.CTkButton(
            main_controls,
            text="⏭️  Skip Exercise",
            font=FONTS['button'],
            fg_color=COLORS['primary'],
            hover_color=COLORS['primary_hover'],
            corner_radius=RADIUS['md'],
            height=50,
            width=150,
            command=self._skip_exercise
        )
        self.skip_btn.pack(side='left', padx=SPACING['xs'])
        
        # Reset button
        self.reset_btn = ctk.CTkButton(
            main_controls,
            text="🔄  Reset",
            font=FONTS['button'],
            fg_color=COLORS['surface_dark'],
            hover_color=COLORS['border'],
            text_color=COLORS['text_primary'],
            corner_radius=RADIUS['md'],
            height=50,
            width=120,
            command=self._reset_session
        )
        self.reset_btn.pack(side='left', padx=SPACING['xs'])
        
        # Emergency stop - always visible and prominent
        self.emergency_btn = ctk.CTkButton(
            main_controls,
            text="🛑  EMERGENCY STOP",
            font=('Segoe UI', 14, 'bold'),
            fg_color=COLORS['error'],
            hover_color='#DC2626',
            corner_radius=RADIUS['md'],
            height=50,
            width=200,
            command=self._emergency_stop
        )
        self.emergency_btn.pack(side='right', padx=SPACING['xs'])
    
    def _create_patient_info(self, parent):
        """Create patient information panel."""
        patient_card = Card(parent, title="Patient")
        patient_card.pack(fill='x', pady=(0, SPACING['md']))
        
        # Patient details
        patient_frame = ctk.CTkFrame(patient_card.content, fg_color='transparent')
        patient_frame.pack(fill='x')
        
        ctk.CTkLabel(
            patient_frame,
            text="👤",
            font=('Segoe UI Emoji', 40)
        ).pack(side='left')
        
        info = ctk.CTkFrame(patient_frame, fg_color='transparent')
        info.pack(side='left', fill='x', expand=True, padx=SPACING['sm'])
        
        ctk.CTkLabel(
            info,
            text="John Smith",
            font=FONTS['heading_sm'],
            text_color=COLORS['text_primary'],
            anchor='w'
        ).pack(fill='x')
        
        ctk.CTkLabel(
            info,
            text="65 years • Right Hemiparesis",
            font=FONTS['body_sm'],
            text_color=COLORS['text_secondary'],
            anchor='w'
        ).pack(fill='x')
        
        StatusBadge(info, "Session #15", "info").pack(anchor='w')
    
    def _create_metrics(self, parent):
        """Create real-time metrics panel."""
        metrics_card = Card(parent, title="Real-time Metrics")
        metrics_card.pack(fill='x', pady=(0, SPACING['md']))
        
        # Gauges row
        gauges_frame = ctk.CTkFrame(metrics_card.content, fg_color='transparent')
        gauges_frame.pack(fill='x', pady=SPACING['sm'])
        
        self.fatigue_gauge = GaugeWidget(
            gauges_frame, "Fatigue", 0.25, color=COLORS['warning']
        )
        self.fatigue_gauge.pack(side='left', expand=True)
        
        self.rom_gauge = GaugeWidget(
            gauges_frame, "ROM", 0.85, color=COLORS['secondary']
        )
        self.rom_gauge.pack(side='left', expand=True)
        
        # Numeric metrics
        metrics_grid = ctk.CTkFrame(metrics_card.content, fg_color='transparent')
        metrics_grid.pack(fill='x', pady=SPACING['sm'])
        
        metrics = [
            ("Shoulder Torque", "0.00 Nm", "shoulder_torque"),
            ("Elbow Torque", "0.00 Nm", "elbow_torque"),
            ("Velocity", "0.0 °/s", "velocity"),
            ("Position", "0.0°", "position"),
        ]
        
        self.metric_labels = {}
        
        for i, (name, value, key) in enumerate(metrics):
            frame = ctk.CTkFrame(
                metrics_grid,
                fg_color=COLORS['surface_dark'],
                corner_radius=RADIUS['sm']
            )
            frame.grid(row=i // 2, column=i % 2, padx=SPACING['xs'], pady=SPACING['xs'], sticky='ew')
            
            ctk.CTkLabel(
                frame,
                text=name,
                font=FONTS['body_sm'],
                text_color=COLORS['text_secondary']
            ).pack(anchor='w', padx=SPACING['sm'], pady=(SPACING['xs'], 0))
            
            label = ctk.CTkLabel(
                frame,
                text=value,
                font=FONTS['heading_sm'],
                text_color=COLORS['text_primary']
            )
            label.pack(anchor='w', padx=SPACING['sm'], pady=(0, SPACING['xs']))
            self.metric_labels[key] = label
        
        metrics_grid.grid_columnconfigure(0, weight=1)
        metrics_grid.grid_columnconfigure(1, weight=1)
    
    def _create_parameters(self, parent):
        """Create exercise parameters panel."""
        params_card = Card(parent, title="Exercise Parameters")
        params_card.pack(fill='x', pady=(0, SPACING['md']))
        
        # Parameter sliders
        params = [
            ("Assistance Level", 30, "%"),
            ("Movement Speed", 25, "°/s"),
            ("Range of Motion", 90, "°"),
        ]
        
        self.param_sliders = {}
        
        for name, value, unit in params:
            frame = ctk.CTkFrame(params_card.content, fg_color='transparent')
            frame.pack(fill='x', pady=SPACING['xs'])
            
            header = ctk.CTkFrame(frame, fg_color='transparent')
            header.pack(fill='x')
            
            ctk.CTkLabel(
                header,
                text=name,
                font=FONTS['body_sm'],
                text_color=COLORS['text_secondary']
            ).pack(side='left')
            
            value_label = ctk.CTkLabel(
                header,
                text=f"{value} {unit}",
                font=FONTS['body_md'],
                text_color=COLORS['text_primary']
            )
            value_label.pack(side='right')
            
            slider = ctk.CTkSlider(
                frame,
                from_=0,
                to=100,
                number_of_steps=100,
                progress_color=COLORS['primary'],
                button_color=COLORS['primary'],
                button_hover_color=COLORS['primary_hover'],
                fg_color=COLORS['surface_dark']
            )
            slider.pack(fill='x', pady=(SPACING['xs'], 0))
            slider.set(value)
            
            # Update label on slider change
            def make_callback(lbl, u):
                return lambda v: lbl.configure(text=f"{int(v)} {u}")
            
            slider.configure(command=make_callback(value_label, unit))
            
            self.param_sliders[name] = slider
    
    def _create_session_log(self, parent):
        """Create session activity log."""
        log_card = Card(parent, title="Session Log")
        log_card.pack(fill='both', expand=True)
        
        self.log_frame = ctk.CTkScrollableFrame(
            log_card.content,
            fg_color='transparent',
            height=150
        )
        self.log_frame.pack(fill='both', expand=True)
        
        # Add initial log entries
        self._add_log("System initialized", "info")
        self._add_log("Patient loaded: John Smith", "info")
        self._add_log("Protocol: Intermediate", "info")
    
    def _add_log(self, message: str, level: str = "info"):
        """Add entry to session log."""
        colors = {
            "info": COLORS['info'],
            "success": COLORS['success'],
            "warning": COLORS['warning'],
            "error": COLORS['error'],
        }
        
        icons = {
            "info": "ℹ️",
            "success": "✅",
            "warning": "⚠️",
            "error": "❌",
        }
        
        entry = ctk.CTkFrame(self.log_frame, fg_color='transparent')
        entry.pack(fill='x', pady=1)
        
        time_str = datetime.now().strftime("%H:%M:%S")
        
        ctk.CTkLabel(
            entry,
            text=f"{icons.get(level, 'ℹ️')} [{time_str}]",
            font=FONTS['body_sm'],
            text_color=COLORS['text_muted']
        ).pack(side='left')
        
        ctk.CTkLabel(
            entry,
            text=message,
            font=FONTS['body_sm'],
            text_color=colors.get(level, COLORS['text_primary'])
        ).pack(side='left', padx=SPACING['xs'])
    
    def _on_canvas_resize(self, event):
        """Handle canvas resize."""
        self._draw_arm()
    
    def _draw_arm(self):
        """Draw the robot arm visualization."""
        self.viz_canvas.delete('all')
        
        width = self.viz_canvas.winfo_width()
        height = self.viz_canvas.winfo_height()
        
        if width < 10 or height < 10:
            return
        
        # Center point (shoulder)
        cx = width // 2
        cy = height // 2 - 30
        
        # Arm segment lengths
        upper_arm_len = min(width, height) * 0.25
        forearm_len = min(width, height) * 0.22
        
        # Calculate joint positions
        shoulder_angle = math.radians(self.angle)
        elbow_angle = math.radians(self.angle * 0.7)  # Coupled motion
        
        # Upper arm end (elbow position)
        elbow_x = cx + upper_arm_len * math.sin(shoulder_angle)
        elbow_y = cy + upper_arm_len * math.cos(shoulder_angle)
        
        # Forearm end (hand position)
        hand_x = elbow_x + forearm_len * math.sin(shoulder_angle + elbow_angle)
        hand_y = elbow_y + forearm_len * math.cos(shoulder_angle + elbow_angle)
        
        # Draw reference lines (ROM limits)
        for angle in [-45, 45]:
            rad = math.radians(angle)
            end_x = cx + (upper_arm_len + forearm_len) * math.sin(rad)
            end_y = cy + (upper_arm_len + forearm_len) * math.cos(rad)
            self.viz_canvas.create_line(
                cx, cy, end_x, end_y,
                fill=COLORS['border'],
                width=1,
                dash=(4, 4)
            )
        
        # Draw target arc
        self.viz_canvas.create_arc(
            cx - 60, cy - 60, cx + 60, cy + 60,
            start=-45, extent=90,
            style='arc',
            outline=COLORS['primary_light'],
            width=20
        )
        
        # Draw shoulder joint
        self.viz_canvas.create_oval(
            cx - 15, cy - 15, cx + 15, cy + 15,
            fill=COLORS['primary'],
            outline=COLORS['primary_hover'],
            width=2
        )
        
        # Draw upper arm
        self.viz_canvas.create_line(
            cx, cy, elbow_x, elbow_y,
            fill=COLORS['secondary'],
            width=16,
            capstyle='round'
        )
        
        # Draw elbow joint
        self.viz_canvas.create_oval(
            elbow_x - 12, elbow_y - 12, elbow_x + 12, elbow_y + 12,
            fill=COLORS['primary'],
            outline=COLORS['primary_hover'],
            width=2
        )
        
        # Draw forearm
        self.viz_canvas.create_line(
            elbow_x, elbow_y, hand_x, hand_y,
            fill=COLORS['accent'],
            width=12,
            capstyle='round'
        )
        
        # Draw hand
        self.viz_canvas.create_oval(
            hand_x - 10, hand_y - 10, hand_x + 10, hand_y + 10,
            fill=COLORS['warning'],
            outline=COLORS['text_primary'],
            width=2
        )
        
        # Draw angle indicator
        angle_text = f"{self.angle:.1f}°"
        self.viz_canvas.create_text(
            cx, cy - 50,
            text=angle_text,
            font=FONTS['heading_sm'],
            fill=COLORS['text_primary']
        )
        
        # Status indicator
        status_text = "ACTIVE" if self.is_running else "READY"
        status_color = COLORS['success'] if self.is_running else COLORS['text_muted']
        self.viz_canvas.create_text(
            width - 60, 30,
            text=f"● {status_text}",
            font=FONTS['body_md'],
            fill=status_color
        )
        
        # Draw labels
        self.viz_canvas.create_text(
            cx, height - 20,
            text="Master (Sound Arm) ←→ Follower (Paretic Arm)",
            font=FONTS['body_sm'],
            fill=COLORS['text_secondary']
        )
    
    def _start_animation(self):
        """Start the arm animation loop."""
        self._animate()
    
    def _animate(self):
        """Animation loop."""
        if self.is_running:
            # Simulate sinusoidal movement
            self.target_angle = 45 * math.sin(self.session_time * 0.5)
            self.session_time += 0.05
            
            # Update timer display
            total_seconds = int(self.session_time * 20)
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            seconds = total_seconds % 60
            self.timer_label.configure(text=f"{hours:02d}:{minutes:02d}:{seconds:02d}")
            
            # Update metrics with simulated values
            self._update_simulated_metrics()
        
        # Smooth angle transition
        self.angle += (self.target_angle - self.angle) * 0.1
        
        self._draw_arm()
        
        # Schedule next frame
        self.after(50, self._animate)
    
    def _update_simulated_metrics(self):
        """Update metrics with simulated values."""
        # Simulated sensor data
        shoulder_torque = 5.0 + 2.0 * math.sin(self.session_time)
        elbow_torque = 2.5 + 1.0 * math.cos(self.session_time)
        velocity = abs(45 * 0.5 * math.cos(self.session_time * 0.5))
        position = self.angle
        
        self.metric_labels['shoulder_torque'].configure(text=f"{shoulder_torque:.2f} Nm")
        self.metric_labels['elbow_torque'].configure(text=f"{elbow_torque:.2f} Nm")
        self.metric_labels['velocity'].configure(text=f"{velocity:.1f} °/s")
        self.metric_labels['position'].configure(text=f"{position:.1f}°")
        
        # Update fatigue (slowly increases)
        fatigue = min(0.9, 0.1 + self.session_time * 0.005)
        self.fatigue_gauge.update_value(fatigue)
        
        # Update ROM
        rom = max(0.5, 0.95 - fatigue * 0.3)
        self.rom_gauge.update_value(rom)
        
        # Update progress
        progress = min(1.0, self.session_time * 0.02)
        self.session_progress.set(progress)
        
        # Simulate rep counting
        if int(self.session_time * 2) % 8 == 0:
            self._increment_rep()
    
    def _increment_rep(self):
        """Increment repetition counter."""
        if self.current_rep < self.total_reps:
            self.current_rep += 1
        else:
            self.current_rep = 1
            if self.current_set < self.total_sets:
                self.current_set += 1
                self._add_log(f"Set {self.current_set} started", "success")
        
        self.rep_label.configure(text=f"{self.current_rep} / {self.total_reps}")
        self.set_label.configure(text=f"{self.current_set} / {self.total_sets}")
    
    def _toggle_session(self):
        """Start or pause the session."""
        self.is_running = not self.is_running
        
        if self.is_running:
            self.start_btn.configure(text="⏸️  Pause Session", fg_color=COLORS['warning'])
            self.status_badge = StatusBadge(self.status_badge.master, "In Progress", "active")
            self._add_log("Session started", "success")
        else:
            self.start_btn.configure(text="▶️  Resume Session", fg_color=COLORS['secondary'])
            self._add_log("Session paused", "warning")
    
    def _skip_exercise(self):
        """Skip to next exercise."""
        self._add_log("Exercise skipped", "warning")
        self.current_rep = 1
        self.current_set += 1
        if self.current_set > self.total_sets:
            self.current_set = 1
        self.rep_label.configure(text=f"{self.current_rep} / {self.total_reps}")
        self.set_label.configure(text=f"{self.current_set} / {self.total_sets}")
    
    def _reset_session(self):
        """Reset the session."""
        self.is_running = False
        self.session_time = 0
        self.current_rep = 1
        self.current_set = 1
        self.angle = 0
        self.target_angle = 0
        
        self.start_btn.configure(text="▶️  Start Session", fg_color=COLORS['secondary'])
        self.timer_label.configure(text="00:00:00")
        self.rep_label.configure(text="1 / 10")
        self.set_label.configure(text="1 / 3")
        self.session_progress.set(0)
        self.fatigue_gauge.update_value(0)
        self.rom_gauge.update_value(0.85)
        
        self._add_log("Session reset", "info")
    
    def _emergency_stop(self):
        """Trigger emergency stop."""
        self.is_running = False
        self.start_btn.configure(text="▶️  Start Session", fg_color=COLORS['secondary'])
        
        self._add_log("⚠️ EMERGENCY STOP ACTIVATED", "error")
        
        if self.on_emergency_stop:
            self.on_emergency_stop()
        
        # Show warning dialog
        dialog = ctk.CTkToplevel(self)
        dialog.title("Emergency Stop")
        dialog.geometry("400x200")
        dialog.resizable(False, False)
        dialog.grab_set()
        
        # Center the dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() - 400) // 2
        y = (dialog.winfo_screenheight() - 200) // 2
        dialog.geometry(f"+{x}+{y}")
        
        frame = ctk.CTkFrame(dialog, fg_color=COLORS['error'])
        frame.pack(fill='both', expand=True)
        
        ctk.CTkLabel(
            frame,
            text="🛑",
            font=('Segoe UI Emoji', 48)
        ).pack(pady=SPACING['md'])
        
        ctk.CTkLabel(
            frame,
            text="EMERGENCY STOP ACTIVATED",
            font=FONTS['heading_md'],
            text_color='white'
        ).pack()
        
        ctk.CTkLabel(
            frame,
            text="Robot motion has been stopped for safety.",
            font=FONTS['body_md'],
            text_color='white'
        ).pack(pady=SPACING['xs'])
        
        ctk.CTkButton(
            frame,
            text="Acknowledge",
            fg_color='white',
            text_color=COLORS['error'],
            hover_color=COLORS['surface_dark'],
            command=dialog.destroy
        ).pack(pady=SPACING['md'])
