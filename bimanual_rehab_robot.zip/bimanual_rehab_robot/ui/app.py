"""
Main Application for Bimanual Rehabilitation Robot System.
Entry point with navigation and view management.
"""

import customtkinter as ctk
from typing import Optional, Dict, Callable
import sys
import os

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from .config import COLORS, FONTS, SPACING, RADIUS, NAV_ITEMS, WINDOW
from .widgets import NavigationItem, IconButton
from .login_screen import LoginScreen
from .dashboard import DashboardView
from .session_control import SessionControlView


class MainApplication(ctk.CTk):
    """
    Main application window for Bimanual Rehabilitation Robot System.
    """
    
    def __init__(self):
        super().__init__()
        
        # Configure window
        self.title("Bimanual Rehabilitation Robot System")
        self.geometry(f"{WINDOW['width']}x{WINDOW['height']}")
        self.minsize(WINDOW['min_width'], WINDOW['min_height'])
        
        # Set theme
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")
        
        # Configure colors
        self.configure(fg_color=COLORS['background'])
        
        # State
        self.current_user: Optional[Dict] = None
        self.current_view: Optional[str] = None
        self.nav_items: Dict[str, NavigationItem] = {}
        
        # Create main container
        self.main_container = ctk.CTkFrame(self, fg_color=COLORS['background'])
        self.main_container.pack(fill='both', expand=True)
        
        # Show login screen initially
        self._show_login()
    
    def _show_login(self):
        """Display the login screen."""
        # Clear main container
        for widget in self.main_container.winfo_children():
            widget.destroy()
        
        self.login_screen = LoginScreen(
            self.main_container,
            on_login=self._handle_login
        )
        self.login_screen.pack(fill='both', expand=True)
    
    def _handle_login(self, username: str, password: str, role: str):
        """
        Handle login attempt.
        
        In production, this would validate credentials against a database.
        For demo purposes, accept any non-empty credentials.
        """
        # Demo: Accept any login
        # In production: Validate against database
        if username and password:
            self.current_user = {
                'username': username,
                'role': role,
                'name': username.title()  # Capitalize for display
            }
            self._show_main_app()
        else:
            self.login_screen.show_error("Please enter valid credentials")
    
    def _show_main_app(self):
        """Display the main application with navigation."""
        # Clear main container
        for widget in self.main_container.winfo_children():
            widget.destroy()
        
        # Create layout: sidebar + content
        self._create_sidebar()
        self._create_content_area()
        
        # Show default view (dashboard)
        self._navigate_to('dashboard')
    
    def _create_sidebar(self):
        """Create the navigation sidebar."""
        self.sidebar = ctk.CTkFrame(
            self.main_container,
            fg_color=COLORS['surface'],
            corner_radius=0,
            width=250
        )
        self.sidebar.pack(side='left', fill='y')
        self.sidebar.pack_propagate(False)
        
        # Logo/Brand section
        brand_frame = ctk.CTkFrame(self.sidebar, fg_color='transparent')
        brand_frame.pack(fill='x', padx=SPACING['md'], pady=SPACING['lg'])
        
        logo_label = ctk.CTkLabel(
            brand_frame,
            text="🤖",
            font=('Segoe UI Emoji', 36)
        )
        logo_label.pack()
        
        title_label = ctk.CTkLabel(
            brand_frame,
            text="Rehab Robot",
            font=FONTS['heading_sm'],
            text_color=COLORS['text_primary']
        )
        title_label.pack()
        
        subtitle_label = ctk.CTkLabel(
            brand_frame,
            text="Control System",
            font=FONTS['body_sm'],
            text_color=COLORS['text_secondary']
        )
        subtitle_label.pack()
        
        # Separator
        sep = ctk.CTkFrame(self.sidebar, height=1, fg_color=COLORS['border'])
        sep.pack(fill='x', padx=SPACING['md'], pady=SPACING['sm'])
        
        # Navigation items
        nav_frame = ctk.CTkFrame(self.sidebar, fg_color='transparent')
        nav_frame.pack(fill='x', padx=SPACING['sm'])
        
        # Get nav items for current role
        role = self.current_user['role']
        items = NAV_ITEMS.get(role, NAV_ITEMS['patient'])
        
        for nav_id, nav_text, nav_icon in items:
            nav_item = NavigationItem(
                nav_frame,
                icon=nav_icon,
                text=nav_text,
                command=lambda n=nav_id: self._navigate_to(n),
                selected=(nav_id == 'dashboard')
            )
            nav_item.pack(fill='x', pady=SPACING['xs'])
            self.nav_items[nav_id] = nav_item
        
        # Spacer
        spacer = ctk.CTkFrame(self.sidebar, fg_color='transparent')
        spacer.pack(fill='both', expand=True)
        
        # User section at bottom
        user_frame = ctk.CTkFrame(
            self.sidebar,
            fg_color=COLORS['surface_dark'],
            corner_radius=RADIUS['md']
        )
        user_frame.pack(fill='x', padx=SPACING['sm'], pady=SPACING['md'])
        
        user_inner = ctk.CTkFrame(user_frame, fg_color='transparent')
        user_inner.pack(fill='x', padx=SPACING['sm'], pady=SPACING['sm'])
        
        # User avatar
        role_icons = {
            'doctor': '👨‍⚕️',
            'physiotherapist': '🏃',
            'caregiver': '🤝',
            'patient': '🧑',
        }
        
        avatar_label = ctk.CTkLabel(
            user_inner,
            text=role_icons.get(role, '👤'),
            font=('Segoe UI Emoji', 28)
        )
        avatar_label.pack(side='left')
        
        # User info
        info_frame = ctk.CTkFrame(user_inner, fg_color='transparent')
        info_frame.pack(side='left', fill='x', expand=True, padx=SPACING['xs'])
        
        name_label = ctk.CTkLabel(
            info_frame,
            text=self.current_user['name'],
            font=FONTS['body_md'],
            text_color=COLORS['text_primary'],
            anchor='w'
        )
        name_label.pack(fill='x')
        
        role_label = ctk.CTkLabel(
            info_frame,
            text=role.title(),
            font=FONTS['body_sm'],
            text_color=COLORS['text_secondary'],
            anchor='w'
        )
        role_label.pack(fill='x')
        
        # Logout button
        logout_btn = IconButton(
            user_inner,
            icon="🚪",
            command=self._logout
        )
        logout_btn.pack(side='right')
    
    def _create_content_area(self):
        """Create the main content area."""
        self.content_area = ctk.CTkFrame(
            self.main_container,
            fg_color=COLORS['background'],
            corner_radius=0
        )
        self.content_area.pack(side='left', fill='both', expand=True)
        
        # Header bar
        self.header = ctk.CTkFrame(
            self.content_area,
            fg_color=COLORS['surface'],
            height=60,
            corner_radius=0
        )
        self.header.pack(fill='x')
        self.header.pack_propagate(False)
        
        header_inner = ctk.CTkFrame(self.header, fg_color='transparent')
        header_inner.pack(fill='both', expand=True, padx=SPACING['lg'])
        
        # Page title
        self.page_title = ctk.CTkLabel(
            header_inner,
            text="Dashboard",
            font=FONTS['heading_md'],
            text_color=COLORS['text_primary']
        )
        self.page_title.pack(side='left', pady=SPACING['md'])
        
        # Header actions
        actions_frame = ctk.CTkFrame(header_inner, fg_color='transparent')
        actions_frame.pack(side='right', pady=SPACING['sm'])
        
        # Notifications button
        notif_btn = IconButton(actions_frame, icon="🔔")
        notif_btn.pack(side='left', padx=SPACING['xs'])
        
        # Settings button
        settings_btn = IconButton(actions_frame, icon="⚙️")
        settings_btn.pack(side='left', padx=SPACING['xs'])
        
        # Help button
        help_btn = IconButton(actions_frame, icon="❓")
        help_btn.pack(side='left', padx=SPACING['xs'])
        
        # Content frame (where views are loaded)
        self.view_container = ctk.CTkFrame(
            self.content_area,
            fg_color=COLORS['background']
        )
        self.view_container.pack(fill='both', expand=True)
    
    def _navigate_to(self, view_id: str):
        """Navigate to a specific view."""
        # Update nav selection
        for nav_id, nav_item in self.nav_items.items():
            nav_item.set_selected(nav_id == view_id)
        
        # Clear current view
        for widget in self.view_container.winfo_children():
            widget.destroy()
        
        self.current_view = view_id
        
        # Page titles
        titles = {
            'dashboard': 'Dashboard',
            'patients': 'Patient Management',
            'session': 'Session Control',
            'protocols': 'Exercise Protocols',
            'reports': 'Reports & Analytics',
            'settings': 'Settings',
            'patient': 'Patient Information',
            'progress': 'Progress Tracking',
            'schedule': 'Schedule',
            'exercises': 'My Exercises',
            'profile': 'My Profile',
        }
        
        self.page_title.configure(text=titles.get(view_id, view_id.title()))
        
        # Load appropriate view
        if view_id == 'dashboard':
            view = DashboardView(
                self.view_container,
                role=self.current_user['role'],
                user_name=self.current_user['name']
            )
        elif view_id == 'session':
            view = SessionControlView(
                self.view_container,
                on_emergency_stop=self._handle_emergency_stop
            )
        elif view_id in ['patients', 'protocols', 'reports']:
            view = self._create_placeholder_view(view_id)
        else:
            view = self._create_placeholder_view(view_id)
        
        view.pack(fill='both', expand=True)
    
    def _create_placeholder_view(self, view_id: str) -> ctk.CTkFrame:
        """Create a placeholder view for unimplemented features."""
        view = ctk.CTkFrame(self.view_container, fg_color=COLORS['background'])
        
        center_frame = ctk.CTkFrame(view, fg_color='transparent')
        center_frame.place(relx=0.5, rely=0.5, anchor='center')
        
        icon_map = {
            'patients': '👥',
            'protocols': '📋',
            'reports': '📊',
            'settings': '⚙️',
            'patient': '👤',
            'progress': '📈',
            'schedule': '📅',
            'exercises': '🏋️',
            'profile': '👤',
        }
        
        ctk.CTkLabel(
            center_frame,
            text=icon_map.get(view_id, '📄'),
            font=('Segoe UI Emoji', 64)
        ).pack()
        
        ctk.CTkLabel(
            center_frame,
            text=view_id.replace('_', ' ').title(),
            font=FONTS['heading_lg'],
            text_color=COLORS['text_primary']
        ).pack(pady=SPACING['sm'])
        
        ctk.CTkLabel(
            center_frame,
            text="This feature is coming soon!",
            font=FONTS['body_md'],
            text_color=COLORS['text_secondary']
        ).pack()
        
        return view
    
    def _handle_emergency_stop(self):
        """Handle emergency stop from session control."""
        print("EMERGENCY STOP TRIGGERED!")
        # In production: Send stop command to robot
    
    def _logout(self):
        """Log out current user."""
        self.current_user = None
        self.current_view = None
        self.nav_items = {}
        self._show_login()


def run_app():
    """Run the application."""
    app = MainApplication()
    app.mainloop()


if __name__ == "__main__":
    run_app()
