"""
Dashboard Views for Different User Roles.
"""

import customtkinter as ctk
from typing import Callable, Optional, Dict, Any
from datetime import datetime
import random

from .config import COLORS, FONTS, SPACING, RADIUS
from .widgets import (
    Card, StatCard, PrimaryButton, SecondaryButton, OutlineButton,
    ProgressCard, DataTable, StatusBadge, GaugeWidget
)


class DashboardView(ctk.CTkFrame):
    """Main dashboard view - adapts based on user role."""
    
    def __init__(self, parent, role: str, user_name: str):
        super().__init__(parent, fg_color=COLORS['background'])
        
        self.role = role
        self.user_name = user_name
        
        self._create_ui()
    
    def _create_ui(self):
        """Create the dashboard UI."""
        # Scrollable container
        scroll_frame = ctk.CTkScrollableFrame(
            self,
            fg_color='transparent'
        )
        scroll_frame.pack(fill='both', expand=True, padx=SPACING['lg'], pady=SPACING['lg'])
        
        # Welcome header
        self._create_header(scroll_frame)
        
        # Stats cards row
        self._create_stats_section(scroll_frame)
        
        # Main content area
        content_frame = ctk.CTkFrame(scroll_frame, fg_color='transparent')
        content_frame.pack(fill='both', expand=True, pady=SPACING['lg'])
        
        # Left column (larger)
        left_col = ctk.CTkFrame(content_frame, fg_color='transparent')
        left_col.pack(side='left', fill='both', expand=True, padx=(0, SPACING['md']))
        
        # Right column (sidebar)
        right_col = ctk.CTkFrame(content_frame, fg_color='transparent', width=350)
        right_col.pack(side='right', fill='y')
        right_col.pack_propagate(False)
        
        # Create role-specific content
        if self.role == 'doctor':
            self._create_doctor_content(left_col, right_col)
        elif self.role == 'physiotherapist':
            self._create_physio_content(left_col, right_col)
        elif self.role == 'caregiver':
            self._create_caregiver_content(left_col, right_col)
        else:  # patient
            self._create_patient_content(left_col, right_col)
    
    def _create_header(self, parent):
        """Create welcome header."""
        header_frame = ctk.CTkFrame(parent, fg_color='transparent')
        header_frame.pack(fill='x', pady=(0, SPACING['lg']))
        
        # Greeting
        time_greeting = self._get_time_greeting()
        greeting_label = ctk.CTkLabel(
            header_frame,
            text=f"{time_greeting}, {self.user_name}!",
            font=FONTS['heading_lg'],
            text_color=COLORS['text_primary'],
            anchor='w'
        )
        greeting_label.pack(anchor='w')
        
        # Date
        date_str = datetime.now().strftime("%A, %B %d, %Y")
        date_label = ctk.CTkLabel(
            header_frame,
            text=date_str,
            font=FONTS['body_md'],
            text_color=COLORS['text_secondary'],
            anchor='w'
        )
        date_label.pack(anchor='w')
    
    def _get_time_greeting(self) -> str:
        """Get appropriate greeting based on time of day."""
        hour = datetime.now().hour
        if hour < 12:
            return "Good morning"
        elif hour < 17:
            return "Good afternoon"
        else:
            return "Good evening"
    
    def _create_stats_section(self, parent):
        """Create statistics cards."""
        stats_frame = ctk.CTkFrame(parent, fg_color='transparent')
        stats_frame.pack(fill='x', pady=(0, SPACING['md']))
        
        if self.role == 'doctor':
            stats = [
                ('👥', '24', 'Total Patients', COLORS['primary']),
                ('📅', '8', 'Sessions Today', COLORS['secondary']),
                ('📈', '85%', 'Avg. Progress', COLORS['accent']),
                ('⚡', '3', 'Active Now', COLORS['warning']),
            ]
        elif self.role == 'physiotherapist':
            stats = [
                ('👥', '12', 'My Patients', COLORS['primary']),
                ('📅', '5', 'Sessions Today', COLORS['secondary']),
                ('⏱️', '45m', 'Avg. Duration', COLORS['accent']),
                ('✅', '3', 'Completed', COLORS['success']),
            ]
        elif self.role == 'caregiver':
            stats = [
                ('💪', '75%', 'Today\'s Progress', COLORS['primary']),
                ('📅', '2', 'Sessions Done', COLORS['secondary']),
                ('🎯', '3', 'Exercises Left', COLORS['accent']),
                ('⭐', '4.5', 'Performance', COLORS['warning']),
            ]
        else:  # patient
            stats = [
                ('🔥', '12', 'Day Streak', COLORS['warning']),
                ('💪', '156', 'Exercises Done', COLORS['primary']),
                ('📈', '78%', 'Recovery', COLORS['secondary']),
                ('⏱️', '2.5h', 'This Week', COLORS['accent']),
            ]
        
        for i, (icon, value, label, color) in enumerate(stats):
            stat_card = StatCard(stats_frame, icon, value, label, color)
            stat_card.pack(side='left', fill='both', expand=True, padx=SPACING['xs'])
    
    def _create_doctor_content(self, left_col, right_col):
        """Create doctor-specific dashboard content."""
        # Recent patients table
        patients_card = Card(left_col, title="Recent Patients")
        patients_card.pack(fill='both', expand=True)
        
        # Table
        table = DataTable(
            patients_card.content,
            columns=[
                ('Name', 150),
                ('Age', 60),
                ('Condition', 150),
                ('Progress', 100),
                ('Last Session', 120),
            ]
        )
        table.pack(fill='both', expand=True)
        
        # Sample data
        patients = [
            ('John Smith', '65', 'Right Hemiparesis', '75%', '2 hours ago'),
            ('Mary Johnson', '58', 'Left Hemiparesis', '82%', 'Yesterday'),
            ('Robert Davis', '72', 'Bilateral', '45%', '3 days ago'),
            ('Sarah Wilson', '61', 'Right Hemiparesis', '90%', 'Today'),
            ('Michael Brown', '55', 'Left Hemiparesis', '60%', '1 week ago'),
        ]
        
        for patient in patients:
            table.add_row(patient)
        
        # Right sidebar - Upcoming sessions
        sessions_card = Card(right_col, title="Today's Schedule")
        sessions_card.pack(fill='x', pady=(0, SPACING['md']))
        
        sessions = [
            ('09:00', 'John Smith', 'Elbow Exercise'),
            ('10:30', 'Mary Johnson', 'Full Protocol'),
            ('14:00', 'Sarah Wilson', 'Assessment'),
        ]
        
        for time, name, exercise in sessions:
            session_item = ctk.CTkFrame(sessions_card.content, fg_color='transparent')
            session_item.pack(fill='x', pady=SPACING['xs'])
            
            time_label = ctk.CTkLabel(
                session_item,
                text=time,
                font=FONTS['body_md'],
                text_color=COLORS['primary'],
                width=60
            )
            time_label.pack(side='left')
            
            info_frame = ctk.CTkFrame(session_item, fg_color='transparent')
            info_frame.pack(side='left', fill='x', expand=True)
            
            name_label = ctk.CTkLabel(
                info_frame,
                text=name,
                font=FONTS['body_md'],
                text_color=COLORS['text_primary'],
                anchor='w'
            )
            name_label.pack(fill='x')
            
            ex_label = ctk.CTkLabel(
                info_frame,
                text=exercise,
                font=FONTS['body_sm'],
                text_color=COLORS['text_secondary'],
                anchor='w'
            )
            ex_label.pack(fill='x')
        
        # Quick actions
        actions_card = Card(right_col, title="Quick Actions")
        actions_card.pack(fill='x')
        
        PrimaryButton(
            actions_card.content,
            text="📋 New Protocol"
        ).pack(fill='x', pady=SPACING['xs'])
        
        SecondaryButton(
            actions_card.content,
            text="👤 Add Patient"
        ).pack(fill='x', pady=SPACING['xs'])
        
        OutlineButton(
            actions_card.content,
            text="📊 View Reports"
        ).pack(fill='x', pady=SPACING['xs'])
    
    def _create_physio_content(self, left_col, right_col):
        """Create physiotherapist-specific dashboard content."""
        # Current/Next session card
        session_card = Card(left_col, title="Current Session")
        session_card.pack(fill='x', pady=(0, SPACING['md']))
        
        session_content = ctk.CTkFrame(session_card.content, fg_color='transparent')
        session_content.pack(fill='x')
        
        # Patient info
        patient_frame = ctk.CTkFrame(session_content, fg_color='transparent')
        patient_frame.pack(fill='x', pady=SPACING['sm'])
        
        avatar = ctk.CTkLabel(
            patient_frame,
            text="👤",
            font=('Segoe UI Emoji', 48)
        )
        avatar.pack(side='left', padx=(0, SPACING['md']))
        
        info_frame = ctk.CTkFrame(patient_frame, fg_color='transparent')
        info_frame.pack(side='left', fill='x', expand=True)
        
        ctk.CTkLabel(
            info_frame,
            text="John Smith",
            font=FONTS['heading_sm'],
            text_color=COLORS['text_primary'],
            anchor='w'
        ).pack(fill='x')
        
        ctk.CTkLabel(
            info_frame,
            text="Right Hemiparesis • Session #15",
            font=FONTS['body_md'],
            text_color=COLORS['text_secondary'],
            anchor='w'
        ).pack(fill='x')
        
        StatusBadge(info_frame, "In Progress", "active").pack(anchor='w', pady=SPACING['xs'])
        
        # Session actions
        action_frame = ctk.CTkFrame(patient_frame, fg_color='transparent')
        action_frame.pack(side='right')
        
        PrimaryButton(
            action_frame,
            text="▶️ Continue Session",
            width=160
        ).pack(pady=SPACING['xs'])
        
        OutlineButton(
            action_frame,
            text="⏸️ Pause",
            width=160
        ).pack(pady=SPACING['xs'])
        
        # Progress section
        progress_frame = ctk.CTkFrame(session_card.content, fg_color='transparent')
        progress_frame.pack(fill='x', pady=SPACING['md'])
        
        ProgressCard(
            progress_frame,
            "Session Progress",
            0.65,
            COLORS['primary']
        ).pack(side='left', fill='x', expand=True, padx=(0, SPACING['xs']))
        
        ProgressCard(
            progress_frame,
            "Overall Recovery",
            0.75,
            COLORS['secondary']
        ).pack(side='left', fill='x', expand=True, padx=(SPACING['xs'], 0))
        
        # Patient list
        patients_card = Card(left_col, title="My Patients")
        patients_card.pack(fill='both', expand=True)
        
        table = DataTable(
            patients_card.content,
            columns=[
                ('Patient', 150),
                ('Protocol', 120),
                ('Progress', 80),
                ('Next Session', 100),
            ]
        )
        table.pack(fill='both', expand=True)
        
        patients = [
            ('John Smith', 'Intermediate', '75%', 'Now'),
            ('Mary Johnson', 'Advanced', '82%', '10:30'),
            ('Robert Davis', 'Beginner', '45%', 'Tomorrow'),
            ('Sarah Wilson', 'Advanced', '90%', '14:00'),
        ]
        
        for p in patients:
            table.add_row(p)
        
        # Right sidebar - Real-time metrics
        metrics_card = Card(right_col, title="Live Metrics")
        metrics_card.pack(fill='x', pady=(0, SPACING['md']))
        
        gauges_frame = ctk.CTkFrame(metrics_card.content, fg_color='transparent')
        gauges_frame.pack(fill='x')
        
        GaugeWidget(
            gauges_frame,
            "Fatigue",
            0.35,
            color=COLORS['warning']
        ).pack(side='left', expand=True)
        
        GaugeWidget(
            gauges_frame,
            "ROM",
            0.78,
            color=COLORS['secondary']
        ).pack(side='left', expand=True)
        
        # Recent activity
        activity_card = Card(right_col, title="Recent Activity")
        activity_card.pack(fill='x')
        
        activities = [
            ("✅", "Set 2 completed", "2 min ago"),
            ("⚡", "Fatigue detected", "5 min ago"),
            ("📊", "Parameters updated", "8 min ago"),
            ("▶️", "Session started", "15 min ago"),
        ]
        
        for icon, text, time in activities:
            item = ctk.CTkFrame(activity_card.content, fg_color='transparent')
            item.pack(fill='x', pady=SPACING['xs'])
            
            ctk.CTkLabel(item, text=icon, font=('Segoe UI Emoji', 16)).pack(side='left')
            ctk.CTkLabel(
                item, text=text, font=FONTS['body_sm'],
                text_color=COLORS['text_primary']
            ).pack(side='left', padx=SPACING['xs'])
            ctk.CTkLabel(
                item, text=time, font=FONTS['body_sm'],
                text_color=COLORS['text_muted']
            ).pack(side='right')
    
    def _create_caregiver_content(self, left_col, right_col):
        """Create caregiver-specific dashboard content."""
        # Patient overview
        patient_card = Card(left_col, title="Patient Overview")
        patient_card.pack(fill='x', pady=(0, SPACING['md']))
        
        # Patient details
        details = ctk.CTkFrame(patient_card.content, fg_color='transparent')
        details.pack(fill='x')
        
        avatar = ctk.CTkLabel(details, text="👴", font=('Segoe UI Emoji', 64))
        avatar.pack(side='left', padx=SPACING['md'])
        
        info = ctk.CTkFrame(details, fg_color='transparent')
        info.pack(side='left', fill='x', expand=True)
        
        ctk.CTkLabel(
            info, text="Robert Davis", font=FONTS['heading_md'],
            text_color=COLORS['text_primary'], anchor='w'
        ).pack(fill='x')
        
        ctk.CTkLabel(
            info, text="Age: 72 • Right Hemiparesis", font=FONTS['body_md'],
            text_color=COLORS['text_secondary'], anchor='w'
        ).pack(fill='x')
        
        ctk.CTkLabel(
            info, text="Dr. Sarah Chen • PT: Michael Lee", font=FONTS['body_sm'],
            text_color=COLORS['text_muted'], anchor='w'
        ).pack(fill='x')
        
        # Today's exercises
        exercises_card = Card(left_col, title="Today's Exercises")
        exercises_card.pack(fill='both', expand=True)
        
        exercises = [
            ("Elbow Flexion/Extension", "10 reps × 3 sets", True, 1.0),
            ("Shoulder Rotation", "8 reps × 3 sets", True, 1.0),
            ("Bimanual Exercise", "8 reps × 2 sets", False, 0.4),
            ("Cool Down Stretches", "5 minutes", False, 0.0),
        ]
        
        for name, details, completed, progress in exercises:
            ex_frame = ctk.CTkFrame(
                exercises_card.content,
                fg_color=COLORS['surface_dark'] if completed else 'transparent',
                corner_radius=RADIUS['md']
            )
            ex_frame.pack(fill='x', pady=SPACING['xs'])
            
            check = ctk.CTkLabel(
                ex_frame,
                text="✅" if completed else "⭕",
                font=('Segoe UI Emoji', 20)
            )
            check.pack(side='left', padx=SPACING['sm'])
            
            ex_info = ctk.CTkFrame(ex_frame, fg_color='transparent')
            ex_info.pack(side='left', fill='x', expand=True, pady=SPACING['sm'])
            
            ctk.CTkLabel(
                ex_info, text=name, font=FONTS['body_md'],
                text_color=COLORS['text_primary'], anchor='w'
            ).pack(fill='x')
            
            ctk.CTkLabel(
                ex_info, text=details, font=FONTS['body_sm'],
                text_color=COLORS['text_secondary'], anchor='w'
            ).pack(fill='x')
            
            if not completed and progress > 0:
                prog_bar = ctk.CTkProgressBar(
                    ex_frame,
                    progress_color=COLORS['primary'],
                    width=80
                )
                prog_bar.pack(side='right', padx=SPACING['md'])
                prog_bar.set(progress)
        
        # Right sidebar
        progress_card = Card(right_col, title="Weekly Progress")
        progress_card.pack(fill='x', pady=(0, SPACING['md']))
        
        ProgressCard(
            progress_card.content, "Recovery Progress", 0.72, COLORS['secondary']
        ).pack(fill='x', pady=SPACING['xs'])
        
        ProgressCard(
            progress_card.content, "Session Completion", 0.85, COLORS['primary']
        ).pack(fill='x', pady=SPACING['xs'])
        
        # Emergency contact
        emergency_card = Card(right_col, title="Emergency Contact")
        emergency_card.pack(fill='x')
        
        ctk.CTkLabel(
            emergency_card.content,
            text="🏥 Dr. Sarah Chen",
            font=FONTS['body_md'],
            text_color=COLORS['text_primary']
        ).pack(anchor='w')
        
        ctk.CTkLabel(
            emergency_card.content,
            text="📞 +94 77 123 4567",
            font=FONTS['body_md'],
            text_color=COLORS['primary']
        ).pack(anchor='w', pady=SPACING['xs'])
        
        PrimaryButton(
            emergency_card.content,
            text="🚨 Emergency Call"
        ).pack(fill='x', pady=SPACING['sm'])
    
    def _create_patient_content(self, left_col, right_col):
        """Create patient-specific dashboard content."""
        # Motivational header
        motivation_card = ctk.CTkFrame(
            left_col,
            fg_color=COLORS['primary'],
            corner_radius=RADIUS['lg']
        )
        motivation_card.pack(fill='x', pady=(0, SPACING['md']))
        
        inner = ctk.CTkFrame(motivation_card, fg_color='transparent')
        inner.pack(fill='x', padx=SPACING['lg'], pady=SPACING['lg'])
        
        ctk.CTkLabel(
            inner,
            text="🎯 Keep Going! You're doing great!",
            font=FONTS['heading_md'],
            text_color='white'
        ).pack(anchor='w')
        
        ctk.CTkLabel(
            inner,
            text="You've completed 12 sessions this month. That's 20% more than last month!",
            font=FONTS['body_md'],
            text_color='white'
        ).pack(anchor='w', pady=(SPACING['xs'], 0))
        
        # Today's session
        session_card = Card(left_col, title="Today's Session")
        session_card.pack(fill='x', pady=(0, SPACING['md']))
        
        ProgressCard(
            session_card.content, "Session Progress", 0.4, COLORS['primary']
        ).pack(fill='x', pady=SPACING['xs'])
        
        PrimaryButton(
            session_card.content,
            text="▶️ Continue My Exercises",
            height=50
        ).pack(fill='x', pady=SPACING['sm'])
        
        # Exercise list
        exercises_card = Card(left_col, title="My Exercises")
        exercises_card.pack(fill='both', expand=True)
        
        exercises = [
            ("💪 Elbow Exercise", "Flexion/Extension", "✅ Done"),
            ("🔄 Shoulder Rotation", "Internal/External", "▶️ In Progress"),
            ("🤲 Bimanual Training", "Mirror Movement", "⏳ Next"),
        ]
        
        for name, desc, status in exercises:
            ex_frame = ctk.CTkFrame(exercises_card.content, fg_color='transparent')
            ex_frame.pack(fill='x', pady=SPACING['sm'])
            
            info = ctk.CTkFrame(ex_frame, fg_color='transparent')
            info.pack(side='left', fill='x', expand=True)
            
            ctk.CTkLabel(
                info, text=name, font=FONTS['body_md'],
                text_color=COLORS['text_primary'], anchor='w'
            ).pack(fill='x')
            
            ctk.CTkLabel(
                info, text=desc, font=FONTS['body_sm'],
                text_color=COLORS['text_secondary'], anchor='w'
            ).pack(fill='x')
            
            ctk.CTkLabel(
                ex_frame, text=status, font=FONTS['body_md'],
                text_color=COLORS['text_primary']
            ).pack(side='right')
        
        # Right sidebar - Progress
        progress_card = Card(right_col, title="My Recovery")
        progress_card.pack(fill='x', pady=(0, SPACING['md']))
        
        GaugeWidget(
            progress_card.content, "Overall Progress", 0.78, COLORS['secondary']
        ).pack(pady=SPACING['sm'])
        
        # Achievements
        achievements_card = Card(right_col, title="Recent Achievements")
        achievements_card.pack(fill='x')
        
        achievements = [
            ("🏆", "10 Day Streak!"),
            ("⭐", "Perfect Session"),
            ("📈", "50% ROM Improvement"),
        ]
        
        for icon, text in achievements:
            ach = ctk.CTkFrame(achievements_card.content, fg_color='transparent')
            ach.pack(fill='x', pady=SPACING['xs'])
            
            ctk.CTkLabel(ach, text=icon, font=('Segoe UI Emoji', 24)).pack(side='left')
            ctk.CTkLabel(
                ach, text=text, font=FONTS['body_md'],
                text_color=COLORS['text_primary']
            ).pack(side='left', padx=SPACING['sm'])
