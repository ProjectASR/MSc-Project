"""
UI Configuration and Theme Settings for Bimanual Rehabilitation Robot.
"""

# Color Palette - Modern Medical/Healthcare Theme
COLORS = {
    # Primary colors
    'primary': '#2563EB',           # Blue
    'primary_hover': '#1D4ED8',
    'primary_light': '#DBEAFE',
    
    # Secondary colors
    'secondary': '#059669',         # Green (success/health)
    'secondary_hover': '#047857',
    'secondary_light': '#D1FAE5',
    
    # Accent colors
    'accent': '#7C3AED',            # Purple
    'accent_hover': '#6D28D9',
    
    # Status colors
    'success': '#10B981',
    'warning': '#F59E0B',
    'error': '#EF4444',
    'info': '#3B82F6',
    
    # Neutral colors
    'background': '#F8FAFC',
    'surface': '#FFFFFF',
    'surface_dark': '#F1F5F9',
    'border': '#E2E8F0',
    'text_primary': '#1E293B',
    'text_secondary': '#64748B',
    'text_muted': '#94A3B8',
    
    # Dark mode (optional)
    'dark_bg': '#0F172A',
    'dark_surface': '#1E293B',
    'dark_text': '#F8FAFC',
}

# Font Configuration
FONTS = {
    'family': 'Segoe UI',
    'heading_xl': ('Segoe UI', 28, 'bold'),
    'heading_lg': ('Segoe UI', 24, 'bold'),
    'heading_md': ('Segoe UI', 20, 'bold'),
    'heading_sm': ('Segoe UI', 16, 'bold'),
    'body_lg': ('Segoe UI', 14),
    'body_md': ('Segoe UI', 12),
    'body_sm': ('Segoe UI', 10),
    'button': ('Segoe UI', 12, 'bold'),
    'label': ('Segoe UI', 11),
    'mono': ('Consolas', 11),
}

# Spacing
SPACING = {
    'xs': 4,
    'sm': 8,
    'md': 16,
    'lg': 24,
    'xl': 32,
    'xxl': 48,
}

# Border radius
RADIUS = {
    'sm': 4,
    'md': 8,
    'lg': 12,
    'xl': 16,
    'full': 9999,
}

# Window sizes
WINDOW = {
    'width': 1400,
    'height': 900,
    'min_width': 1200,
    'min_height': 700,
}

# User role icons (emoji fallback)
ROLE_ICONS = {
    'doctor': '👨‍⚕️',
    'physiotherapist': '🏃',
    'caregiver': '🤝',
    'patient': '🧑',
    'admin': '⚙️',
}

# Navigation items per role
NAV_ITEMS = {
    'doctor': [
        ('dashboard', 'Dashboard', '📊'),
        ('patients', 'Patients', '👥'),
        ('protocols', 'Protocols', '📋'),
        ('reports', 'Reports', '📈'),
        ('settings', 'Settings', '⚙️'),
    ],
    'physiotherapist': [
        ('dashboard', 'Dashboard', '📊'),
        ('patients', 'My Patients', '👥'),
        ('session', 'Session Control', '🎮'),
        ('protocols', 'Exercises', '📋'),
        ('settings', 'Settings', '⚙️'),
    ],
    'caregiver': [
        ('dashboard', 'Dashboard', '📊'),
        ('patient', 'Patient Info', '👤'),
        ('progress', 'Progress', '📈'),
        ('schedule', 'Schedule', '📅'),
    ],
    'patient': [
        ('dashboard', 'My Dashboard', '📊'),
        ('exercises', 'My Exercises', '🏋️'),
        ('progress', 'My Progress', '📈'),
        ('profile', 'Profile', '👤'),
    ],
}
