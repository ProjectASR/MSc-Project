"""
Custom UI Widgets for Bimanual Rehabilitation Robot.
Reusable components with consistent styling.
"""

import customtkinter as ctk
from typing import Callable, Optional, List, Tuple, Any
import tkinter as tk
from .config import COLORS, FONTS, SPACING, RADIUS


class Card(ctk.CTkFrame):
    """A styled card container with optional title."""
    
    def __init__(
        self,
        parent,
        title: str = None,
        padding: int = SPACING['md'],
        **kwargs
    ):
        super().__init__(
            parent,
            fg_color=COLORS['surface'],
            corner_radius=RADIUS['lg'],
            border_width=1,
            border_color=COLORS['border'],
            **kwargs
        )
        
        self.padding = padding
        
        if title:
            self.title_label = ctk.CTkLabel(
                self,
                text=title,
                font=FONTS['heading_sm'],
                text_color=COLORS['text_primary'],
                anchor='w'
            )
            self.title_label.pack(
                fill='x',
                padx=padding,
                pady=(padding, SPACING['sm'])
            )
            
            # Separator line
            separator = ctk.CTkFrame(
                self,
                height=1,
                fg_color=COLORS['border']
            )
            separator.pack(fill='x', padx=padding)
        
        # Content frame
        self.content = ctk.CTkFrame(self, fg_color='transparent')
        self.content.pack(fill='both', expand=True, padx=padding, pady=padding)


class StatCard(ctk.CTkFrame):
    """A card displaying a statistic with icon, value, and label."""
    
    def __init__(
        self,
        parent,
        icon: str,
        value: str,
        label: str,
        color: str = COLORS['primary'],
        **kwargs
    ):
        super().__init__(
            parent,
            fg_color=COLORS['surface'],
            corner_radius=RADIUS['lg'],
            border_width=1,
            border_color=COLORS['border'],
            **kwargs
        )
        
        # Icon
        icon_label = ctk.CTkLabel(
            self,
            text=icon,
            font=('Segoe UI Emoji', 32),
            text_color=color
        )
        icon_label.pack(pady=(SPACING['md'], SPACING['xs']))
        
        # Value
        self.value_label = ctk.CTkLabel(
            self,
            text=value,
            font=FONTS['heading_lg'],
            text_color=COLORS['text_primary']
        )
        self.value_label.pack()
        
        # Label
        label_widget = ctk.CTkLabel(
            self,
            text=label,
            font=FONTS['body_md'],
            text_color=COLORS['text_secondary']
        )
        label_widget.pack(pady=(0, SPACING['md']))
    
    def update_value(self, new_value: str):
        """Update the displayed value."""
        self.value_label.configure(text=new_value)


class PrimaryButton(ctk.CTkButton):
    """Primary action button with consistent styling."""
    
    def __init__(self, parent, text: str, command: Callable = None, **kwargs):
        super().__init__(
            parent,
            text=text,
            command=command,
            font=FONTS['button'],
            fg_color=COLORS['primary'],
            hover_color=COLORS['primary_hover'],
            corner_radius=RADIUS['md'],
            height=40,
            **kwargs
        )


class SecondaryButton(ctk.CTkButton):
    """Secondary action button."""
    
    def __init__(self, parent, text: str, command: Callable = None, **kwargs):
        super().__init__(
            parent,
            text=text,
            command=command,
            font=FONTS['button'],
            fg_color=COLORS['secondary'],
            hover_color=COLORS['secondary_hover'],
            corner_radius=RADIUS['md'],
            height=40,
            **kwargs
        )


class OutlineButton(ctk.CTkButton):
    """Outlined button for less prominent actions."""
    
    def __init__(self, parent, text: str, command: Callable = None, **kwargs):
        super().__init__(
            parent,
            text=text,
            command=command,
            font=FONTS['button'],
            fg_color='transparent',
            hover_color=COLORS['primary_light'],
            border_width=2,
            border_color=COLORS['primary'],
            text_color=COLORS['primary'],
            corner_radius=RADIUS['md'],
            height=40,
            **kwargs
        )


class IconButton(ctk.CTkButton):
    """Small icon-only button."""
    
    def __init__(self, parent, icon: str, command: Callable = None, **kwargs):
        super().__init__(
            parent,
            text=icon,
            command=command,
            font=('Segoe UI Emoji', 16),
            fg_color='transparent',
            hover_color=COLORS['surface_dark'],
            width=36,
            height=36,
            corner_radius=RADIUS['md'],
            **kwargs
        )


class StyledEntry(ctk.CTkEntry):
    """Styled text entry with label."""
    
    def __init__(
        self,
        parent,
        label: str = None,
        placeholder: str = "",
        **kwargs
    ):
        # Container
        self.container = ctk.CTkFrame(parent, fg_color='transparent')
        
        if label:
            self.label = ctk.CTkLabel(
                self.container,
                text=label,
                font=FONTS['label'],
                text_color=COLORS['text_secondary'],
                anchor='w'
            )
            self.label.pack(fill='x', pady=(0, SPACING['xs']))
        
        super().__init__(
            self.container,
            placeholder_text=placeholder,
            font=FONTS['body_md'],
            fg_color=COLORS['surface'],
            border_color=COLORS['border'],
            border_width=1,
            corner_radius=RADIUS['md'],
            height=40,
            **kwargs
        )
        self.pack(fill='x')
    
    def pack(self, **kwargs):
        if hasattr(self, 'container'):
            self.container.pack(**kwargs)
        else:
            super().pack(**kwargs)
    
    def grid(self, **kwargs):
        if hasattr(self, 'container'):
            self.container.grid(**kwargs)
        else:
            super().grid(**kwargs)


class StyledComboBox(ctk.CTkComboBox):
    """Styled dropdown with label."""
    
    def __init__(
        self,
        parent,
        label: str = None,
        values: List[str] = None,
        **kwargs
    ):
        self.container = ctk.CTkFrame(parent, fg_color='transparent')
        
        if label:
            self.label_widget = ctk.CTkLabel(
                self.container,
                text=label,
                font=FONTS['label'],
                text_color=COLORS['text_secondary'],
                anchor='w'
            )
            self.label_widget.pack(fill='x', pady=(0, SPACING['xs']))
        
        super().__init__(
            self.container,
            values=values or [],
            font=FONTS['body_md'],
            fg_color=COLORS['surface'],
            border_color=COLORS['border'],
            button_color=COLORS['primary'],
            button_hover_color=COLORS['primary_hover'],
            dropdown_fg_color=COLORS['surface'],
            dropdown_hover_color=COLORS['primary_light'],
            corner_radius=RADIUS['md'],
            height=40,
            **kwargs
        )
        self.pack(fill='x')
    
    def pack(self, **kwargs):
        if hasattr(self, 'container'):
            self.container.pack(**kwargs)
        else:
            super().pack(**kwargs)


class ProgressCard(ctk.CTkFrame):
    """Card with progress bar and percentage."""
    
    def __init__(
        self,
        parent,
        title: str,
        value: float = 0.0,  # 0.0 to 1.0
        color: str = COLORS['primary'],
        **kwargs
    ):
        super().__init__(
            parent,
            fg_color=COLORS['surface'],
            corner_radius=RADIUS['lg'],
            border_width=1,
            border_color=COLORS['border'],
            **kwargs
        )
        
        # Header
        header = ctk.CTkFrame(self, fg_color='transparent')
        header.pack(fill='x', padx=SPACING['md'], pady=(SPACING['md'], SPACING['sm']))
        
        title_label = ctk.CTkLabel(
            header,
            text=title,
            font=FONTS['body_md'],
            text_color=COLORS['text_secondary']
        )
        title_label.pack(side='left')
        
        self.percent_label = ctk.CTkLabel(
            header,
            text=f"{int(value * 100)}%",
            font=FONTS['heading_sm'],
            text_color=COLORS['text_primary']
        )
        self.percent_label.pack(side='right')
        
        # Progress bar
        self.progress = ctk.CTkProgressBar(
            self,
            progress_color=color,
            fg_color=COLORS['surface_dark'],
            corner_radius=RADIUS['sm'],
            height=8
        )
        self.progress.pack(
            fill='x',
            padx=SPACING['md'],
            pady=(0, SPACING['md'])
        )
        self.progress.set(value)
    
    def update_progress(self, value: float):
        """Update progress value (0.0 to 1.0)."""
        self.progress.set(value)
        self.percent_label.configure(text=f"{int(value * 100)}%")


class DataTable(ctk.CTkScrollableFrame):
    """A styled data table with headers and rows."""
    
    def __init__(
        self,
        parent,
        columns: List[Tuple[str, int]],  # [(name, width), ...]
        **kwargs
    ):
        super().__init__(
            parent,
            fg_color=COLORS['surface'],
            corner_radius=RADIUS['lg'],
            **kwargs
        )
        
        self.columns = columns
        self.rows = []
        
        # Header row
        self.header_frame = ctk.CTkFrame(self, fg_color=COLORS['surface_dark'])
        self.header_frame.pack(fill='x', pady=(0, 1))
        
        for i, (name, width) in enumerate(columns):
            label = ctk.CTkLabel(
                self.header_frame,
                text=name,
                font=FONTS['label'],
                text_color=COLORS['text_secondary'],
                width=width,
                anchor='w'
            )
            label.grid(row=0, column=i, padx=SPACING['sm'], pady=SPACING['sm'], sticky='w')
    
    def add_row(self, values: List[str], on_click: Callable = None):
        """Add a row to the table."""
        row_frame = ctk.CTkFrame(self, fg_color='transparent')
        row_frame.pack(fill='x')
        
        for i, (value, (_, width)) in enumerate(zip(values, self.columns)):
            label = ctk.CTkLabel(
                row_frame,
                text=value,
                font=FONTS['body_md'],
                text_color=COLORS['text_primary'],
                width=width,
                anchor='w'
            )
            label.grid(row=0, column=i, padx=SPACING['sm'], pady=SPACING['sm'], sticky='w')
        
        if on_click:
            row_frame.bind('<Button-1>', lambda e: on_click())
            row_frame.configure(cursor='hand2')
        
        # Hover effect
        def on_enter(e):
            row_frame.configure(fg_color=COLORS['surface_dark'])
        
        def on_leave(e):
            row_frame.configure(fg_color='transparent')
        
        row_frame.bind('<Enter>', on_enter)
        row_frame.bind('<Leave>', on_leave)
        
        self.rows.append(row_frame)
        
        # Separator
        sep = ctk.CTkFrame(self, height=1, fg_color=COLORS['border'])
        sep.pack(fill='x')
    
    def clear_rows(self):
        """Remove all rows from table."""
        for row in self.rows:
            row.destroy()
        self.rows = []


class StatusBadge(ctk.CTkFrame):
    """A small status badge/pill."""
    
    STATUS_COLORS = {
        'active': (COLORS['success'], '#ECFDF5'),
        'inactive': (COLORS['text_muted'], COLORS['surface_dark']),
        'warning': (COLORS['warning'], '#FFFBEB'),
        'error': (COLORS['error'], '#FEF2F2'),
        'info': (COLORS['info'], '#EFF6FF'),
    }
    
    def __init__(self, parent, text: str, status: str = 'active', **kwargs):
        fg_color, bg_color = self.STATUS_COLORS.get(status, self.STATUS_COLORS['info'])
        
        super().__init__(
            parent,
            fg_color=bg_color,
            corner_radius=RADIUS['full'],
            **kwargs
        )
        
        label = ctk.CTkLabel(
            self,
            text=text,
            font=FONTS['body_sm'],
            text_color=fg_color
        )
        label.pack(padx=SPACING['sm'], pady=SPACING['xs'])


class NavigationItem(ctk.CTkFrame):
    """A navigation menu item."""
    
    def __init__(
        self,
        parent,
        icon: str,
        text: str,
        command: Callable = None,
        selected: bool = False,
        **kwargs
    ):
        self.selected = selected
        self.command = command
        
        bg_color = COLORS['primary_light'] if selected else 'transparent'
        text_color = COLORS['primary'] if selected else COLORS['text_secondary']
        
        super().__init__(
            parent,
            fg_color=bg_color,
            corner_radius=RADIUS['md'],
            cursor='hand2',
            **kwargs
        )
        
        self.icon_label = ctk.CTkLabel(
            self,
            text=icon,
            font=('Segoe UI Emoji', 18),
            text_color=text_color
        )
        self.icon_label.pack(side='left', padx=(SPACING['md'], SPACING['sm']))
        
        self.text_label = ctk.CTkLabel(
            self,
            text=text,
            font=FONTS['body_md'],
            text_color=text_color
        )
        self.text_label.pack(side='left', pady=SPACING['sm'])
        
        # Bind click
        self.bind('<Button-1>', self._on_click)
        self.icon_label.bind('<Button-1>', self._on_click)
        self.text_label.bind('<Button-1>', self._on_click)
        
        # Hover effect
        if not selected:
            self.bind('<Enter>', lambda e: self.configure(fg_color=COLORS['surface_dark']))
            self.bind('<Leave>', lambda e: self.configure(fg_color='transparent'))
    
    def _on_click(self, event):
        if self.command:
            self.command()
    
    def set_selected(self, selected: bool):
        """Update selection state."""
        self.selected = selected
        if selected:
            self.configure(fg_color=COLORS['primary_light'])
            self.icon_label.configure(text_color=COLORS['primary'])
            self.text_label.configure(text_color=COLORS['primary'])
        else:
            self.configure(fg_color='transparent')
            self.icon_label.configure(text_color=COLORS['text_secondary'])
            self.text_label.configure(text_color=COLORS['text_secondary'])


class GaugeWidget(ctk.CTkFrame):
    """A circular gauge for displaying metrics like fatigue level."""
    
    def __init__(
        self,
        parent,
        title: str,
        value: float = 0.0,  # 0.0 to 1.0
        size: int = 120,
        color: str = COLORS['primary'],
        **kwargs
    ):
        super().__init__(parent, fg_color='transparent', **kwargs)
        
        self.size = size
        self.color = color
        
        # Canvas for gauge
        self.canvas = tk.Canvas(
            self,
            width=size,
            height=size,
            bg=COLORS['surface'],
            highlightthickness=0
        )
        self.canvas.pack()
        
        # Title
        title_label = ctk.CTkLabel(
            self,
            text=title,
            font=FONTS['body_sm'],
            text_color=COLORS['text_secondary']
        )
        title_label.pack(pady=(SPACING['xs'], 0))
        
        self.draw_gauge(value)
    
    def draw_gauge(self, value: float):
        """Draw the gauge with given value."""
        self.canvas.delete('all')
        
        padding = 10
        # Background arc
        self.canvas.create_arc(
            padding, padding,
            self.size - padding, self.size - padding,
            start=225, extent=-270,
            style='arc',
            outline=COLORS['surface_dark'],
            width=8
        )
        
        # Value arc
        extent = -270 * value
        self.canvas.create_arc(
            padding, padding,
            self.size - padding, self.size - padding,
            start=225, extent=extent,
            style='arc',
            outline=self.color,
            width=8
        )
        
        # Center text
        percent = int(value * 100)
        self.canvas.create_text(
            self.size // 2, self.size // 2,
            text=f"{percent}%",
            font=FONTS['heading_sm'],
            fill=COLORS['text_primary']
        )
    
    def update_value(self, value: float):
        """Update gauge value."""
        self.draw_gauge(value)
