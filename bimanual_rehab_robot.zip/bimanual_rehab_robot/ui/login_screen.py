"""
Login Screen for Bimanual Rehabilitation Robot System.
"""

import customtkinter as ctk
from typing import Callable, Optional
from .config import COLORS, FONTS, SPACING, RADIUS, ROLE_ICONS


class LoginScreen(ctk.CTkFrame):
    """Professional login screen with role selection."""
    
    def __init__(self, parent, on_login: Callable[[str, str, str], None]):
        """
        Initialize login screen.
        
        Args:
            parent: Parent widget
            on_login: Callback function(username, password, role) when login attempted
        """
        super().__init__(parent, fg_color=COLORS['background'])
        
        self.on_login = on_login
        self.selected_role = 'physiotherapist'  # Default role
        
        self._create_ui()
    
    def _create_ui(self):
        """Create the login UI."""
        # Center container
        center_frame = ctk.CTkFrame(self, fg_color='transparent')
        center_frame.place(relx=0.5, rely=0.5, anchor='center')
        
        # Logo/Title section
        logo_frame = ctk.CTkFrame(center_frame, fg_color='transparent')
        logo_frame.pack(pady=(0, SPACING['xl']))
        
        # Robot icon
        icon_label = ctk.CTkLabel(
            logo_frame,
            text="🤖",
            font=('Segoe UI Emoji', 64)
        )
        icon_label.pack()
        
        # Title
        title_label = ctk.CTkLabel(
            logo_frame,
            text="Bimanual Rehab Robot",
            font=FONTS['heading_lg'],
            text_color=COLORS['text_primary']
        )
        title_label.pack(pady=(SPACING['sm'], 0))
        
        # Subtitle
        subtitle_label = ctk.CTkLabel(
            logo_frame,
            text="Adaptive Torque Modeling & Exercise Protocols",
            font=FONTS['body_md'],
            text_color=COLORS['text_secondary']
        )
        subtitle_label.pack()
        
        # Login card
        login_card = ctk.CTkFrame(
            center_frame,
            fg_color=COLORS['surface'],
            corner_radius=RADIUS['xl'],
            border_width=1,
            border_color=COLORS['border']
        )
        login_card.pack(fill='x', padx=SPACING['md'])
        
        inner_frame = ctk.CTkFrame(login_card, fg_color='transparent')
        inner_frame.pack(padx=SPACING['xl'], pady=SPACING['xl'])
        
        # Role selection
        role_label = ctk.CTkLabel(
            inner_frame,
            text="Select Your Role",
            font=FONTS['heading_sm'],
            text_color=COLORS['text_primary']
        )
        role_label.pack(anchor='w', pady=(0, SPACING['md']))
        
        # Role buttons grid
        roles_frame = ctk.CTkFrame(inner_frame, fg_color='transparent')
        roles_frame.pack(fill='x', pady=(0, SPACING['lg']))
        
        self.role_buttons = {}
        roles = [
            ('doctor', 'Doctor', '👨‍⚕️'),
            ('physiotherapist', 'Physiotherapist', '🏃'),
            ('caregiver', 'Caregiver', '🤝'),
            ('patient', 'Patient', '🧑'),
        ]
        
        for i, (role_id, role_name, role_icon) in enumerate(roles):
            btn = self._create_role_button(roles_frame, role_id, role_name, role_icon)
            btn.grid(row=i // 2, column=i % 2, padx=SPACING['xs'], pady=SPACING['xs'], sticky='ew')
            self.role_buttons[role_id] = btn
        
        roles_frame.grid_columnconfigure(0, weight=1)
        roles_frame.grid_columnconfigure(1, weight=1)
        
        # Select default role
        self._select_role('physiotherapist')
        
        # Separator
        sep_frame = ctk.CTkFrame(inner_frame, fg_color='transparent')
        sep_frame.pack(fill='x', pady=SPACING['md'])
        
        sep_left = ctk.CTkFrame(sep_frame, height=1, fg_color=COLORS['border'])
        sep_left.pack(side='left', fill='x', expand=True)
        
        sep_text = ctk.CTkLabel(
            sep_frame,
            text="Login Credentials",
            font=FONTS['body_sm'],
            text_color=COLORS['text_muted']
        )
        sep_text.pack(side='left', padx=SPACING['md'])
        
        sep_right = ctk.CTkFrame(sep_frame, height=1, fg_color=COLORS['border'])
        sep_right.pack(side='left', fill='x', expand=True)
        
        # Username field
        username_label = ctk.CTkLabel(
            inner_frame,
            text="Username",
            font=FONTS['label'],
            text_color=COLORS['text_secondary'],
            anchor='w'
        )
        username_label.pack(fill='x', pady=(SPACING['md'], SPACING['xs']))
        
        self.username_entry = ctk.CTkEntry(
            inner_frame,
            placeholder_text="Enter your username",
            font=FONTS['body_md'],
            fg_color=COLORS['surface'],
            border_color=COLORS['border'],
            corner_radius=RADIUS['md'],
            height=45,
            width=350
        )
        self.username_entry.pack(fill='x')
        
        # Password field
        password_label = ctk.CTkLabel(
            inner_frame,
            text="Password",
            font=FONTS['label'],
            text_color=COLORS['text_secondary'],
            anchor='w'
        )
        password_label.pack(fill='x', pady=(SPACING['md'], SPACING['xs']))
        
        self.password_entry = ctk.CTkEntry(
            inner_frame,
            placeholder_text="Enter your password",
            show="•",
            font=FONTS['body_md'],
            fg_color=COLORS['surface'],
            border_color=COLORS['border'],
            corner_radius=RADIUS['md'],
            height=45,
            width=350
        )
        self.password_entry.pack(fill='x')
        
        # Remember me checkbox
        remember_frame = ctk.CTkFrame(inner_frame, fg_color='transparent')
        remember_frame.pack(fill='x', pady=SPACING['md'])
        
        self.remember_var = ctk.BooleanVar(value=False)
        remember_check = ctk.CTkCheckBox(
            remember_frame,
            text="Remember me",
            variable=self.remember_var,
            font=FONTS['body_sm'],
            text_color=COLORS['text_secondary'],
            fg_color=COLORS['primary'],
            hover_color=COLORS['primary_hover']
        )
        remember_check.pack(side='left')
        
        forgot_btn = ctk.CTkButton(
            remember_frame,
            text="Forgot password?",
            font=FONTS['body_sm'],
            fg_color='transparent',
            text_color=COLORS['primary'],
            cursor='hand2',
            width=100
        )
        forgot_btn.pack(side='right')
        
        # Error message label (hidden by default)
        self.error_label = ctk.CTkLabel(
            inner_frame,
            text="",
            font=FONTS['body_sm'],
            text_color=COLORS['error']
        )
        self.error_label.pack(pady=(0, SPACING['sm']))
        
        # Login button
        login_btn = ctk.CTkButton(
            inner_frame,
            text="Sign In",
            font=FONTS['button'],
            fg_color=COLORS['primary'],
            hover_color=COLORS['primary_hover'],
            corner_radius=RADIUS['md'],
            height=50,
            command=self._attempt_login
        )
        login_btn.pack(fill='x', pady=(SPACING['sm'], 0))
        
        # Bind Enter key
        self.username_entry.bind('<Return>', lambda e: self.password_entry.focus())
        self.password_entry.bind('<Return>', lambda e: self._attempt_login())
        
        # Footer
        footer_label = ctk.CTkLabel(
            center_frame,
            text="University of Moratuwa • Robotics & Automation Laboratory",
            font=FONTS['body_sm'],
            text_color=COLORS['text_muted']
        )
        footer_label.pack(pady=SPACING['lg'])
    
    def _create_role_button(self, parent, role_id: str, role_name: str, icon: str) -> ctk.CTkFrame:
        """Create a role selection button."""
        frame = ctk.CTkFrame(
            parent,
            fg_color=COLORS['surface_dark'],
            corner_radius=RADIUS['md'],
            cursor='hand2'
        )
        
        icon_label = ctk.CTkLabel(
            frame,
            text=icon,
            font=('Segoe UI Emoji', 24)
        )
        icon_label.pack(pady=(SPACING['sm'], SPACING['xs']))
        
        name_label = ctk.CTkLabel(
            frame,
            text=role_name,
            font=FONTS['body_md'],
            text_color=COLORS['text_primary']
        )
        name_label.pack(pady=(0, SPACING['sm']))
        
        # Store role_id in frame
        frame.role_id = role_id
        
        # Bind clicks
        frame.bind('<Button-1>', lambda e, r=role_id: self._select_role(r))
        icon_label.bind('<Button-1>', lambda e, r=role_id: self._select_role(r))
        name_label.bind('<Button-1>', lambda e, r=role_id: self._select_role(r))
        
        return frame
    
    def _select_role(self, role_id: str):
        """Select a role."""
        self.selected_role = role_id
        
        # Update button styles
        for rid, btn in self.role_buttons.items():
            if rid == role_id:
                btn.configure(
                    fg_color=COLORS['primary_light'],
                    border_width=2,
                    border_color=COLORS['primary']
                )
            else:
                btn.configure(
                    fg_color=COLORS['surface_dark'],
                    border_width=0
                )
    
    def _attempt_login(self):
        """Attempt to login with current credentials."""
        username = self.username_entry.get().strip()
        password = self.password_entry.get()
        
        if not username:
            self.show_error("Please enter your username")
            return
        
        if not password:
            self.show_error("Please enter your password")
            return
        
        # Clear error and call login handler
        self.error_label.configure(text="")
        self.on_login(username, password, self.selected_role)
    
    def show_error(self, message: str):
        """Display an error message."""
        self.error_label.configure(text=message)
    
    def clear(self):
        """Clear all input fields."""
        self.username_entry.delete(0, 'end')
        self.password_entry.delete(0, 'end')
        self.error_label.configure(text="")
