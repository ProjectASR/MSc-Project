"""
Fatigue Detection Module for Bimanual Rehabilitation Robot.

Implements multi-modal fatigue detection based on:
- Torque decline
- Movement smoothness (jerk)
- Range of motion decline
- Velocity pattern changes

These indicators help prevent overexertion and optimize rehabilitation outcomes.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Any, Deque
from collections import deque
import numpy as np
from scipy import signal

from core.base import FatigueDetector, FatigueIndicators
from core.enums import FatigueLevel
from core.exceptions import FatigueThresholdExceededError


@dataclass
class FatigueThresholds:
    """
    Thresholds for fatigue level classification.
    
    Based on literature and clinical observations.
    """
    # Torque decline thresholds
    torque_mild: float = 0.85       # 15% decline
    torque_moderate: float = 0.70   # 30% decline
    torque_severe: float = 0.55     # 45% decline
    
    # Movement smoothness (normalized jerk)
    jerk_mild: float = 1.3          # 30% increase
    jerk_moderate: float = 1.6      # 60% increase
    jerk_severe: float = 2.0        # 100% increase
    
    # ROM decline thresholds
    rom_mild: float = 0.90          # 10% decline
    rom_moderate: float = 0.80      # 20% decline
    rom_severe: float = 0.70        # 30% decline
    
    # Velocity decline thresholds
    velocity_mild: float = 0.85
    velocity_moderate: float = 0.70
    velocity_severe: float = 0.55


@dataclass
class BaselineMetrics:
    """
    Baseline measurements from initial exercise phase.
    """
    mean_torque: float
    max_torque: float
    mean_velocity: float
    max_velocity: float
    range_of_motion: float
    baseline_jerk: float
    
    # Number of samples used
    sample_count: int
    
    @classmethod
    def from_data(
        cls,
        torques: np.ndarray,
        velocities: np.ndarray,
        positions: np.ndarray,
        dt: float,
    ) -> 'BaselineMetrics':
        """Calculate baseline metrics from initial data."""
        # Calculate jerk (3rd derivative of position)
        accelerations = np.gradient(velocities, dt)
        jerks = np.gradient(accelerations, dt)
        mean_jerk = np.sqrt(np.mean(jerks**2))  # RMS jerk
        
        return cls(
            mean_torque=np.mean(np.abs(torques)),
            max_torque=np.max(np.abs(torques)),
            mean_velocity=np.mean(np.abs(velocities)),
            max_velocity=np.max(np.abs(velocities)),
            range_of_motion=np.max(positions) - np.min(positions),
            baseline_jerk=mean_jerk,
            sample_count=len(torques),
        )


class TorqueBasedFatigueDetector(FatigueDetector):
    """
    Fatigue detection based on torque production decline.
    
    As muscles fatigue, maximum voluntary torque decreases.
    This is a primary indicator of peripheral muscle fatigue.
    """
    
    def __init__(
        self,
        window_size: int = 100,
        thresholds: Optional[FatigueThresholds] = None,
    ):
        """
        Initialize detector.
        
        Args:
            window_size: Number of samples in sliding window
            thresholds: Custom thresholds (uses defaults if None)
        """
        self.window_size = window_size
        self.thresholds = thresholds or FatigueThresholds()
        
        self._baseline: Optional[BaselineMetrics] = None
        self._torque_buffer: Deque[float] = deque(maxlen=window_size)
        self._current_level = FatigueLevel.NONE
        self._initialized = False
    
    def initialize(self, baseline_data: Dict[str, Any]) -> None:
        """
        Initialize with baseline measurements.
        
        Args:
            baseline_data: Dict with 'torques', 'velocities', 'positions', 'dt'
        """
        self._baseline = BaselineMetrics.from_data(
            torques=np.array(baseline_data['torques']),
            velocities=np.array(baseline_data['velocities']),
            positions=np.array(baseline_data['positions']),
            dt=baseline_data['dt'],
        )
        self._torque_buffer.clear()
        self._current_level = FatigueLevel.NONE
        self._initialized = True
    
    def update(self, current_data: Dict[str, Any]) -> FatigueIndicators:
        """
        Update fatigue assessment with new data.
        
        Args:
            current_data: Dict with 'torque' value
            
        Returns:
            Current fatigue indicators
        """
        if not self._initialized:
            raise RuntimeError("Detector not initialized")
        
        torque = current_data.get('torque', 0)
        self._torque_buffer.append(abs(torque))
        
        # Calculate current mean torque
        current_mean = np.mean(list(self._torque_buffer))
        
        # Torque decline ratio
        torque_ratio = current_mean / self._baseline.mean_torque if self._baseline.mean_torque > 0 else 1.0
        
        # Update fatigue level
        self._update_fatigue_level(torque_ratio)
        
        return FatigueIndicators(
            torque_decline_ratio=torque_ratio,
            movement_smoothness=1.0,  # Not tracked by this detector
            rom_decline_ratio=1.0,
            velocity_decline_ratio=1.0,
        )
    
    def _update_fatigue_level(self, torque_ratio: float) -> None:
        """Update fatigue level based on torque ratio."""
        t = self.thresholds
        
        if torque_ratio < t.torque_severe:
            self._current_level = FatigueLevel.CRITICAL
        elif torque_ratio < t.torque_moderate:
            self._current_level = FatigueLevel.SEVERE
        elif torque_ratio < t.torque_mild:
            self._current_level = FatigueLevel.MODERATE
        elif torque_ratio < 1.0:
            self._current_level = FatigueLevel.MILD
        else:
            self._current_level = FatigueLevel.NONE
    
    def get_fatigue_level(self) -> FatigueLevel:
        return self._current_level
    
    def should_pause(self) -> bool:
        return self._current_level in [FatigueLevel.SEVERE, FatigueLevel.CRITICAL]
    
    def reset(self) -> None:
        self._baseline = None
        self._torque_buffer.clear()
        self._current_level = FatigueLevel.NONE
        self._initialized = False


class MovementSmoothnessDetector(FatigueDetector):
    """
    Fatigue detection based on movement smoothness (jerk metric).
    
    Fatigued movements tend to be less smooth with more jerky corrections.
    Uses normalized squared jerk as the smoothness metric.
    """
    
    def __init__(
        self,
        window_size: int = 100,
        sample_rate: float = 100.0,
        thresholds: Optional[FatigueThresholds] = None,
    ):
        self.window_size = window_size
        self.sample_rate = sample_rate
        self.dt = 1.0 / sample_rate
        self.thresholds = thresholds or FatigueThresholds()
        
        self._baseline: Optional[BaselineMetrics] = None
        self._position_buffer: Deque[float] = deque(maxlen=window_size)
        self._current_level = FatigueLevel.NONE
        self._initialized = False
    
    def initialize(self, baseline_data: Dict[str, Any]) -> None:
        self._baseline = BaselineMetrics.from_data(
            torques=np.array(baseline_data['torques']),
            velocities=np.array(baseline_data['velocities']),
            positions=np.array(baseline_data['positions']),
            dt=baseline_data['dt'],
        )
        self._position_buffer.clear()
        self._current_level = FatigueLevel.NONE
        self._initialized = True
    
    def update(self, current_data: Dict[str, Any]) -> FatigueIndicators:
        if not self._initialized:
            raise RuntimeError("Detector not initialized")
        
        position = current_data.get('position', 0)
        self._position_buffer.append(position)
        
        # Need enough samples to calculate jerk
        if len(self._position_buffer) < 4:
            return FatigueIndicators(
                torque_decline_ratio=1.0,
                movement_smoothness=1.0,
                rom_decline_ratio=1.0,
                velocity_decline_ratio=1.0,
            )
        
        # Calculate current jerk
        positions = np.array(list(self._position_buffer))
        velocities = np.gradient(positions, self.dt)
        accelerations = np.gradient(velocities, self.dt)
        jerks = np.gradient(accelerations, self.dt)
        current_jerk = np.sqrt(np.mean(jerks**2))
        
        # Jerk ratio (higher = less smooth = more fatigued)
        jerk_ratio = current_jerk / self._baseline.baseline_jerk if self._baseline.baseline_jerk > 0 else 1.0
        
        self._update_fatigue_level(jerk_ratio)
        
        return FatigueIndicators(
            torque_decline_ratio=1.0,
            movement_smoothness=1.0 / jerk_ratio,  # Invert so lower = worse
            rom_decline_ratio=1.0,
            velocity_decline_ratio=1.0,
        )
    
    def _update_fatigue_level(self, jerk_ratio: float) -> None:
        t = self.thresholds
        
        if jerk_ratio > t.jerk_severe:
            self._current_level = FatigueLevel.CRITICAL
        elif jerk_ratio > t.jerk_moderate:
            self._current_level = FatigueLevel.SEVERE
        elif jerk_ratio > t.jerk_mild:
            self._current_level = FatigueLevel.MODERATE
        elif jerk_ratio > 1.0:
            self._current_level = FatigueLevel.MILD
        else:
            self._current_level = FatigueLevel.NONE
    
    def get_fatigue_level(self) -> FatigueLevel:
        return self._current_level
    
    def should_pause(self) -> bool:
        return self._current_level in [FatigueLevel.SEVERE, FatigueLevel.CRITICAL]
    
    def reset(self) -> None:
        self._baseline = None
        self._position_buffer.clear()
        self._current_level = FatigueLevel.NONE
        self._initialized = False


class CompositeFatigueDetector(FatigueDetector):
    """
    Multi-modal fatigue detection combining multiple indicators.
    
    Combines:
    - Torque decline
    - Movement smoothness
    - ROM decline
    - Velocity decline
    
    Uses weighted voting to determine overall fatigue level.
    """
    
    def __init__(
        self,
        window_size: int = 100,
        sample_rate: float = 100.0,
        thresholds: Optional[FatigueThresholds] = None,
        weights: Optional[Dict[str, float]] = None,
    ):
        """
        Initialize composite detector.
        
        Args:
            window_size: Sliding window size
            sample_rate: Data sampling rate (Hz)
            thresholds: Fatigue thresholds
            weights: Weights for each indicator (default: equal)
        """
        self.window_size = window_size
        self.sample_rate = sample_rate
        self.dt = 1.0 / sample_rate
        self.thresholds = thresholds or FatigueThresholds()
        
        # Default equal weights
        self.weights = weights or {
            'torque': 0.35,
            'smoothness': 0.25,
            'rom': 0.20,
            'velocity': 0.20,
        }
        
        self._baseline: Optional[BaselineMetrics] = None
        
        # Buffers for different measurements
        self._torque_buffer: Deque[float] = deque(maxlen=window_size)
        self._position_buffer: Deque[float] = deque(maxlen=window_size)
        self._velocity_buffer: Deque[float] = deque(maxlen=window_size)
        
        # Per-repetition tracking for ROM
        self._rep_positions: List[float] = []
        self._rep_roms: List[float] = []
        
        self._current_level = FatigueLevel.NONE
        self._current_indicators = FatigueIndicators(1.0, 1.0, 1.0, 1.0)
        self._initialized = False
    
    def initialize(self, baseline_data: Dict[str, Any]) -> None:
        """Initialize with baseline data from first few repetitions."""
        self._baseline = BaselineMetrics.from_data(
            torques=np.array(baseline_data['torques']),
            velocities=np.array(baseline_data['velocities']),
            positions=np.array(baseline_data['positions']),
            dt=baseline_data.get('dt', self.dt),
        )
        
        # Clear buffers
        self._torque_buffer.clear()
        self._position_buffer.clear()
        self._velocity_buffer.clear()
        self._rep_positions = []
        self._rep_roms = [self._baseline.range_of_motion]
        
        self._current_level = FatigueLevel.NONE
        self._initialized = True
    
    def update(self, current_data: Dict[str, Any]) -> FatigueIndicators:
        """
        Update with new measurement data.
        
        Args:
            current_data: Dict with 'torque', 'position', 'velocity', 'new_rep' (bool)
        """
        if not self._initialized:
            raise RuntimeError("Detector not initialized")
        
        # Update buffers
        self._torque_buffer.append(abs(current_data.get('torque', 0)))
        self._position_buffer.append(current_data.get('position', 0))
        self._velocity_buffer.append(abs(current_data.get('velocity', 0)))
        
        # Track ROM per repetition
        self._rep_positions.append(current_data.get('position', 0))
        
        if current_data.get('new_rep', False) and len(self._rep_positions) > 1:
            rep_rom = max(self._rep_positions) - min(self._rep_positions)
            self._rep_roms.append(rep_rom)
            self._rep_positions = []
        
        # Calculate indicators
        indicators = self._calculate_indicators()
        self._current_indicators = indicators
        
        # Update fatigue level
        self._update_fatigue_level(indicators)
        
        return indicators
    
    def _calculate_indicators(self) -> FatigueIndicators:
        """Calculate all fatigue indicators."""
        # Torque decline
        current_torque = np.mean(list(self._torque_buffer)) if self._torque_buffer else 0
        torque_ratio = current_torque / self._baseline.mean_torque if self._baseline.mean_torque > 0 else 1.0
        
        # Movement smoothness (jerk-based)
        smoothness = 1.0
        if len(self._position_buffer) >= 4:
            positions = np.array(list(self._position_buffer))
            velocities = np.gradient(positions, self.dt)
            accelerations = np.gradient(velocities, self.dt)
            jerks = np.gradient(accelerations, self.dt)
            current_jerk = np.sqrt(np.mean(jerks**2))
            jerk_ratio = current_jerk / self._baseline.baseline_jerk if self._baseline.baseline_jerk > 0 else 1.0
            smoothness = 1.0 / max(jerk_ratio, 0.1)  # Invert and limit
        
        # ROM decline
        rom_ratio = 1.0
        if len(self._rep_roms) > 1:
            recent_rom = np.mean(self._rep_roms[-3:])  # Last 3 reps
            rom_ratio = recent_rom / self._baseline.range_of_motion if self._baseline.range_of_motion > 0 else 1.0
        
        # Velocity decline
        current_velocity = np.mean(list(self._velocity_buffer)) if self._velocity_buffer else 0
        velocity_ratio = current_velocity / self._baseline.mean_velocity if self._baseline.mean_velocity > 0 else 1.0
        
        return FatigueIndicators(
            torque_decline_ratio=min(torque_ratio, 1.0),
            movement_smoothness=min(smoothness, 1.0),
            rom_decline_ratio=min(rom_ratio, 1.0),
            velocity_decline_ratio=min(velocity_ratio, 1.0),
        )
    
    def _update_fatigue_level(self, indicators: FatigueIndicators) -> None:
        """Update fatigue level using weighted combination."""
        t = self.thresholds
        w = self.weights
        
        # Calculate fatigue score for each indicator (0-4 scale)
        def get_score(value: float, mild: float, mod: float, severe: float, inverted: bool = False) -> float:
            if inverted:
                # For smoothness where higher is better
                if value > mild:
                    return 0
                elif value > mod:
                    return 1
                elif value > severe:
                    return 2
                else:
                    return 3
            else:
                # For decline ratios where lower is worse
                if value > mild:
                    return 0
                elif value > mod:
                    return 1
                elif value > severe:
                    return 2
                else:
                    return 3
        
        # Calculate weighted score
        torque_score = get_score(indicators.torque_decline_ratio, t.torque_mild, t.torque_moderate, t.torque_severe)
        smoothness_score = get_score(1.0/indicators.movement_smoothness if indicators.movement_smoothness > 0 else 2.0, 
                                     t.jerk_mild, t.jerk_moderate, t.jerk_severe, inverted=True)
        rom_score = get_score(indicators.rom_decline_ratio, t.rom_mild, t.rom_moderate, t.rom_severe)
        velocity_score = get_score(indicators.velocity_decline_ratio, t.velocity_mild, t.velocity_moderate, t.velocity_severe)
        
        weighted_score = (
            w['torque'] * torque_score +
            w['smoothness'] * smoothness_score +
            w['rom'] * rom_score +
            w['velocity'] * velocity_score
        )
        
        # Map to fatigue level
        if weighted_score >= 2.5:
            self._current_level = FatigueLevel.CRITICAL
        elif weighted_score >= 2.0:
            self._current_level = FatigueLevel.SEVERE
        elif weighted_score >= 1.0:
            self._current_level = FatigueLevel.MODERATE
        elif weighted_score > 0:
            self._current_level = FatigueLevel.MILD
        else:
            self._current_level = FatigueLevel.NONE
    
    def get_fatigue_level(self) -> FatigueLevel:
        return self._current_level
    
    def should_pause(self) -> bool:
        return self._current_level in [FatigueLevel.SEVERE, FatigueLevel.CRITICAL]
    
    def get_indicators(self) -> FatigueIndicators:
        """Get current fatigue indicators."""
        return self._current_indicators
    
    def get_detailed_report(self) -> Dict[str, Any]:
        """Get detailed fatigue report."""
        return {
            'level': self._current_level.name,
            'level_value': self._current_level.value,
            'indicators': {
                'torque_decline': self._current_indicators.torque_decline_ratio,
                'movement_smoothness': self._current_indicators.movement_smoothness,
                'rom_decline': self._current_indicators.rom_decline_ratio,
                'velocity_decline': self._current_indicators.velocity_decline_ratio,
            },
            'should_pause': self.should_pause(),
            'repetitions_tracked': len(self._rep_roms),
        }
    
    def reset(self) -> None:
        self._baseline = None
        self._torque_buffer.clear()
        self._position_buffer.clear()
        self._velocity_buffer.clear()
        self._rep_positions = []
        self._rep_roms = []
        self._current_level = FatigueLevel.NONE
        self._initialized = False


# ==================== Factory Function ====================

def create_fatigue_detector(
    detector_type: str = 'composite',
    sample_rate: float = 100.0,
    **kwargs
) -> FatigueDetector:
    """
    Factory function to create fatigue detector.
    
    Args:
        detector_type: 'torque', 'smoothness', or 'composite'
        sample_rate: Data sampling rate (Hz)
        **kwargs: Additional arguments for specific detector
        
    Returns:
        Configured FatigueDetector instance
    """
    if detector_type == 'torque':
        return TorqueBasedFatigueDetector(**kwargs)
    elif detector_type == 'smoothness':
        return MovementSmoothnessDetector(sample_rate=sample_rate, **kwargs)
    elif detector_type == 'composite':
        return CompositeFatigueDetector(sample_rate=sample_rate, **kwargs)
    else:
        raise ValueError(f"Unknown detector type: {detector_type}")
