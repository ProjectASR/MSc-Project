"""Fatigue module - Fatigue detection algorithms."""

from .fatigue_detector import (
    FatigueThresholds,
    BaselineMetrics,
    TorqueBasedFatigueDetector,
    MovementSmoothnessDetector,
    CompositeFatigueDetector,
    create_fatigue_detector,
)

__all__ = [
    'FatigueThresholds',
    'BaselineMetrics',
    'TorqueBasedFatigueDetector',
    'MovementSmoothnessDetector',
    'CompositeFatigueDetector',
    'create_fatigue_detector',
]
