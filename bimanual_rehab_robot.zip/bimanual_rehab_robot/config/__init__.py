"""Config module - Configuration settings."""
