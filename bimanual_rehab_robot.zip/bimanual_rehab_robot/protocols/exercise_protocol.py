"""
Exercise Protocol Management for Bimanual Rehabilitation Robot.

Provides:
- Exercise definitions for elbow flexion/extension and shoulder rotation
- Protocol builder for creating customized exercise sequences
- Protocol optimization based on patient capabilities

Developed in consultation with physiotherapists for evidence-based rehabilitation.
"""
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
import uuid
import numpy as np

from core.base import Entity, ExerciseProtocolBase
from core.enums import (
    ExerciseType, ExerciseMode, FatigueLevel, 
    JointType, AffectedSide
)


@dataclass
class ExerciseParameters:
    """
    Parameters defining a single exercise.
    
    Based on rehabilitation guidelines and clinical practice.
    """
    # Movement parameters
    range_of_motion: float          # degrees
    movement_speed: float           # degrees/second
    hold_time: float = 0.0          # seconds at end position
    
    # Repetition parameters
    repetitions: int = 10
    sets: int = 3
    rest_between_sets: float = 60.0  # seconds
    
    # Assistance/resistance
    assistance_level: float = 0.0   # 0-1 (0=none, 1=full assistance)
    resistance_level: float = 0.0   # 0-1 (0=none, 1=max resistance)
    
    # Safety limits
    max_torque: float = 10.0        # Nm
    max_velocity: float = 60.0      # degrees/second
    
    def validate(self) -> List[str]:
        """Validate parameters and return list of issues."""
        issues = []
        
        if self.range_of_motion <= 0:
            issues.append("Range of motion must be positive")
        if self.movement_speed <= 0:
            issues.append("Movement speed must be positive")
        if self.repetitions < 1:
            issues.append("Must have at least 1 repetition")
        if self.sets < 1:
            issues.append("Must have at least 1 set")
        if not 0 <= self.assistance_level <= 1:
            issues.append("Assistance level must be 0-1")
        if not 0 <= self.resistance_level <= 1:
            issues.append("Resistance level must be 0-1")
        if self.assistance_level > 0 and self.resistance_level > 0:
            issues.append("Cannot have both assistance and resistance")
            
        return issues
    
    def estimated_duration(self) -> float:
        """Estimate total exercise duration in seconds."""
        time_per_rep = (self.range_of_motion / self.movement_speed) * 2 + self.hold_time
        time_per_set = time_per_rep * self.repetitions
        total_time = time_per_set * self.sets + self.rest_between_sets * (self.sets - 1)
        return total_time
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'range_of_motion': self.range_of_motion,
            'movement_speed': self.movement_speed,
            'hold_time': self.hold_time,
            'repetitions': self.repetitions,
            'sets': self.sets,
            'rest_between_sets': self.rest_between_sets,
            'assistance_level': self.assistance_level,
            'resistance_level': self.resistance_level,
            'max_torque': self.max_torque,
            'max_velocity': self.max_velocity,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ExerciseParameters':
        return cls(**data)


@dataclass
class Exercise(Entity):
    """
    Single exercise definition.
    """
    name: str = ""
    description: str = ""
    exercise_type: ExerciseType = ExerciseType.ELBOW_FLEXION_EXTENSION
    joint_type: JointType = JointType.ELBOW_FLEXION
    mode: ExerciseMode = ExerciseMode.PASSIVE
    parameters: ExerciseParameters = field(default_factory=lambda: ExerciseParameters(
        range_of_motion=45.0, movement_speed=15.0
    ))
    
    # Optional guidance
    instructions: str = ""
    precautions: List[str] = field(default_factory=list)
    
    # Categorization
    difficulty_level: int = 1  # 1-5
    target_muscles: List[str] = field(default_factory=list)
    
    @classmethod
    def create(
        cls,
        name: str,
        exercise_type: ExerciseType,
        joint_type: JointType,
        mode: ExerciseMode,
        parameters: ExerciseParameters,
        **kwargs
    ) -> 'Exercise':
        """Factory method to create exercise with generated ID."""
        exercise_id = f"EX-{uuid.uuid4().hex[:8].upper()}"
        return cls(
            id=exercise_id,
            name=name,
            description=kwargs.get('description', ''),
            exercise_type=exercise_type,
            joint_type=joint_type,
            mode=mode,
            parameters=parameters,
            **{k: v for k, v in kwargs.items() if k != 'description'}
        )
    
    def is_valid(self) -> tuple[bool, List[str]]:
        """Check if exercise configuration is valid."""
        issues = self.parameters.validate()
        return len(issues) == 0, issues
    
    def get_estimated_duration(self) -> timedelta:
        """Get estimated duration as timedelta."""
        seconds = self.parameters.estimated_duration()
        return timedelta(seconds=seconds)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'exercise_type': self.exercise_type.name,
            'joint_type': self.joint_type.name,
            'mode': self.mode.name,
            'parameters': self.parameters.to_dict(),
            'instructions': self.instructions,
            'precautions': self.precautions,
            'difficulty_level': self.difficulty_level,
            'target_muscles': self.target_muscles,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Exercise':
        data = data.copy()
        data['exercise_type'] = ExerciseType[data['exercise_type']]
        data['joint_type'] = JointType[data['joint_type']]
        data['mode'] = ExerciseMode[data['mode']]
        data['parameters'] = ExerciseParameters.from_dict(data['parameters'])
        data['created_at'] = datetime.fromisoformat(data['created_at'])
        data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        return cls(**data)


@dataclass
class ExerciseProtocol(Entity, ExerciseProtocolBase):
    """
    Complete exercise protocol consisting of multiple exercises.
    
    Designed to be personalized for each patient based on:
    - Affected side
    - Current motor function
    - Recovery stage
    - Fatigue tolerance
    """
    name: str = ""
    description: str = ""
    exercises: List[Exercise] = field(default_factory=list)
    
    # Protocol metadata
    target_condition: str = "Post-stroke hemiparesis"
    difficulty_level: int = 1  # 1-5 overall difficulty
    
    # Execution tracking
    _current_exercise_index: int = field(default=0, repr=False)
    _current_set: int = field(default=1, repr=False)
    _current_rep: int = field(default=1, repr=False)
    
    # Protocol customization
    warmup_duration: float = 300.0   # 5 minutes
    cooldown_duration: float = 300.0  # 5 minutes
    
    # Fatigue management
    fatigue_adjustment_enabled: bool = True
    max_session_duration: float = 3600.0  # 1 hour max
    
    @classmethod
    def create(cls, name: str, description: str = "", **kwargs) -> 'ExerciseProtocol':
        """Factory method to create protocol with generated ID."""
        protocol_id = f"PROT-{uuid.uuid4().hex[:8].upper()}"
        return cls(id=protocol_id, name=name, description=description, **kwargs)
    
    def add_exercise(self, exercise: Exercise) -> None:
        """Add exercise to protocol."""
        self.exercises.append(exercise)
        self.updated_at = datetime.now()
    
    def remove_exercise(self, exercise_id: str) -> bool:
        """Remove exercise by ID. Returns True if found and removed."""
        for i, ex in enumerate(self.exercises):
            if ex.id == exercise_id:
                self.exercises.pop(i)
                self.updated_at = datetime.now()
                return True
        return False
    
    def get_exercises(self) -> List[Exercise]:
        """Get all exercises in protocol."""
        return self.exercises.copy()
    
    def get_current_exercise(self) -> Optional[Exercise]:
        """Get the current exercise."""
        if 0 <= self._current_exercise_index < len(self.exercises):
            return self.exercises[self._current_exercise_index]
        return None
    
    def advance(self) -> bool:
        """
        Advance to next repetition/set/exercise.
        Returns False if protocol is complete.
        """
        current = self.get_current_exercise()
        if current is None:
            return False
        
        params = current.parameters
        
        # Advance repetition
        self._current_rep += 1
        
        # Check if set complete
        if self._current_rep > params.repetitions:
            self._current_rep = 1
            self._current_set += 1
            
            # Check if all sets complete
            if self._current_set > params.sets:
                self._current_set = 1
                self._current_exercise_index += 1
                
                # Check if protocol complete
                if self._current_exercise_index >= len(self.exercises):
                    return False
        
        return True
    
    def get_progress(self) -> float:
        """Get protocol completion progress (0.0 to 1.0)."""
        if not self.exercises:
            return 1.0
        
        total_reps = sum(
            ex.parameters.repetitions * ex.parameters.sets 
            for ex in self.exercises
        )
        
        completed_reps = sum(
            ex.parameters.repetitions * ex.parameters.sets
            for ex in self.exercises[:self._current_exercise_index]
        )
        
        current = self.get_current_exercise()
        if current:
            completed_reps += (
                (self._current_set - 1) * current.parameters.repetitions +
                (self._current_rep - 1)
            )
        
        return completed_reps / total_reps if total_reps > 0 else 1.0
    
    def modify_for_fatigue(self, fatigue_level: FatigueLevel) -> None:
        """
        Modify protocol parameters based on detected fatigue level.
        
        Adjustments:
        - MILD: Reduce speed by 10%
        - MODERATE: Reduce speed by 20%, reduce ROM by 10%
        - SEVERE: Reduce speed by 30%, reduce ROM by 20%, increase rest
        - CRITICAL: Stop protocol
        """
        if not self.fatigue_adjustment_enabled:
            return
        
        current = self.get_current_exercise()
        if current is None:
            return
        
        params = current.parameters
        
        if fatigue_level == FatigueLevel.MILD:
            params.movement_speed *= 0.9
        elif fatigue_level == FatigueLevel.MODERATE:
            params.movement_speed *= 0.8
            params.range_of_motion *= 0.9
        elif fatigue_level == FatigueLevel.SEVERE:
            params.movement_speed *= 0.7
            params.range_of_motion *= 0.8
            params.rest_between_sets *= 1.5
        elif fatigue_level == FatigueLevel.CRITICAL:
            # Should trigger protocol pause
            pass
    
    def reset(self) -> None:
        """Reset protocol to beginning."""
        self._current_exercise_index = 0
        self._current_set = 1
        self._current_rep = 1
    
    def get_total_duration(self) -> timedelta:
        """Get estimated total protocol duration."""
        exercise_time = sum(
            ex.parameters.estimated_duration() 
            for ex in self.exercises
        )
        total_seconds = (
            self.warmup_duration + 
            exercise_time + 
            self.cooldown_duration
        )
        return timedelta(seconds=total_seconds)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'exercises': [ex.to_dict() for ex in self.exercises],
            'target_condition': self.target_condition,
            'difficulty_level': self.difficulty_level,
            'warmup_duration': self.warmup_duration,
            'cooldown_duration': self.cooldown_duration,
            'fatigue_adjustment_enabled': self.fatigue_adjustment_enabled,
            'max_session_duration': self.max_session_duration,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ExerciseProtocol':
        data = data.copy()
        data['exercises'] = [Exercise.from_dict(ex) for ex in data['exercises']]
        data['created_at'] = datetime.fromisoformat(data['created_at'])
        data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        return cls(**data)


class ProtocolBuilder:
    """
    Builder pattern for creating exercise protocols.
    
    Provides fluent interface for constructing protocols step by step.
    """
    
    def __init__(self):
        self._protocol: Optional[ExerciseProtocol] = None
        self._exercises: List[Exercise] = []
    
    def create_protocol(self, name: str, description: str = "") -> 'ProtocolBuilder':
        """Start building a new protocol."""
        self._protocol = ExerciseProtocol.create(name, description)
        self._exercises = []
        return self
    
    def set_difficulty(self, level: int) -> 'ProtocolBuilder':
        """Set overall difficulty level (1-5)."""
        if self._protocol:
            self._protocol.difficulty_level = max(1, min(5, level))
        return self
    
    def set_warmup(self, duration_seconds: float) -> 'ProtocolBuilder':
        """Set warmup duration."""
        if self._protocol:
            self._protocol.warmup_duration = duration_seconds
        return self
    
    def set_cooldown(self, duration_seconds: float) -> 'ProtocolBuilder':
        """Set cooldown duration."""
        if self._protocol:
            self._protocol.cooldown_duration = duration_seconds
        return self
    
    def add_elbow_flexion_extension(
        self,
        rom_degrees: float = 90.0,
        speed_degrees_per_sec: float = 30.0,
        repetitions: int = 10,
        sets: int = 3,
        mode: ExerciseMode = ExerciseMode.ACTIVE_ASSISTED,
        assistance: float = 0.3,
    ) -> 'ProtocolBuilder':
        """Add elbow flexion/extension exercise."""
        params = ExerciseParameters(
            range_of_motion=rom_degrees,
            movement_speed=speed_degrees_per_sec,
            repetitions=repetitions,
            sets=sets,
            assistance_level=assistance if mode == ExerciseMode.ACTIVE_ASSISTED else 0,
        )
        
        exercise = Exercise.create(
            name="Elbow Flexion/Extension",
            exercise_type=ExerciseType.ELBOW_FLEXION_EXTENSION,
            joint_type=JointType.ELBOW_FLEXION,
            mode=mode,
            parameters=params,
            description="Bend and straighten the elbow joint",
            target_muscles=["Biceps brachii", "Triceps brachii"],
            instructions="Slowly bend your elbow, then straighten it completely.",
        )
        
        self._exercises.append(exercise)
        return self
    
    def add_shoulder_rotation(
        self,
        rom_degrees: float = 60.0,
        speed_degrees_per_sec: float = 20.0,
        repetitions: int = 10,
        sets: int = 3,
        mode: ExerciseMode = ExerciseMode.ACTIVE_ASSISTED,
        assistance: float = 0.3,
    ) -> 'ProtocolBuilder':
        """Add shoulder internal/external rotation exercise."""
        params = ExerciseParameters(
            range_of_motion=rom_degrees,
            movement_speed=speed_degrees_per_sec,
            repetitions=repetitions,
            sets=sets,
            assistance_level=assistance if mode == ExerciseMode.ACTIVE_ASSISTED else 0,
        )
        
        exercise = Exercise.create(
            name="Shoulder Rotation",
            exercise_type=ExerciseType.SHOULDER_ROTATION,
            joint_type=JointType.SHOULDER_INTERNAL_ROTATION,
            mode=mode,
            parameters=params,
            description="Rotate the shoulder internally and externally",
            target_muscles=["Rotator cuff", "Deltoid"],
            instructions="Keep elbow at 90°, rotate forearm in and out.",
        )
        
        self._exercises.append(exercise)
        return self
    
    def add_bimanual_symmetric(
        self,
        exercise_type: ExerciseType,
        rom_degrees: float = 60.0,
        speed_degrees_per_sec: float = 20.0,
        repetitions: int = 10,
        sets: int = 3,
    ) -> 'ProtocolBuilder':
        """Add bimanual symmetric exercise (both arms move together)."""
        params = ExerciseParameters(
            range_of_motion=rom_degrees,
            movement_speed=speed_degrees_per_sec,
            repetitions=repetitions,
            sets=sets,
        )
        
        joint_type = (
            JointType.ELBOW_FLEXION 
            if exercise_type == ExerciseType.ELBOW_FLEXION_EXTENSION 
            else JointType.SHOULDER_INTERNAL_ROTATION
        )
        
        exercise = Exercise.create(
            name="Bimanual Symmetric Exercise",
            exercise_type=ExerciseType.BIMANUAL_SYMMETRIC,
            joint_type=joint_type,
            mode=ExerciseMode.ACTIVE_ASSISTED,
            parameters=params,
            description="Both arms move in mirror-image pattern",
            instructions="Let your sound arm guide the movement. The paretic arm will follow.",
        )
        
        self._exercises.append(exercise)
        return self
    
    def add_custom_exercise(self, exercise: Exercise) -> 'ProtocolBuilder':
        """Add a custom-defined exercise."""
        self._exercises.append(exercise)
        return self
    
    def enable_fatigue_adjustment(self, enabled: bool = True) -> 'ProtocolBuilder':
        """Enable or disable automatic fatigue adjustment."""
        if self._protocol:
            self._protocol.fatigue_adjustment_enabled = enabled
        return self
    
    def set_max_duration(self, minutes: float) -> 'ProtocolBuilder':
        """Set maximum session duration in minutes."""
        if self._protocol:
            self._protocol.max_session_duration = minutes * 60
        return self
    
    def build(self) -> ExerciseProtocol:
        """Build and return the completed protocol."""
        if self._protocol is None:
            raise ValueError("No protocol created. Call create_protocol() first.")
        
        for exercise in self._exercises:
            self._protocol.add_exercise(exercise)
        
        protocol = self._protocol
        self._protocol = None
        self._exercises = []
        
        return protocol


# ==================== Predefined Protocols ====================

class StandardProtocols:
    """
    Factory for standard rehabilitation protocols.
    
    Based on clinical guidelines and evidence-based practice.
    """
    
    @staticmethod
    def beginner_protocol() -> ExerciseProtocol:
        """
        Create beginner protocol for early-stage rehabilitation.
        
        Characteristics:
        - Low ROM
        - Slow movements
        - High assistance
        - Few repetitions
        """
        return (
            ProtocolBuilder()
            .create_protocol(
                "Beginner Protocol",
                "For early-stage rehabilitation with limited motor function"
            )
            .set_difficulty(1)
            .set_warmup(300)  # 5 min
            .add_elbow_flexion_extension(
                rom_degrees=45,
                speed_degrees_per_sec=15,
                repetitions=5,
                sets=2,
                mode=ExerciseMode.PASSIVE,
                assistance=0.8,
            )
            .add_shoulder_rotation(
                rom_degrees=30,
                speed_degrees_per_sec=10,
                repetitions=5,
                sets=2,
                mode=ExerciseMode.PASSIVE,
                assistance=0.8,
            )
            .enable_fatigue_adjustment(True)
            .set_max_duration(30)
            .build()
        )
    
    @staticmethod
    def intermediate_protocol() -> ExerciseProtocol:
        """
        Create intermediate protocol for patients showing recovery.
        """
        return (
            ProtocolBuilder()
            .create_protocol(
                "Intermediate Protocol",
                "For patients with some voluntary movement"
            )
            .set_difficulty(3)
            .set_warmup(300)
            .add_elbow_flexion_extension(
                rom_degrees=90,
                speed_degrees_per_sec=30,
                repetitions=10,
                sets=3,
                mode=ExerciseMode.ACTIVE_ASSISTED,
                assistance=0.4,
            )
            .add_shoulder_rotation(
                rom_degrees=60,
                speed_degrees_per_sec=20,
                repetitions=10,
                sets=3,
                mode=ExerciseMode.ACTIVE_ASSISTED,
                assistance=0.4,
            )
            .add_bimanual_symmetric(
                ExerciseType.ELBOW_FLEXION_EXTENSION,
                rom_degrees=60,
                speed_degrees_per_sec=20,
                repetitions=8,
                sets=2,
            )
            .enable_fatigue_adjustment(True)
            .set_max_duration(45)
            .build()
        )
    
    @staticmethod
    def advanced_protocol() -> ExerciseProtocol:
        """
        Create advanced protocol for late-stage rehabilitation.
        """
        return (
            ProtocolBuilder()
            .create_protocol(
                "Advanced Protocol",
                "For patients with significant motor recovery"
            )
            .set_difficulty(5)
            .set_warmup(300)
            .add_elbow_flexion_extension(
                rom_degrees=120,
                speed_degrees_per_sec=45,
                repetitions=15,
                sets=3,
                mode=ExerciseMode.ACTIVE,
                assistance=0.0,
            )
            .add_shoulder_rotation(
                rom_degrees=90,
                speed_degrees_per_sec=30,
                repetitions=15,
                sets=3,
                mode=ExerciseMode.ACTIVE,
                assistance=0.0,
            )
            .add_bimanual_symmetric(
                ExerciseType.ELBOW_FLEXION_EXTENSION,
                rom_degrees=90,
                speed_degrees_per_sec=30,
                repetitions=12,
                sets=3,
            )
            .add_bimanual_symmetric(
                ExerciseType.SHOULDER_ROTATION,
                rom_degrees=60,
                speed_degrees_per_sec=25,
                repetitions=12,
                sets=3,
            )
            .enable_fatigue_adjustment(True)
            .set_max_duration(60)
            .build()
        )
    
    @staticmethod
    def get_protocol_for_fma_score(fma_score: int) -> ExerciseProtocol:
        """
        Select appropriate protocol based on Fugl-Meyer Assessment score.
        
        FMA Upper Extremity: 0-66
        - 0-22: Severe impairment -> Beginner
        - 23-44: Moderate impairment -> Intermediate
        - 45-66: Mild impairment -> Advanced
        """
        if fma_score < 23:
            return StandardProtocols.beginner_protocol()
        elif fma_score < 45:
            return StandardProtocols.intermediate_protocol()
        else:
            return StandardProtocols.advanced_protocol()
