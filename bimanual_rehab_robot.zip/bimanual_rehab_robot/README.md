# Bimanual Tele-Rehabilitation Robot Software System

## Project: Adaptive Torque Modeling and Optimized Exercise Protocols for Upper Limb Bimanual Tele-Robot

**University of Moratuwa - Robotics and Automation Laboratory**

---

## 🚀 QUICK START - Launch the GUI

```powershell
# Install dependencies
pip install customtkinter pillow numpy scipy

# Run the UI
python run_ui.py
```

---

## 📁 Project Structure

```
bimanual_rehab_robot/
├── run_ui.py               # 🚀 LAUNCH THE GUI - Run this!
├── main.py                 # Command-line examples
├── requirements.txt        # Python dependencies
│
├── ui/                     # 🖥️ User Interface
│   ├── app.py             # Main application
│   ├── config.py          # Colors, fonts, themes
│   ├── widgets.py         # Custom UI components
│   ├── login_screen.py    # Login page
│   ├── dashboard.py       # Role-based dashboards
│   └── session_control.py # Real-time session control
│
├── core/                   # Core module
│   ├── enums.py           # All enumerations
│   ├── exceptions.py      # Custom exceptions
│   └── base.py            # Abstract base classes
│
├── models/                 # Data models
│   └── patient.py         # Patient & Anthropometrics
│
├── estimation/             # Parameter estimation
│   ├── bsip_calculator.py # Body Segment Inertial Parameters
│   ├── parameter_estimators.py  # RLS & FFRLS
│   └── arm_dynamics.py    # 2-DOF arm dynamics
│
├── protocols/              # Exercise protocols
│   └── exercise_protocol.py
│
└── fatigue/                # Fatigue detection
    └── fatigue_detector.py
```

---

## 🖥️ User Interface Features

### Login Screen
- Role-based access: **Doctor, Physiotherapist, Caregiver, Patient**
- Modern, professional design
- Demo mode: Enter any username/password to login

### Dashboard Views
- **Doctor**: Patient management, protocols, analytics
- **Physiotherapist**: Session control, live metrics, patient progress
- **Caregiver**: Daily exercises, patient status, emergency contacts
- **Patient**: Personal progress, achievements, exercise schedule

### Session Control (Physiotherapists)
- **Real-time robot arm visualization** with animation
- **Live metrics**: Torque, velocity, position, fatigue level
- **Adjustable parameters**: Assistance, speed, ROM
- **Progress tracking**: Reps, sets, session progress
- **Emergency stop button**: Safety first!
- **Session logging**: All events recorded

---

## 📦 Installation

### Windows PowerShell

```powershell
# 1. Navigate to project folder
cd "path\to\bimanual_rehab_robot"

# 2. Create virtual environment (recommended)
python -m venv venv
.\venv\Scripts\Activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the GUI
python run_ui.py
```

### Required Packages
```
customtkinter>=5.2.0
pillow>=9.0.0
numpy>=1.24.0
scipy>=1.10.0
```

---

## 📊 Command-Line Examples

Run without GUI:
```powershell
python main.py                    # All examples
python main.py --example bsip     # BSIP calculation
python main.py --example dynamics # Arm dynamics
python main.py --example protocol # Exercise protocols
```

---

## 💻 Code Usage

```python
from core.enums import Gender, AffectedSide
from models.patient import Patient, Anthropometrics
from estimation.bsip_calculator import create_bsip_calculator
from protocols.exercise_protocol import StandardProtocols

# Create patient
patient = Patient.create(
    name="John Doe",
    date_of_birth=date(1960, 5, 20),
    gender=Gender.MALE,
)

# Calculate BSIP
calculator = create_bsip_calculator()
bsip = calculator.calculate_all_segments(
    body_mass=70.0,
    upper_arm_length=0.30,
    forearm_length=0.25,
    hand_length=0.19,
    gender=Gender.MALE,
)

# Get protocol based on FMA score
protocol = StandardProtocols.get_protocol_for_fma_score(35)
```

---

## 📚 References

1. de Leva (1996) - BSIP adjustments
2. Dumas et al. (2007) - Updated BSIP equations
3. Frontiers 2023 - FFRLS for impedance control
4. Perera et al. (2024) - Bimanual robot (MERCon)

---

**University of Moratuwa • Robotics & Automation Laboratory**
